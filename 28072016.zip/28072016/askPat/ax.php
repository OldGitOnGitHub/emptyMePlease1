<?php
//error_reporting(E_ALL ^ E_NOTICE);
$u_agent = $_SERVER['HTTP_USER_AGENT'];
 
if(!preg_match('/MSIE/i',$u_agent)){
  echo "This application must be used with Microsoft Internet Explorer.";
  echo "Your current browser is: $u_agent" ;
  die;
}
 
session_start(); //Start the session or load session variables
 
if (!isset($_SESSION['MDRS2013username'])):
 
  if (isset($_COOKIE['MDRSUser2013'])):
    $MDRSUser2013 = ($_COOKIE['MDRSUser2013']);
  endif;
 
 
  if (isset($MDRSUser2013)):
                $_SESSION['MDRS2013username']=$MDRSUser2013;     
  endif;
 
endif;
 
 
?>
 
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
 
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Employee details</title>
 
<script type="text/javascript">
 
function usernamerequest(){
var ActiveX=new ActiveXObject("wscript.network");
return ActiveX.username;
alert("ActiveX call request to browser returns '" + ActiveX.username + "' for use in new cookie");
}
 
function getCookie(c_name)
{
var i,x,y,ARRcookies=document.cookie.split(";");
for (i=0;i<ARRcookies.length;i++)
{
  x=ARRcookies[i].substr(0,ARRcookies[i].indexOf("="));
  y=ARRcookies[i].substr(ARRcookies[i].indexOf("=")+1);
  x=x.replace(/^\s+|\s+$/g,"");
  alert("Get cookie found a cookie'" + x + "' and '" + y + "'in cookie")
  if (x==c_name)
    {
    return unescape(y);
    }
  }
}
 
function setCookie(c_name,value,exdays)
{
var exdate=new Date();
exdate.setDate(exdate.getDate() + exdays);
var c_value=escape(value) + ((exdays==null) ? "" : "; expires="+exdate.toUTCString());
document.cookie=c_name + "=" + c_value;
alert("Cookie set!!")
}
 
function checkCookie()
{
                //var ActiveX=new ActiveXObject("wscript.network");
                //alert("ActiveX call request to browser returns '" + ActiveX.username + "'");
               
  var username=getCookie("MDRSUser2013");
  alert("Get cookie function returns '" + username + "'");
 
  if (username==null || username=="" || username == "undefined"){
                  //alert('its unkwon');
                  //alert(usernamerequest());
  setCookie("MDRSUser2013",usernamerequest(),365);
  location.reload(true);
 
}
}
 
</script>
 
</head>
 
<body onload="checkCookie()">             
    <p>Your Windoze username is <?php
                if (isset($_SESSION['MDRS2013username'])):
                  echo $_SESSION['MDRS2013username'];
                else:
                  echo " UNKNOWN";
                endif; ?>.</p>
</body>
</html>