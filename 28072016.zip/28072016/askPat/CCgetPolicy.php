<?php

// includes
include('conf.php');
//include('userIDinclude.php'); 

// open database connection
$connection = mysql_connect($host, $user, $pass) or die ('Unable to connect!');

// select database
mysql_select_db($db) or die ('Unable to select database!');

$policyID = $_GET["policyID"];
$ipAddress = $_GET["ipAddress"];
$userID = $_GET["userID"];

// generate and execute query
$query = "SELECT * FROM CANCER_policies WHERE ID='".$policyID."'";

$result = mysql_query($query) or die ("Error in query: $query. " . mysql_error());
// if records present
if (mysql_num_rows($result) > 0)
{

      // iterate through resultset
      // print title with links to edit and delete scripts
      while($row = mysql_fetch_object($result))
      {
$returnValue['name'] = $row->name;	
$returnValue['Benefit1'] = $row->Benefit1;	
$returnValue['Benefit2'] = $row->Benefit2;	
$returnValue['Benefit3'] = $row->Benefit3;	
$returnValue['Benefit4'] = $row->Benefit4;
$returnValue['dateAdded'] = $row->dateAdded;
$returnValue['dateAddedStr'] = strtotime($row->dateAdded);
$returnValue['dateModified'] = $row->dateModified;
$returnValue['dateModified'] = strtotime($row->dateModified);

echo json_encode($returnValue);
	
	

	
	}
	
	

	
}

?>