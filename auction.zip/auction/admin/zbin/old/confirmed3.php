<?php
// gets the user's IP address
function getip() {
   if (getenv("HTTP_CLIENT_IP") && strcasecmp(getenv("HTTP_CLIENT_IP"), "unknown"))
  	 $ip = getenv("HTTP_CLIENT_IP");

   else if (getenv("HTTP_X_FORWARDED_FOR") && strcasecmp(getenv("HTTP_X_FORWARDED_FOR"), "unknown"))
   	$ip = getenv("HTTP_X_FORWARDED_FOR");

   else if (getenv("REMOTE_ADDR") && strcasecmp(getenv("REMOTE_ADDR"), "unknown"))
   	$ip = getenv("REMOTE_ADDR");

   else if (isset($_SERVER['REMOTE_ADDR']) && $_SERVER['REMOTE_ADDR'] && strcasecmp($_SERVER['REMOTE_ADDR'], "unknown"))
   	$ip = $_SERVER['REMOTE_ADDR'];

   else
   	$ip = "unknown";

   return($ip);
}
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="en" xml:lang="en">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<?php
$bidlot = stripslashes(htmlentities($_POST['bidlot']));
$name = stripslashes(htmlentities($_POST['name']));
$email = htmlentities($_POST['email']);
$phone = htmlentities($_POST['phone']);
$ext = htmlentities($_POST['ext']);
$bid = htmlentities($_POST['bid']);
$bid = ceil($bid);
echo "<title>Charity auction bid of $bid by $name confirmed for $bidlot</title>";

// -- vvaswani -- start
// includes
include('includes/conf.php');
include('includes/functions.php');

// open database connection
// select database
$connection = mysql_connect($host, $user, $pass) or die ('Unable to connect!');
mysql_select_db($db) or die ('Unable to select database!');

// get current max bid for this lot
$query = "SELECT MAX(MaximumBid) FROM bids WHERE LotNumber = '$bidlot'";
$result = mysql_query($query) or die ("Error in query: $query. " . mysql_error());
$row = mysql_fetch_array($result);
$currentMaxBid = (int)$row[0];

// get current displayed bid for this lot
$query = "SELECT LotCurrentDisplayBid FROM lots WHERE LotNumber = '$bidlot'";
$result = mysql_query($query) or die ("Error in query: $query. " . mysql_error());
$row = mysql_fetch_array($result);
$currentDisplayBid = (int)$row[0];

$sendFlag = false;

if ($bid > $currentDisplayBid) {
  $now = mktime();
  
  if ($bid == $currentMaxBid) {
    // bid is higher than displayed bid value and equal to max bid value
    // update displayed bid value to new bid but keep bidder record as is
    $query = "UPDATE lots SET LotCurrentDisplayBid = '" . ($bid) . "' WHERE LotNumber = '$bidlot'";
    mysql_query($query) or die ("Error in query: $query. " . mysql_error());  
    $message = "You've matched the current maximum. Please bid again, at least 1 pound more this time.";
  }
  
  if ($bid < $currentMaxBid) {
    // bid is higher than displayed bid value and less than max bid value
    // update displayed bid value to (new bid+1) but keep bidder record as is
    $query = "UPDATE lots SET LotCurrentDisplayBid = '" . ($bid+1) . "' WHERE LotNumber = '$bidlot'";
    mysql_query($query) or die ("Error in query: $query. " . mysql_error());    
    $message = "You need to enter a higher bid to win this item. <p> <a href='index.php'>Go Back to auction listings</a> to bid again.</p>";            
  }
  
  if ($bid > $currentMaxBid) {
    // bid is higher than displayed bid value and max bid value
    // save bid 
    // update displayed bid value and save corresponding bid record
    $query = "INSERT INTO bids (LotNumber, MaximumBid, BidTime, BidderName, BidderEmail, BidderPhone) VALUES('$bidlot', '$bid', FROM_UNIXTIME('$now'), '$name', '$email', '$phone')";
    mysql_query($query) or die ("Error in query: $query. " . mysql_error());  
    $id = mysql_insert_id();  
    unset($query);
    $query = "UPDATE lots SET LotCurrentDisplayBid = '" . ($currentMaxBid+1) . "', LotCurrentActiveBid = '$id' WHERE LotNumber='$bidlot'";
    mysql_query($query) or die ("Error in query: $query. " . mysql_error());    
    $sendFlag = true;
  } 
  
} else {
   $message = "You need to enter a higher bid to win this item. <p> <a href='index.php'>Go Back to auction listings</a> to bid again.</p>";  
}


// -- vvaswani -- end

$document_owner="graham.thomas@axa-ppp.co.uk";
$devolved_publisher="matthew.newman@axa-ppp.co.uk";
include($_SERVER['DOCUMENT_ROOT']."/intranet/global/includes/page-scripts-styles.html");
?>
<script type="text/javascript">
navLocation="Time out:Auction:";
</script>
</head>
<body class="col3">

<div id="wrapper">
<?php
include($_SERVER['DOCUMENT_ROOT']."/intranet/global/includes/page-header.php");
include($_SERVER['DOCUMENT_ROOT']."/intranet/timeout/sports-and-social/local-nav.html");
?>
<div class="presentational1"></div>
<?php
$bidlot = stripslashes($_POST["bidlot"]);
?>
<div id="content">

<?php if ($sendFlag === true): ?>

<h1>Bid confirmed for Lot number <?php echo $bidlot ?></h1>
<p>Your bid has been sent through to PPP's charity auction containing the following details:</p>
<ul class="list-nobullets">
  <li>Your name: <?php echo $name ?></li>
  <li>Your email address: <?php echo $email ?></li>
  <li>Your phone number: <?php echo $phone ?></li>
  <li>Your maximum bid: <?php echo $bid ?> pounds</li>
</ul>
<p>You will be sent confirmation of your bid by email. If you do not get an email within a few minutes, please contact Graham on 771 5239.<p>

<p>Feel free to select the "Back to the auction listings" link, to check the status of your bid and look at other items.</p>

<p><a href='index.php'>Back to auction listings</a></p>
<?php
mail("matthew.newman@axa-ppp.co.uk", "Another Bid of $bid by $name for $bidlot",

"Hello Auction Administrator,

The following bid has been placed in the charity auction:

Item: $bidlot
Name: $name
Email address: $email
Extension no: $phone
Bid amount: $bid

$name has been sent an email to confirm the bid.

This message was sent from the following computer network address " . getip() ."

\n\r", "From:intranet\r\n");

mail("$email", "Thanks for the Bid of $bid from $name for $bidlot",

"Hello there,

The following bid has been placed in the charity auction:

Item: $bidlot

Name: $name

Email address: $email

Extension no: $phone

Bid amount: $bid

Our assumption is that this bid was placed by you.

If you did not place this bid, please contact Graham Thomas immediately.\n\r", "From:intranet\r\n");

?>
<?php else: ?>
<?php echo $message; ?>
<?php endif; ?>
</div>
<div class="presentational2"></div>
<div id="related-links">
<h2><b>Related</b> links</h2>
<ul>
<li><a href="http://www.kentairambulance.co.uk/">Kent Air Ambulance</a></li>
</ul>
</div>

<?php
include($_SERVER['DOCUMENT_ROOT']."/intranet/global/includes/page-last-updated.php");
include($_SERVER['DOCUMENT_ROOT']."/intranet/global/includes/footer.php");
?>
</div>
</body>
</html>