<!DOCTYPE html>
<meta http-equiv="X-UA-Compatible" content="IE=edge" />
<?php  include('userIDinclude.php'); ?>

<html>
<head>
<title>Add a company</title>

<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.css">

<link rel="stylesheet" type="text/css" href="styles.css">

</head>
<body class="formPage">
<?php
if (!$_POST['submit'])
{
?>


<h1>Add a company</h1>
<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST">
<label>Company Name</label>
<input type="text" name="name"/>
<label>Part of AXA group?</label>
<input type="checkbox" name="AXAgroup" value="1"/>
<label>Generic Item #1</label>
<textarea name="GenericItem1"></textarea>
<label>Generic Item #2</label>
<textarea name="GenericItem2"></textarea>
<label>Generic Item #3</label>
<textarea name="GenericItem3"></textarea>
<label>General Info</label>
<textarea name="GeneralInfo"></textarea>
<label>Web Address</label>
<input type="text" name="WebAddress"/>
<input type="submit" value="Add" name="submit">
</form>


<?php
}
else
{
    // includes
    include('conf.php');

    // set up error list array
    $errorList = array();
    
    $name = $_POST['name'];
    $AXAgroup = $_POST['AXAgroup'];
    $genericItem1 = $_POST['GenericItem1'];
    $genericItem2 = $_POST['GenericItem2'];
    $genericItem3 = $_POST['GenericItem3'];
    $generalInfo = $_POST['GeneralInfo'];
    $webAddress = $_POST['WebAddress'];
    
    	
    // validate text input fields
    if (trim($_POST['name']) == '') 
    { 
        $errorList[] = 'Invalid entry: Name'; 
    }
    if (trim($_POST['GenericItem1']) == '') 
    { 
        $errorList[] = 'Invalid entry: Generic Item 1'; 
    }
    if (trim($_POST['GenericItem2']) == '') 
    { 
        $errorList[] = 'Invalid entry: Generic Item 2'; 
    }
    if (trim($_POST['GenericItem3']) == '') 
    { 
        $errorList[] = 'Invalid entry: Generic Item 3'; 
    }
    if (trim($_POST['GeneralInfo']) == '') 
    { 
        $errorList[] = 'Invalid entry: General Info'; 
    }
    if (trim($_POST['WebAddress']) == '') 
    { 
        $errorList[] = 'Invalid entry: Web Address'; 
    }


    if (!trim($_POST['AXAgroup']) == '1')  {
    	$AXAgroup="0";
    	}


    
    // check for errors
    // if none found...
    if (sizeof($errorList) == 0)
    {
        // open database connection
        $connection = mysql_connect($host, $user, $pass) or die ('Unable to connect!');

        // select database
        mysql_select_db($db) or die ('Unable to select database!');
		$dateA = date("d/m/Y");

        // generate and execute query
        $query = "INSERT INTO CASHBACK_companies(name, AXAgroup, genericItem1, genericItem1date, genericItem2, genericItem2date, genericItem3, genericItem3date, generalInfo, webAddress) VALUES('$name', '$AXAgroup', '$genericItem1', '$dateA', '$genericItem2', '$dateA', '$genericItem3', '$dateA', '$generalInfo', '$webAddress')";

        $result = mysql_query($query) or die ("Error in query: $query. " . mysql_error());

/**********ACTIVITY LOG FUNCTIONALITY**********/
        $currentFile = $_SERVER["PHP_SELF"];
		$ipAddress = $_SERVER["REMOTE_ADDR"];
		$date = date("Y/m/d");
		$escapedQuery = mysql_escape_string($query);
        // generate and execute query
        $activityQuery = "INSERT INTO activityLog(user, page, notes, query, errors, dateExecuted, ipAddress) VALUES('$userID', '$currentFile', 'Added a new CASHBACK company.', '$escapedQuery', '', '$date', '$ipAddress')";

        $activityResult = mysql_query($activityQuery) or die ("Error in query: $query. " . mysql_error());
/**********************************************/
        // print result
        echo '<h2>Update successful.</h2><br><a href="CASHBACKadmin.php">Return to admin screen</a>';

        // close database connection
        mysql_close($connection);
    }
    else
    {
        // errors found
        // print as list
        echo '<font size=-1>The following errors were encountered:'; 
        echo '<br>';
        echo '<ul>';
        for ($x=0; $x<sizeof($errorList); $x++)
        {
            echo "<li>$errorList[$x]";
        }
        echo '</ul></font><br /><a href=&amp;javascript: history.go(-1)&amp;>Back</a>';
    }
}
?>

</body>
</html>