<?php
/*
Used by ISC Agents to get a record of their activity on 'Ask Pat'
*/
                //include('userIDinclude.php');
                $MDRSUser2013 = ($_COOKIE['MDRSUser2013']); //The standard way we get the value back from the cookie
 
                $dbHost               = 'healthnet-mysql.axa-uk.intraxa';           //            database host
                $dbUser               = 'HealthnetUser';                           //            database user
                $dbPass               = 'PPPphp55';                     			//            database password
                $dbName            = 'cPat';                                 		//            database name
                $dbTable = 'activityLog';
                //$userID = 'Terry Golding';
                $userID = $MDRSUser2013;
 
 
                $connection = @mysql_connect($dbHost, $dbUser, $dbPass) or die("Couldn't connect.");
                $db = mysql_select_db($dbName, $connection) or die("Couldn't select database.");
                //$sql = "Select * FROM $dbTable";
                //$sql = "Select user, notes, dateExecuted FROM $dbTable WHERE user = '$userID'";
				$sql = "Select user, notes, dateExecuted FROM $dbTable WHERE id > 1533";
                $result = @mysql_query($sql)   or die("Couldn't execute query:".mysql_error().''.mysql_errno());
 
                header('Content-Type: application/vnd.ms-excel');       //define header info for browser
                header('Content-Disposition: attachment; filename='.$dbTable.'-'.$userID.'-'.date('Ymd').'.xls');
                header('Pragma: no-cache');
                header('Expires: 0');
 
                for ($i = 0; $i < mysql_num_fields($result); $i++)               // show column names as names of MySQL fields
                                echo mysql_field_name($result, $i)."\t";
                print("\n");
 
                while($row = mysql_fetch_row($result))
                {
                                //set_time_limit(60); // you can enable this if you have lot of data
                                $output = '';
                                for($j=0; $j < mysql_num_fields($result); $j++)
                                {
                                                if(!isset($row[$j]))
                                                                $output .= "NULL\t";
                                                else
                                                                $output .= "$row[$j]\t";
                                }
                                $output = preg_replace("/\r\n|\n\r|\n|\r/", ' ', $output);
                                print(trim($output))."\t\n";
                }
?>