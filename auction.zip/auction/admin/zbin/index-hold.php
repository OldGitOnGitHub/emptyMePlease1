<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="en" xml:lang="en">
<head>
	<!-- HINT! Do a search (CTRL + F) for four angle brackets like this >>>> to find all the sections of the page you need to edit-->

    <!-- >>>> Its important to add a document title, its what appears in the blue bar at the top of Internet Explorer -->
	<!-- >>>> Its NOT the title that appears on the main part of the page, see below for that (search for the word 'content' -->
    <title>Charity Auction</title>    
    <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
    
	<!-- >>>> add a description here of the contants of the page  -->
	<!-- >>>> ie Introduction to the XYZ Team, we build widgits, make tea, and say wibble to anyone who will listen  -->
	<meta name="description" content="Charity Auction" />
	
    <!-- stop 'em bidding after its closed -->
    <!-- <meta http-equiv="refresh" content="60; url=/intranet/timeout/Auction/2012/index.php"> -->

	<?php
	// >>>> Change the email addresses on the following lines to the information owner and publisher (can be different)
	// >>>> the publisher line controls the name that appears at the bottom of the page when its on Healthnet, you cant change the date that appears 
      $document_owner="graham.thomas@axa-ppp.co.uk";
      $devolved_publisher="terry.golding@axa-ppp.co.uk";      
    ?>
    <link rel="search" type="application/opensearchdescription+xml" href="http://www.intranet.pppgroup.co.uk/intranet/global/includes/opensearch.xml" title="AXA PPP intranet search" />
    <link rel="search" type="application/opensearchdescription+xml" href="http://www.intranet.pppgroup.co.uk/intranet/global/includes/opensearch-phonedir.xml" title="AXA UK phone directory" />
    <link type="image/x-icon" href="/intranet/global/imgs/favicon.ico" rel="Shortcut Icon" />
    <meta http-equiv="imagetoolbar" content="no" />
    <link href="/intranet/global/css/common.css" rel="stylesheet" media="screen, print" type="text/css" />
    <link href="/intranet/global/css/content.css" rel="stylesheet" media="screen, print" type="text/css" />
    <link href="/intranet/global/css/appphspecific.css" rel="stylesheet" media="screen, print" type="text/css" />
    <link href="/intranet/global/css/pages.css" rel="stylesheet" media="print, screen" type="text/css" />
    <link href="/intranet/global/css/print.css" rel="stylesheet" media="print" type="text/css" />
    <script type="text/javascript" src="http://www.intranet.pppgroup.co.uk/intranet/global/scripts/jquery-1.3.2.min.js"></script>
    <script type="text/javascript" src="http://www.intranet.pppgroup.co.uk/intranet/global/scripts/scripts.js"></script>
    <script type="text/javascript" src="http://www.intranet.pppgroup.co.uk/intranet/global/scripts/cookies.js"></script>
    <script type="text/javascript" src="http://www.intranet.pppgroup.co.uk/intranet/global/scripts/favourites.js"></script>
    <script type="text/javascript" src="http://www.intranet.pppgroup.co.uk/intranet/global/scripts/jscss.js"></script>

    <style type="text/css">
	<!-- To use these styles on your table, add Class="TG" tothe table tag so it should look something like this <table class-"TG">  -->
        table.TG {
          width:auto;
          border-width: 1px 1px 1px 1px;
          border-spacing: 0px;
          border-style: none none none none;
          border-color: gray gray gray gray;
          border-collapse: collapse;
          background-color: white;
        }
        table.TG th {
          border-width: 1px 1px 1px 1px;
          padding: 0px 0px 0px 0px;
          border-style: inset inset inset inset;
          border-color: gray gray gray gray;
          background-color: #CCC;
          -moz-border-radius: 0px 0px 0px 0px;
        }
        table.TG td {
          border-width: 1px 1px 1px 1px;
          padding: 0px 0px 0px 0px;
          border-style: inset inset inset inset;
          border-color: gray gray gray gray;
          background-color: ;
          vertical-align:middle;
          -moz-border-radius: 0px 0px 0px 0px;
        }      
        table.TG td.TGRight {
        text-align: right;/Applications/XAMPP/xamppfiles/htdocs/auction/index.php
        }

		.floater-r{
		float:right;
		margin-left:0.5em;
		}
		
    </style>
    
																			   <script type="text/javascript">
																			   navLocation="Time out:Employee discounts:Tunbridge Wells area";
																			   </script>
																			   
																							   
																							   
																			<!----REDESIGN START----->
																			   
																			  							   
																			   
																			   <script type="text/javascript" src="newlook/fancybox/jquery.mousewheel-3.0.4.pack.js"></script>
																			   <script type="text/javascript" src="newlook/fancybox/jquery.fancybox-1.3.4.pack.js"></script>
																			   <link rel="stylesheet" type="text/css" href="newlook/fancybox/jquery.fancybox-1.3.4.css" media="screen" />
																			   
																			   <link href="newlook/newlook.css" rel="stylesheet" media="all" type="text/css" />
																			   <script type="text/javascript" src="newlook/newlook.js"></script>

																			<!----REDESIGN END-------->
<script>
$(document).ready(function() {
//$('button').click(function() {
//alert('button click');
$('#loadJquery').load('itemPriceJquery.php');
setInterval(function(){$('#loadJquery').load('itemPriceJquery.php')},6000);
//});
});
</script>
    </head>

<body class="col3">
<div id="loadJquery"></div>
  <div id="wrapper">
	<?php
    	include($_SERVER['DOCUMENT_ROOT']."/intranet/global/includes/page-header.php");
		// >>>> Be sure to change the path below to point to the correct local nav file or you will be loading the wrong menu !
    	include($_SERVER['DOCUMENT_ROOT']."/intranet/timeout/local-nav.html");
    ?>

  	<div class="presentational1"></div>
 	<div id="content">
    	<!-- >>>> This is the section with the page heading that appears at the top of the page -->
        
        <!-- Code to check we can get information items from the database -->
        <?php
            // includes
            include('includes/conf.php');
            include('includes/functions.php');            
            // open database connection
            $connection = mysql_connect($host, $user, $pass) or die ('Unable to connect!');            
            // select database
            mysql_select_db($db) or die ('Unable to select database!');            
		?>
		<!-- end of Code to check we can get information items from the database -->


        	<h1>Charity auction - 2013 </h1>
				

            <img src="images/gavel.gif" alt="Charity Auction" width="110" height=115 border="0" class="floater-r"/>
            <p>Our 2013 auction is now closed. Please return to this page momentarily, and final winning bidders and totals will be announced.</p>            
            <p><strong>Graham Thomas, Community Officer</strong></p>


 
     <!-- page last updated and footer includes start -->
     <!-- DONT EDIT BELOW THIS LINE  -->
	  <?php
      include($_SERVER['DOCUMENT_ROOT']."/intranet/global/includes/page-last-updated.php");
      include($_SERVER['DOCUMENT_ROOT']."/intranet/global/includes/footer.php");
      ?>
      <!-- page last updated and footer includes end -->
  </div>
</body>
</html>
