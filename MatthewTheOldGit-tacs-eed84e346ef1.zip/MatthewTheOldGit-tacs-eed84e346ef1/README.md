# TACS

## Deployment Procedure

### Prerequisites: Apache

  * Ensure that your Apache server has `.htaccess` file support.
  * Ensure that your Apache server has the `mod_rewrite` module enabled.

### Prerequisites: PHP

  * Set the `date.timezone` configuration value in your `php.ini` file to reflect your local timezone.
  * Set the `sendmail_path` configuration value in your `php.ini` file to reflect the path to the `sendmail` binary on your system.
  * Set the `post_max_size` configuration value in your `php.ini` file to a value 25% higher than the maximum possible combined size of an asset file upload and a consent file upload.
  * Set the `upload_max_filesize` configuration value in your `php.ini` file to a value 25% higher than the maximum possible combined size of an asset file upload and a consent file upload.
  * Set the `max_file_uploads` configuration value in your `php.ini` file to `5` or higher.
  * Set the `file_uploads` configuration value in your `php.ini` file to `On`.
  
### Prerequisites: MySQL

  * Create a new empty database for the application.

### Installation/Upgrade

The variable `$APP_DIR` refers to the directory the application is installed in. 

#### First-time Installation

  * Ensure that the `$APP_DIR/data/cache` and `$APP_DIR/data/tmp` directories are writable by the Web server user. Example commands for this on UNIX systems are `chown -R USERNAME.USERNAME DIR` and `chmod -R 775 DIR`.

  * Copy `$APP_DIR/config/autoload/local.php.dist` to `$APP_DIR/config/autoload/local.php`. Any changes to this file will be ignored by Git to enable per-developer configuration.
  
  * Update `$APP_DIR/config/autoload/local.php` with the correct `base_path` value for the application's `public` directory. For example, if the application is located at `http://server/intranet/apps/tacs`, set the base path to `/intranet/apps/tacs/public`.

  * Update `$APP_DIR/config/autoload/local.php` with the correct database credentials for the Doctrine ORM connection.

  * Update `$APP_DIR/config/autoload/local.php` with the correct `unix_socket` value if the MySQL socket is in a non-traditional place.
  
  * Update `$APP_DIR/config/autoload/local.php` with the correct `from_name` and `from_email` values for system-generated email.

  * Update `$APP_DIR/config/autoload/local.php` with the correct `uploads_path` values for file uploads. Ensure that the Web server user has read/write privileges to this directory. Example commands for this on UNIX systems are `chown -R USERNAME.USERNAME DIR` and `chmod -R 775 DIR`.

  * (For development environments, optional) Turn on ZDT by updating `$APP_DIR/config/autoload/local.php` and setting both `profiler` and `toolbar` to `true`. This is not recommended for production environments.

  * (For development environments, optional) Turn on detailed exception listings by updating `$APP_DIR/config/autoload/local.php` and setting both `display_not_found_reason` and `display_exceptions` to `true`. This is not recommended for production environments.
  
  * Create the database tables by running the command `php vendor/bin/doctrine-module orm:schema-tool:update --force` from the $APP_DIR directory.

#### Update or Upgrade

  * Update the database tables by running the command `php vendor/bin/doctrine-module orm:schema-tool:update --force` from the $APP_DIR directory.

### Maintenance

#### Orphan Files

The application allows users to upload files with forms. If a form submission is invalid, the file is held on the server in a temporary area (the `$APP_DIR/data/tmp` directory) until the errors are corrected. When a valid submission is received, the files are attached to the form submission and processed in the normal manner. There are two situations where these uploaded files may become "orphans": remain on the server consuming disk space without being attached to a valid submission.
 
   * The user abandons the invalid form submission.
   * The user corrects the invalid form submission but uploads a different file.
   
The application includes a cleanup routine which, on valid file upload and form submission, checks the temporary area for orphan files and automatically deletes those more than 4 days old. This cleanup routine is not driven by `cron` or any other system scheduler but by application usage. Administrators may wish to implement a separate, scheduled cleanup of these orphan files in the `$APP_DIR/data/tmp` directory. Note that any `.gitignore` files in this temporary area should be excluded from such scheduled cleanup. 

