<html>
<head>
<basefont face="Verdana">
<title>auction admin delete</title>
</head>

<body>

<!-- standard page header begins -->
<p>&nbsp;<p>

<table width="100%" cellspacing="0" cellpadding="5">
<tr>
    <td></td>
</tr>
<tr>
    <td bgcolor="#993333"><font size="-1" color="White">
    <b>AXA PPP Healthcare - Online Charity Auction</b></font>
    </td>
</tr>
</table>
<!-- standard page header ends -->

<?php
// includes
include('../includes/conf.php');
include('../includes/functions.php');

// check for record ID
if ((!isset($_GET['id']) || trim($_GET['id']) == '')) 
{ 
    die('Missing record ID!'); 
}

// open database connection
$connection = mysql_connect($host, $user, $pass) or die ('Unable to connect!');

// select database
mysql_select_db($db) or die ('Unable to select database!');

// generate and execute query
$DisplayedLotNumber = $_GET['id'];
$query = "DELETE FROM lots WHERE DisplayedLotNumber = '$DisplayedLotNumber'";
$result = mysql_query($query) or die ("Error in query: $query. " . mysql_error());

// close database connection
mysql_close($connection);

// print result
echo '<font size=4>Deletion successful.'; 
echo '<a href=list-actions.php>Go back to the Auction List</a>.</font>';
?>

<!-- standard page footer begins -->
<p>
<table width="100%" cellspacing="0" cellpadding="5">
<tr>
    <td align="center"><font size="-2">
    Few rights reserved. Visit  
    <a href="http://www.joining-dots.com"> 
    joining-dots</a> for more.</font></td>
</tr>
</table>
<!-- standard page footer ends -->

</body>
</html>