<?php
// 'Not sure what's supposed to be going on here ...
header("Cache-Control: no-cache, must-revalidate"); 
header("Expires: Mon, 26 Jul 1997 05:00:00 GMT");
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="en" xml:lang="en">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<meta name="description" content="Details of the annual intranet auction for 2010. The intranet auction returned in October 2010 and is in aid of Kent Air Ambulance." />
<title>Charity auction 2010</title>
<?php
$document_owner="graham.thomas@axa-ppp.co.uk";
$devolved_publisher="matthew.newman@joining-dots.com";
include($_SERVER['DOCUMENT_ROOT']."/intranet/global/includes/page-scripts-styles.html");
?>
<script type="text/javascript">
navLocation="Time out:Auction:";
</script>

<style type="text/css">
<!--
.style1 {
	color: #FF0000;
	font-weight: bold;
}
.style2 {color: #FF0000}
-->
</style>
</head>
<body class="col3">

<div id="wrapper">
<!--
<?php
include($_SERVER['DOCUMENT_ROOT']."/intranet/global/includes/page-header.php");
include($_SERVER['DOCUMENT_ROOT']."/intranet/timeout/sports-and-social/local-nav.html");
?>
-->

<div id="header">
<a href="/intranet/" rel="home" id="logo"><img src="/intranet/global/imgs/logo.gif" alt="healthnet" /></a>

</div>

<?php
include($_SERVER['DOCUMENT_ROOT']."/intranet/timeout/sports-and-social/local-nav.html");
?>

<div class="presentational1"></div>

<div id="content">

<!-- Code to check we can get information items from the database -->
<?php
// includes
include('includes/conf.php');
include('includes/functions.php');

// open database connection
$connection = mysql_connect($host, $user, $pass) or die ('Unable to connect!');

// select database
mysql_select_db($db) or die ('Unable to select database!');

?>
<!-- end of Code to check we can get information items from the database -->


<h1>Charity auction - 2010 </h1>

<p>Welcome to AXA PPP healthcare's 2010 charity auction.</p>

<p>Please browse through the items below and if you wish to make a bid, click the <em>Bid now</em> button beneath the item in question. 
NB - please state if you wish your bid to remain anonymous on the site.</p>

<p>All bids must be made in whole pounds - if your bid contains an odd number of pence it will be rounded up to the nearest pound.</p>

<p>Like eBay, bidding will be done for you by proxy. </p>
<p><strong>Always bid the maximum you are willing to pay</strong> for the item. This saves everyone's time and effort. </p>
<p>If your bid is the highest we will only ever keep it at &pound;1 more than the next highest bidder. Highest bidders at the end of the auction period will only ever pay &pound;1 more than the next highest bidder for their item. </p>
<p>In the case of two bids of exactly the same amount, the second bidder will be asked to bid again, if they want to. </p>

<p><strong>The auction closes at 11am on Monday 25th October.</strong> </p>

<p> All proceeds from the auction will be donated to our annual chosen charity, <br /> 
<a href="http://www.kentairambulance.co.uk">Kent Air Ambulance </a>.</p>

<!--
<p><strong>Where possible the site will be updated once a day (normally in the afternoon), to reflect the latest highest bids. </strong></p>
<p class="style1">Latest update - 27 Oct, 8.58am</p>
-->

<p><strong>Graham Thomas, Community Officer</strong></p>

<!-- start of a lot item -->
<?php
// generate and execute the database query

$query = "SELECT lots.LotNumber, DisplayedLotNumber, LotTitle, LotDescription, LotDonor, LotCurrentDisplayBid, BidderName, LotPicture FROM lots LEFT JOIN bids ON lots.LotCurrentActiveBid = bids.BidNumber ORDER BY lots.DisplayedLotNumber";

$result = mysql_query($query) or die ("Error in query: $query. " . mysql_error());

// if records present
if (mysql_num_rows($result) > 0)
{
      // iterate through resultset
      while($row = mysql_fetch_object($result))
      {
      ?>
      
<form action="submit.php" method="post">
<div>
<!-- <img alt="" src="images/odeon1.jpg" border="0" height=50px/> -->

<!-- show images on the joining-dots server -->
 <img alt="" src="images/<?php echo ($row->LotPicture); ?>" border="0" height=50px/> 

<!-- show images on the healthnet server -->
<!-- <img alt="" src="http://www.intranet.pppgroup.co.uk/intranet/timeout/sports-and-social/auction/images/2010<?php echo ($row->LotPicture); ?>" border="0" height=50px/>  -->

<!-- <img alt="" src="images/2009/lot1.jpg" border="0" />  -->
</div>
<input type="hidden" name="bidlot" value="<?php echo $row->DisplayedLotNumber; ?>" />	
<table>
<caption>
Lot <?php echo $row->DisplayedLotNumber; ?>: <?php echo ($row->LotTitle); ?> 
</caption>
<tr>
<th scope="row">Item</th>
<td><?php echo ($row->LotTitle); ?></td>
</tr>
<tr>
<th scope="row">Kindly donated by</th>
<td><?php echo($row->LotDonor); ?></td>
</tr>
<tr>
<th scope="row">Description</th>
<td><?php echo($row->LotDescription); ?></td>
</tr>
<tr>
<th scope="row">Highest bid </th>
<td>&pound;<?php echo((int)$row->LotCurrentDisplayBid); ?> <?php echo !empty($row->BidderName) ? '- ' . $row->BidderName : ''; ?></td>
</tr>
<tr>
<td colspan="2"><input id="formsubmit" type="submit" name="submit" value="Bid now!" /></td>
</tr>
</table>
<p>&nbsp;</p>  
</form>      
      <?php
      }
}
// if no records present
// display message
else
{
?>
      <font size="-1">No items currently available</font><p>
<?php
}

// close connection
mysql_close($connection);
?>

<!-- old code for showing lots -->
<!--
<form action="submit.php" method="post">
<div><img alt="" src="images/2009/lot1.jpg" border="0" /></div>
<input type="hidden" name="bidlot" value="lot 1: guitar lesson" />	
<table>
<caption>
Lot 1: Guitar experience 
</caption>
<tr>
<th scope="row">Item</th>
<td>One hour guitar session </td>
</tr>
<tr>
<th scope="row">Kindly donated by</th>
<td>Nick Harding</td>
</tr>
<tr>
<th scope="row">Description</th>
<td>60 minutes playing on a professional guitar rig with me as your �techy�. I�ll set up the rig by 17.30 in a meeting room and you can let your Clapton licks and Hendrix tricks transform the room into stadium filled with greasy-faced fans shouting something that you don�t quite understand. Tuition available, but your bid should reflect this! </td>
</tr>
<tr>
<th scope="row">Highest bid / bidder &pound;</th>
<td>Anonymous bidder - &pound;10 </td>
</tr>
<tr>
<td colspan="2"><input id="formsubmit" type="submit" name="submit" value="Bid now!" /></td>
</tr>
</table>
<p>&nbsp;</p>  
</form>
-->
<!-- end of old code for showing lots -->


</div>
<div class="presentational2"></div>


<div id="related-links">
<h2><b>Related</b> links</h2>
<ul>
<li><a href="http://www.kentairambulance.co.uk/">Kent Air Ambulance</a></li>
</ul>
</div>


<?php
include($_SERVER['DOCUMENT_ROOT']."/intranet/global/includes/page-last-updated.php");
include($_SERVER['DOCUMENT_ROOT']."/intranet/global/includes/footer.php");
?>
</div>
</body>
</html>