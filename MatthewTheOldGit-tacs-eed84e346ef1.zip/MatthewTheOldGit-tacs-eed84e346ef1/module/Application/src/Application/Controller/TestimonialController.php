<?php
namespace Application\Controller;

use Application\Entity\Asset as Asset;

class TestimonialController extends AssetController
{

    public function __construct()
    {
        return parent::__construct(Asset::TYPE_TESTIMONIAL);    
    }
        
}
