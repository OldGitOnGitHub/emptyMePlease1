<?php
namespace Application\Mail\Transport;

use Zend\Mail\Transport\Sendmail as ZendSendmail;
use Zend\Mail\Message as ZendMessage;
use Zend\Mail\Transport\TransportInterface;

/**
 * Add mark (*) for all required elements inside a form.
 */
class Sendmail extends ZendSendmail implements TransportInterface
{

    /*
     * Send a message
     *
     * @param  \Zend\Mail\Message $message
     */
    public function send(ZendMessage $message)
    {
        $to      = $this->prepareRecipients($message);
        $subject = $this->prepareSubject($message);
        $body    = $this->prepareBody($message);
        $headers = $this->prepareHeaders($message);
        $params  = $this->prepareParameters($message);

        // On *nix platforms, we need to replace \r\n with \n
        // sendmail is not an SMTP server, it is a unix command - it expects LF
        if (!$this->isWindowsOs()) {
            $to      = str_replace("\r\n", "\n", $to);
            $subject = str_replace("\r\n", "\n", $subject);
            $body    = str_replace("\r\n", "\n", $body);
            $headers = str_replace("\r\n", "\n", $headers);
        }

        call_user_func($this->callable, $to, $subject, $body, $headers, null);
    }
}