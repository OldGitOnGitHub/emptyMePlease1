<?php

// includes
include('conf.php');

// open database connection
$connection = mysql_connect($host, $user, $pass) or die ('Unable to connect!');

// select database
mysql_select_db($db) or die ('Unable to select database!');





$policySearch = trim($_GET["policySearch"]);


if ($policySearch == "1") {


$policyName = $_GET["policyName"];
$ipAddress = $_GET["ipAddress"];
$userID = $_GET["userID"];

        $currentFile = $_SERVER["PHP_SELF"];
$ipAddress = $_SERVER["REMOTE_ADDR"];
$date = date("Y/m/d");
$escapedQuery = mysql_escape_string($query);
        // generate and execute query
        $activityQuery = "INSERT INTO activityLog(user, page, notes, query, errors, dateExecuted, ipAddress) VALUES('$userID', '$currentFile', 'Policy search for ".$policyName."', '$escapedQuery', '$SQLerror', '$date', '$ipAddress')";

        $activityResult = mysql_query($activityQuery) or die ("Error in query: $query. " . mysql_error());
        
        
 ?>   
 
 <script src="scripts/jquery-1.10.1.min.js" type="text/javascript"></script>
    
<script>
        
$(document).ready(function(){
     
/***********UPDATE SEARCH COUNT************/
var user = $.trim($("p.userInfo").attr("data"));
var time = (new Date).getTime();
$(".searchCount #count").load(encodeURI("searchCount.php?userID="+user+"&time="+time));
/******************************************/
 

});

</script>
        
<?php 
} 
?>
