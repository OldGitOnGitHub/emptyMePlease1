	<?php

// includes
include('conf.php');

// open database connection
$connection = mysql_connect($host, $user, $pass) or die ('Unable to connect!');

// select database
mysql_select_db($db) or die ('Unable to select database!');

$ID = $_GET["ID"];

// generate and execute query
if($ID==1){
$query = "SELECT ID FROM CANCER_companies WHERE axaGroup='1'";
$result = mysql_query($query) or die ("Error in query: $query. " . mysql_error());
$i ="0";
      while($row = mysql_fetch_object($result))	{
	if($i=="0"){
	$axaGroup = $row->ID;
	} else {
	$axaGroup = $axaGroup.",".$row->ID;
	}
	$i = $i+1;
}


// generate and execute query
$query = "SELECT * FROM CANCER_policies WHERE companyID IN ($axaGroup)";}
else{
$query = "SELECT * FROM CANCER_policies WHERE companyID='".$ID."'";	
}

$result = mysql_query($query) or die ("Error in query: $query. " . mysql_error());
// if records present
if (mysql_num_rows($result) > 0)
{
?>
	<select class="competitorCancerPolicies CancerPolicies"><option>Select policy</option>
<?php
      // iterate through resultset
      // print title with links to edit and delete scripts
      while($row = mysql_fetch_object($result))
      {
      ?>
		<option value="<?php echo $row->ID; ?>" class="viable"><?php echo $row->name; ?></option>
	<?php
	}
?>
	</select>
<?php
}


$query = "SELECT ID FROM CANCER_companies WHERE axaGroup='1'";
$result = mysql_query($query) or die ("Error in query: $query. " . mysql_error());
$i ="0";
      while($row = mysql_fetch_object($result))	{
	if($i=="0"){
	$axaGroup = $row->ID;
	} else {
	$axaGroup = $axaGroup.",".$row->ID;
	}
	$i = $i+1;
}


// generate and execute query
$query = "SELECT * FROM CANCER_policies WHERE companyID IN ($axaGroup)";

$result = mysql_query($query) or die ("Error in query: $query. " . mysql_error());
// if records present
if (mysql_num_rows($result) > 0)
{
?>
	<select class="pppCancerPolicies CancerPolicies"><option>Select policy</option>
<?php
      // iterate through resultset
      // print title with links to edit and delete scripts
      while($row = mysql_fetch_object($result))
      {
      ?>
		<option value="<?php echo $row->ID; ?>"><?php echo $row->name; ?></option>
	<?php
	}
?>
	</select>
<?php
}
?>