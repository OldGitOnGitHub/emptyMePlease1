<?php
                // database configuration
                $host = 'localhost';
                $user = 'joining1_auser';
                $pass = '@uct10n!';
                $db = 'joining1_auction_2011';
                
              //  $host = 'localhost';
               // $user = 'root';
                //$pass = '';
                //$db = 'auction_2011';
                
          /*      
	$host = 'healthnet-mysql.axa-uk.intraxa';
	$user = 'HealthnetUser';
	$pass = 'PPPphp55';
	$db = 'auction_2011';
	*/
	
	
	// default contact person
	$def_contact = 'Graham Thomas (graham.thomas@axa-ppp.co.uk)';

                
                
                //auction end time
                
                $endTime = '2013-05-29 15:00:00'; 
                ?>

