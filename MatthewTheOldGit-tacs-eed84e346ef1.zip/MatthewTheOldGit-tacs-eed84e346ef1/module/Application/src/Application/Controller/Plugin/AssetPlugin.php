<?php
namespace Application\Controller\Plugin;

use Zend\Mvc\Controller\Plugin\AbstractPlugin;
use Application\Entity\Asset as Asset;

class AssetPlugin extends AbstractPlugin
{
    private $planTypes;

    private $assetMetadata;

    private $statusTypes;
    
    public function __construct()
    {
        $this->setPlanTypes(array(
            '1' => 'Corporate', 
            '2' => 'Individual', 
            '3' => 'Intermediary',
            '4' => 'SME',
            '5' => 'International',
            '6' => 'Staff',
            '7' => 'Other',
        ));

        $this->setStatusTypes(array(
            Asset::STATUS_ACTIVE => 'Active',
            Asset::STATUS_INACTIVE => 'Archived',
        ));
        
        $this->setAssetMetadata(array(
            Asset::TYPE_TESTIMONIAL => array(
                'route' => 'testimonials',
                'labels' => array('Testimonial', 'Testimonials'),
                'status' => $this->getStatusTypes()
            ),
            Asset::TYPE_CASESTUDY => array(
                'route' => 'case-studies',
                'labels' => array('Case Study', 'Case Studies'),
                'status' => $this->getStatusTypes()
            ),
            Asset::TYPE_VIDEO => array(
                'route' => 'videos',
                'labels' => array('Video', 'Videos'),
                'status' => $this->getStatusTypes()
            ),
        ));  
    
    }
    
    public function getPlanTypes()
    {
        return $this->planTypes;
    }

    public function setPlanTypes($value)
    {
        $this->planTypes = $value;
    }

    public function getPlanTypeName($id)
    {
        return $this->planTypes[$id];
    }
    
    public function getAssetMetadata()
    {
        return $this->assetMetadata;
    }

    public function setAssetMetadata($value)
    {
        $this->assetMetadata = $value;
    }

    public function getAssetMetadataByType($type)
    {
        return $this->assetMetadata[$type];
    }

    public function getStatusTypes()
    {
        return $this->statusTypes;
    }

    public function setStatusTypes($value)
    {
        $this->statusTypes = $value;
    }
    
}