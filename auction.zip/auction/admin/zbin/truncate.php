
<html>
<head></head>
<body>
<?php
            // includes
            include('includes/conf.php');
            include('includes/functions.php');            
            // open database connection
            $connection = mysql_connect($host, $user, $pass) or die ('Unable to connect!');            
            // select database
            mysql_select_db($db) or die ('Unable to select database!');            


     // check for LotNumber
     if ((!isset($_GET['table']) || trim($_GET['table']) == '')) 
     { 
         die('Missing table!'); 
     } else {
        $table = $_GET['table'];
     }

// generate and execute the database query
 
$query = "TRUNCATE TABLE $table";
$result = mysql_query($query) or die ("Error in query: $query. " . mysql_error());

echo("<h1>".$table." table cleared.</h1>");

            // close connection
            mysql_close($connection);
            ?>
</body>
</html>

