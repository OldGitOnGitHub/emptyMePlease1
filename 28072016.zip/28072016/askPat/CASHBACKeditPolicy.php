<!DOCTYPE html>
<meta http-equiv="X-UA-Compatible" content="IE=edge" />
<html>
<head>
<?php $ID = $_GET["ID"]; ?>

<title>Edit policy <?php echo $ID;?></title>

<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.css">
<link rel="stylesheet" type="text/css" href="styles.css">

<script src="scripts/jquery-1.10.1.min.js" type="text/javascript"></script>
<script src="ckeditor4.5.9/ckeditor.js" type="text/javascript"></script>
<script>
$(document).ready(function(){

CKEDITOR.replace( 'ckeditor',
    {
        toolbar : 'Basic',
        uiColor : '#9AB8F3'
    });

});
</script>
</head>
<body class="formPage editPolicy">

<?php
if (!$_POST['submit'])
{

// includes
include('conf.php');

// open database connection
$connection = mysql_connect($host, $user, $pass) or die ('Unable to connect!');

// select database
mysql_select_db($db) or die ('Unable to select database!');




        // generate and execute query
        $query = "SELECT * FROM CASHBACK_policies WHERE ID ='".$ID."'";


        $result = mysql_query($query) or die ("Error in query: $query. " . mysql_error());
// if records present
if (mysql_num_rows($result) > 0)
{

      while($row = mysql_fetch_object($result))
      {
?>
<h1>Edit policy</h1>
<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST">
<input name="ID" type="hidden" value="<?php echo $row->ID ; ?>" >
<label>name</label><input name="name" type="text" value="<?php echo $row->name; ?>"/>
<?php
// generate and execute query
$Dquery = "SELECT ID, name FROM CASHBACK_companies ORDER BY ID DESC";

$Dresult = mysql_query($Dquery) or die ("Error in query: $Dquery. " . mysql_error());

// if records present
if (mysql_num_rows($Dresult) > 0)
{?>
<label>Company</label>
<select name="companyID">
<?php
      // iterate through resultset
      // print title with links to edit and delete scripts
      while($Drow = mysql_fetch_object($Dresult))
      {
      ?>
      <option value="<?php echo $Drow->ID; ?>" <?php if ($Drow->ID==$row->companyID){ ?>selected="selected"<?php } ?>><?php echo $Drow->name; ?></option> 
      <?php
      }
      ?>
</select>
<?php
}
?>
<h4>Every day benefit</h4>
<label>Dental treatment</label><textarea class="ckeditor" name="Benefit1" rows="2" cols="8"><?php echo $row->Benefit1; ?></textarea>
<label>Dental accident</label><textarea class="ckeditor" name="Benefit2" rows="2" cols="8"><?php echo $row->Benefit2; ?></textarea>
<label>Optical benefit</label><textarea class="ckeditor" name="Benefit3" rows="2" cols="8"><?php echo $row->Benefit3; ?></textarea>
<label>Physiotherapy, osteopath  chiropractic benefit</label><textarea class="ckeditor" name="Benefit4" rows="2" cols="8"><?php echo $row->Benefit4; ?></textarea>
<label>Acupuncture and homeopathy benefit</label><textarea class="ckeditor" name="Benefit5" rows="2" cols="8"><?php echo $row->Benefit5; ?></textarea>
<label>Chiropody and podiatry</label><textarea class="ckeditor" name="Benefit6" rows="2" cols="8"><?php echo $row->Benefit6; ?></textarea>
<label>Hearing aid</label><textarea class="ckeditor" name="Benefit7" rows="2" cols="8"><?php echo $row->Benefit7; ?></textarea>
<label>GP services</label><textarea class="ckeditor" name="Benefit8" rows="2" cols="8"><?php echo $row->Benefit8; ?></textarea>
<label>Prescription charges</label><textarea class="ckeditor" name="Benefit9" rows="2" cols="8"><?php echo $row->Benefit9; ?></textarea>
<h4>Specialist</h4>
<label>Specialist consultation fees (and diagnostic tests)</label><textarea class="ckeditor" name="Benefit10" rows="2" cols="8"><?php echo $row->Benefit10; ?></textarea>
<label>Diagnostic scans</label><textarea class="ckeditor" name="Benefit11" rows="2" cols="8"><?php echo $row->Benefit11; ?></textarea>
<label>Specialist allergy testing</label><textarea class="ckeditor" name="Benefit12" rows="2" cols="8"><?php echo $row->Benefit12; ?></textarea>
<label>Occupational therapy</label><textarea class="ckeditor" name="Benefit13" rows="2" cols="8"><?php echo $row->Benefit13; ?></textarea>
<label>Health check / lifestyle assessment benefit</label><textarea class="ckeditor" name="Benefit14" rows="2" cols="8"><?php echo $row->Benefit14; ?></textarea>
<h4>Hospital benefits</h4>
<label>Hospital in-patient</label><textarea class="ckeditor" name="Benefit15" rows="2" cols="8"><?php echo $row->Benefit15; ?></textarea>
<label>Intensive care hospital in-patient</label><textarea class="ckeditor" name="Benefit16" rows="2" cols="8"><?php echo $row->Benefit16; ?></textarea>
<label>Day surgery</label><textarea class="ckeditor" name="Benefit17" rows="2" cols="8"><?php echo $row->Benefit17; ?></textarea>
<label>Recuperation</label><textarea class="ckeditor" name="Benefit18" rows="2" cols="8"><?php echo $row->Benefit18; ?></textarea>
<label>Home care money</label><textarea class="ckeditor" name="Benefit19" rows="2" cols="8"><?php echo $row->Benefit19; ?></textarea>
<label>World wide hospital cover</label><textarea class="ckeditor" name="Benefit20" rows="2" cols="8"><?php echo $row->Benefit20; ?></textarea>
<h4>Child birth</h4>
<label>Childbirth benefit</label><textarea class="ckeditor" name="Benefit21" rows="2" cols="8"><?php echo $row->Benefit21; ?></textarea>
<label>Multiple births - twins</label><textarea class="ckeditor" name="Benefit22" rows="2" cols="8"><?php echo $row->Benefit22; ?></textarea>
<label>Multiple births - triplets</label><textarea class="ckeditor" name="Benefit23" rows="2" cols="8"><?php echo $row->Benefit23; ?></textarea>
<h4>Addidental benefit</h4>
<label>Accidental death benefit</label><textarea class="ckeditor" name="Benefit24" rows="2" cols="8"><?php echo $row->Benefit24; ?></textarea>
<label>Accidental loss of sight benefit</label><textarea class="ckeditor" name="Benefit25" rows="2" cols="8"><?php echo $row->Benefit25; ?></textarea>
<label>Accidental loss of hearing benefit</label><textarea class="ckeditor" name="Benefit26" rows="2" cols="8"><?php echo $row->Benefit26; ?></textarea>
<label>Permanent disability</label><textarea class="ckeditor" name="Benefit27" rows="2" cols="8"><?php echo $row->Benefit27; ?></textarea>
<h4>Additional cover</h4>
<label>Medical appliances</label><textarea class="ckeditor" name="Benefit28" rows="2" cols="8"><?php echo $row->Benefit28; ?></textarea>
<label>European cover</label><textarea class="ckeditor" name="Benefit29" rows="2" cols="8"><?php echo $row->Benefit29; ?></textarea>
<label>Health club concession access</label><textarea class="ckeditor" name="Benefit30" rows="2" cols="8"><?php echo $row->Benefit30; ?></textarea>
<label>Expert help lines</label><textarea class="ckeditor" name="Benefit31" rows="2" cols="8"><?php echo $row->Benefit31; ?></textarea>
<h4>Cancer support</h4>
<label>Second opinion cancer consultation cover</label><textarea class="ckeditor" name="Benefit32" rows="2" cols="8"><?php echo $row->Benefit32; ?></textarea>
<label>Cash payment on first diagnosis of non-melanoma cancer</label><textarea class="ckeditor" name="Benefit33" rows="2" cols="8"><?php echo $row->Benefit33; ?></textarea>
<label>Cash payment on first diagnosis of cancer</label><textarea class="ckeditor" name="Benefit34" rows="2" cols="8"><?php echo $row->Benefit34; ?></textarea>
<label>Cover for licensed cancer drugs not available to you on the NHS when you have been diagnosed with cancer</label><textarea class="ckeditor" name="Benefit35" rows="2" cols="8"><?php echo $row->Benefit35; ?></textarea>


<input type="submit" value="Update" name="submit">
</form>
<?php

	}
}
// close connection
mysql_close($connection);
?>



<?php
}
else
{
    // includes
    include('conf.php');

    // set up error list array
    $errorList = array();
    
$ID = $_POST['ID'];
$name = $_POST['name'];
$companyID = $_POST['companyID'];
$Benefit1 = $_POST['Benefit1'];
$Benefit2 = $_POST['Benefit2'];
$Benefit3 = $_POST['Benefit3'];
$Benefit4 = $_POST['Benefit4'];
$Benefit5 = $_POST['Benefit5'];
$Benefit6 = $_POST['Benefit6'];
$Benefit7 = $_POST['Benefit7'];
$Benefit8 = $_POST['Benefit8'];
$Benefit9 = $_POST['Benefit9'];
$Benefit10 = $_POST['Benefit10'];
$Benefit11 = $_POST['Benefit11'];
$Benefit12 = $_POST['Benefit12'];
$Benefit13 = $_POST['Benefit13'];
$Benefit14 = $_POST['Benefit14'];
$Benefit15 = $_POST['Benefit15'];
$Benefit16 = $_POST['Benefit16'];
$Benefit17 = $_POST['Benefit17'];
$Benefit18 = $_POST['Benefit18'];
$Benefit19 = $_POST['Benefit19'];
$Benefit20 = $_POST['Benefit20'];
$Benefit21 = $_POST['Benefit21'];
$Benefit22 = $_POST['Benefit22'];
$Benefit23 = $_POST['Benefit23'];
$Benefit24 = $_POST['Benefit24'];
$Benefit25 = $_POST['Benefit25'];
$Benefit26 = $_POST['Benefit26'];
$Benefit27 = $_POST['Benefit27'];
$Benefit28 = $_POST['Benefit28'];
$Benefit29 = $_POST['Benefit29'];
$Benefit30 = $_POST['Benefit30'];
$Benefit31 = $_POST['Benefit31'];
$Benefit32 = $_POST['Benefit32'];
$Benefit33 = $_POST['Benefit33'];
$Benefit34 = $_POST['Benefit34'];
$Benefit35 = $_POST['Benefit35'];

    	

    // check for errors
    // if none found...
    if (sizeof($errorList) == 0)
    {
        // open database connection
        $connection = mysql_connect($host, $user, $pass) or die ('Unable to connect!');

        // select database
        mysql_select_db($db) or die ('Unable to select database!');

        // generate and execute query
        $query = "UPDATE CASHBACK_policies SET 
					name ='$name', 
					companyID ='$companyID', 
					Benefit1 ='$Benefit1',
					Benefit2 ='$Benefit2',
					Benefit3 ='$Benefit3',
					Benefit4 ='$Benefit4',
					Benefit5 ='$Benefit5',
					Benefit6 ='$Benefit6',
					Benefit7 ='$Benefit7',
					Benefit8 ='$Benefit8',
					Benefit9 ='$Benefit9',
					Benefit10 ='$Benefit10',
					Benefit11 ='$Benefit11',
					Benefit12 ='$Benefit12',
					Benefit13 ='$Benefit13',
					Benefit14 ='$Benefit14',
					Benefit15 ='$Benefit15',
					Benefit16 ='$Benefit16',
					Benefit17 ='$Benefit17',
					Benefit18 ='$Benefit18',
					Benefit19 ='$Benefit19',
					Benefit20 ='$Benefit20',
					Benefit21 ='$Benefit21',
					Benefit22 ='$Benefit22',
					Benefit23 ='$Benefit23',
					Benefit24 ='$Benefit24',
					Benefit25 ='$Benefit25',
					Benefit26 ='$Benefit26',
					Benefit27 ='$Benefit27',
					Benefit28 ='$Benefit28',
					Benefit29 ='$Benefit29',
					Benefit30 ='$Benefit30', 
					Benefit31 ='$Benefit31',
					Benefit32 ='$Benefit32',
					Benefit33 ='$Benefit33',
					Benefit34 ='$Benefit34',
					Benefit35 ='$Benefit35',
					dateModified ='".date('Y-m-d H:i:s', time())."' 								
					 WHERE ID ='".$ID."'";
        

        $result = mysql_query($query) or die ("Error in query: $query. " . mysql_error());

/**********ACTIVITY LOG FUNCTIONALITY**********/
/*
        $currentFile = $_SERVER["PHP_SELF"];
		$ipAddress = $_SERVER["REMOTE_ADDR"];
		$date = date("Y/m/d");
		$escapedQuery = mysql_escape_string($query);
        // generate and execute query
        $activityQuery = "INSERT INTO activityLog(user, page, notes, query, errors, dateExecuted, ipAddress) VALUES('$userID', '$currentFile', 'Attempt to edit cashback policy ".$ID.".', '$escapedQuery', '$SQLerror', '$date', '$ipAddress')";

        $activityResult = mysql_query($activityQuery) or die ("Error in query: $query. " . mysql_error());
*/
/**********************************************/

        // print result
        echo '<h2>Update successful.</h2>';
?>
<script src="scripts/jquery-1.10.1.min.js" type="text/javascript"></script>
 
<script>
$(document ).ready(function() {
parent.location.reload();
});
</script>
<?php
        // close database connection
        mysql_close($connection);
    }
    else
    {
    
    
        // errors found
        // print as list
        echo '<font size=-1>The following errors were encountered:'; 
        echo '<br>';
        echo '<ul>';
        for ($x=0; $x<sizeof($errorList); $x++)
        {
            echo "<li>$errorList[$x]";
        }
        echo '</ul></font><br /><a href=&amp;javascript: history.go(-1)&amp;>Back</a>';
    }
}
?>
</body>
</html>