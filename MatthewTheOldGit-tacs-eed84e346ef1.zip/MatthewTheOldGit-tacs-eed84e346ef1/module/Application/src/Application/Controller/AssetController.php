<?php
namespace Application\Controller;

use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;
use DoctrineModule\Stdlib\Hydrator\DoctrineObject as DoctrineHydrator;
use Application\Entity\Asset as Asset;
use Application\Entity\Category as Category;
use Application\Entity\Activity as Activity;
use Zend\Form\Annotation\AnnotationBuilder;
use Application\Form\ConfirmationForm as ConfirmationForm;
use Zend\Filter\File\Rename;
use Zend\Mail\Message;
use Zend\Mime\Message as MimeMessage;
use Zend\Mime\Part;
use Zend\Mime\Mime;
use Application\Mail\Transport\Sendmail;
use Zend\Mail\Transport\Smtp as SmtpTransport;
use Zend\Mail\Transport\SmtpOptions;

class AssetController extends AbstractActionController
{

    private $type;

    public function __construct($type)
    {
        return $this->setType($type); 
    }
    
    public function getType()
    {
        return $this->type;
    }

    public function setType($value)
    {
        $this->type = $value;
    }   

    public function indexAction()
    {        
        $entityManager = $this->getServiceLocator()->get('Doctrine\ORM\EntityManager');
        $assets = $entityManager->getRepository('\Application\Entity\Asset')
                                ->findBy(array('status' => Asset::STATUS_ACTIVE, 'type' => $this->getType()), array('created' => 'DESC'));   
        $view = new ViewModel(array(
            'assets' => $assets,
            'title' => ucwords($this->getEntityFriendlyName($this->getType())) . ' List', 
            'route' => $this->getRouteName($this->getType())
        ));
        $view->setTemplate('application/asset/index.phtml');
        return $view;
    }
    
    public function displayAction()
    {
        $entityManager = $this->getServiceLocator()->get('Doctrine\ORM\EntityManager');
        $hydrator = new DoctrineHydrator($entityManager);
        $request = $this->getRequest();        
        
        $id = (int) $this->params()->fromRoute('id', 0);
        if (!$id) {
            return $this->redirect()->toRoute($this->getRouteName($this->getType()));
        }
        
        $asset = $entityManager->getRepository('Application\Entity\Asset')
                               ->find($id);          
        if (!$asset) {
            $this->flashMessenger()
                 ->setNamespace('error')
                 ->addMessage('The requested ' . strtolower($this->getEntityFriendlyName($this->getType())) . ' could not be found.');
            return $this->redirect()->toRoute($this->getRouteName($this->getType()));                 
        } 


        $audits = $entityManager->getRepository('\Application\Entity\Activity')
                                    ->findBy(array('type' => Activity::TYPE_AUDIT, 'assetId' => $asset->getId()), array('created' => 'DESC'));   
        $asset->setAudits($audits); 
 
        $view = new ViewModel(array(
            'asset' => $asset, 
            'assetPlugin' => $this->assetPlugin(), 
            'title' => ucwords($this->getEntityFriendlyName($this->getType())) . ' Details', 
            'route' => $this->getRouteName($this->getType())
        ));
        $view->setTemplate('application/asset/display.phtml');
        return $view;
    }
    
    // common action for create/update operations
    // saves valid files even with invalid form submission using PRG
    // uses common save views
    public function saveAction()
    {        
        // get hydrator and entity manager
        $entityManager = $this->getServiceLocator()->get('Doctrine\ORM\EntityManager');
        $hydrator = new DoctrineHydrator($entityManager);
        $request = $this->getRequest();        
        $id = (int) $this->params()->fromRoute('id', 0);
        
        // check for id in route
        // if present, update operation
        // if absent, create operation
        if ($id) {
            $asset = $entityManager->getRepository('\Application\Entity\Asset')
                                   ->find($id);          
            if (!$asset) {
                $this->flashMessenger()
                     ->setNamespace('error')
                     ->addMessage('The requested ' . strtolower($this->getEntityFriendlyName($this->getType())) . ' could not be found.');
                return $this->redirect()->toRoute($this->getRouteName($this->getType()));                 
            } 
            if ($asset->getStatus() == Asset::STATUS_INACTIVE) {
                $this->flashMessenger()
                     ->setNamespace('error')
                     ->addMessage('The requested ' . strtolower($this->getEntityFriendlyName($this->getType())) . ' has been archived and is no longer available.');
                return $this->redirect()->toRoute($this->getRouteName($this->getType()));                 
            } 
            
            $originalConsentFile = $asset->getConsentFile();
            $originalAssetFile = $asset->getAssetFile();
            $originalMemberStatus = $asset->getMemberStatus();
        } else {
            $asset = new Asset();        
            $originalConsentFile = null;
            $originalAssetFile = null;
            $originalMemberStatus = null;
        }
        
        // build form from entity
        $builder = new AnnotationBuilder($entityManager);
        $form = $builder->createForm($asset);
        
        // manual fix to inject the object manager into the ObjectSelect element
        $form->get('categories')->setOptions(array('object_manager' => $entityManager));
        
        // bind form and entity
        $form->setHydrator($hydrator);
        $form->bind($asset);
        
        // set options for category list 
        $categoryHydrator = new DoctrineHydrator($entityManager, 'Category');
        $categories = $entityManager->getRepository('\Application\Entity\Category')
                                    ->findBy(array('status' => Asset::STATUS_ACTIVE));
        foreach ($categories as $c) {
            $categoryId = $c->getId();
            $categoryOptions[$categoryId] = $c->getTitle();
        }
        $form->get('categories')->setValueOptions($categoryOptions);
        
        $form->get('planType')->setValueOptions($this->assetPlugin()->getPlanTypes());        
        
        // set the mandatory asset data field depending on the asset type and operation type
        $form = $this->setRequiredAssetFields($form, $id);
        $form = $this->setAdditionalValidatorsOnAssetFields($form, $id);

        $uploadedConsentFile = null;
        $uploadedAssetFile = null;

        // clear existing categories
        $asset->getCategories()->clear();     

        // get location for temporary upload directory from RenameUpload filter
        foreach($form->getInputFilter()->get('consentFile')->getFilterChain()->getFilters() as $filter) {
            if (is_a($filter, 'Zend\Filter\File\RenameUpload')) {
                $options = $filter->getOptions();
                $location = $options['target'];
            }
        }
        
        // use PRG plugin to save uploaded files even on invalid form submissions
        // TODO: two leaks occur with this setup
        // a. user uploads a valid file with an invalid form, then abandons it
        // b. user uploads a valid file with an invalid form, then corrects it but uploads a new file
        // in both cases, the uploaded files become orphans in data/tmp and consume unnecessary disk space
        $prg = $this->fileprg($form);
        if ($prg instanceof \Zend\Http\PhpEnvironment\Response) {
            return $prg; 
        } else if (is_array($prg)) {
            if ($form->isValid()) {  

                // set default values 
                $asset->setType($this->getType());
                $asset->setStatus(Asset::STATUS_ACTIVE);
                
                // if there is a change in member status
                // set member status updated date to today
                // if original member status is null
                // this is a new record, set member status updated to created date
                if (is_null($originalMemberStatus)) {                
                    $asset->setMemberStatusUpdated($asset->getCreated());
                } else if (!is_null($originalMemberStatus) && $asset->getMemberStatus() != $originalMemberStatus) {
                    $asset->setMemberStatusUpdated(new \DateTime);
                }
                
                // check for the optional consent file
                // if absent, set to null to avoid array/string conversion errors
                // if present, set to dummy string status (to be reset after successful upload)
                $consentFile = $asset->getConsentFile(); 
                if (is_array($consentFile)) {
                    $asset->setConsentFile('UPLOAD_ERROR');
                } else {
                    $asset->setConsentFile($originalConsentFile);              
                }              
                $assetFile = $asset->getAssetFile();
                if (is_array($assetFile)) {
                    $asset->setAssetFile('UPLOAD_ERROR');
                } else {
                    $asset->setAssetFile($originalAssetFile);                              
                }
                
                // validate and persist record
                try {
                    $entityManager->persist($asset);
                    $entityManager->flush();                      

                    // if id absent, create operation
                    // write audit record with created date
                    if (!$id) {
                        $activity = new Activity();
                        $activity->setAssetId($asset->getId());
                        $activity->setUserName($asset->getOwnerName());
                        $activity->setUserEmail($asset->getOwnerEmail());
                        $activity->setCreated($asset->getCreated());
                        $activity->setType(Activity::TYPE_AUDIT);
                        $activity->setSourceIpAddress($request->getServer('REMOTE_ADDR'));
                        $entityManager->persist($activity);
                        $entityManager->flush();
                    }
                    
                    // transfer files and update record
                    if (is_array($consentFile)) {
                        $consentFilename = $this->handleUpload($consentFile, 'consent', $asset->getId(), $originalConsentFile);
                        $asset->setConsentFile($consentFilename);                  
                    }
                    
                    if (is_array($assetFile)) {
                        $assetFilename = $this->handleUpload($assetFile, 'asset', $asset->getId(), $originalAssetFile);
                        $asset->setAssetFile($assetFilename);                  
                    }
                    
                    $entityManager->persist($asset);
                    $entityManager->flush();                      
                    
                } catch (Exception $e) {
                    $entityManager->rollback();
                    throw $e;
                }
                
                if ($id) {
                    $message = 'The selected ' . strtolower($this->getEntityFriendlyName($this->getType())) . ' was successfully updated.';
                } else {
                    $message = 'The ' . strtolower($this->getEntityFriendlyName($this->getType())) . ' was successfully created.';           
                }                
                $this->flashMessenger()
                     ->setNamespace('success')
                     ->addMessage($message);
                     
                // check for and remove orphan files
                $deletedFilesCount = $this->removeOrphanFiles($location);
                if ($deletedFilesCount > 0) {
                    $this->flashMessenger()
                         ->setNamespace('info')
                         ->addMessage($deletedFilesCount . ' temporary file(s) were successfully cleaned up.');                
                }
                
                return $this->redirect()->toRoute($this->getRouteName($this->getType()));
            } else {   
                $consentFileErrors = $form->get('consentFile')->getMessages();
                if (empty($consentFileErrors)) {
                    $uploadedConsentFile = $form->get('consentFile')->getValue();
                }          
                $assetFileErrors = $form->get('assetFile')->getMessages();
                if (empty($assetFileErrors)) {
                    $uploadedAssetFile = $form->get('assetFile')->getValue();
                }   
                $messages = $form->getMessages();
            }    

        }
        
        if ($id) {
            $title = 'Modify ' . ucwords($this->getEntityFriendlyName($this->getType()));
        } else {
            $title = 'Add ' . ucwords($this->getEntityFriendlyName($this->getType()));                
        }

        $view = new ViewModel(array(
            'form' => $form, 
            'id' => $asset->getId(), 
            'title' => $title, 
            'action' => 'save', 
            'route' => $this->getRouteName($this->getType()),
            'assetFile' => $asset->getAssetFile(), 
            'consentFile' => $asset->getConsentFile(), 
            'uploadedConsentFile' => $uploadedConsentFile,
            'uploadedAssetFile' => $uploadedAssetFile,
        ));
        $view->setTemplate('application/asset/save.phtml');
        return $view;
    }
    
    
    public function archiveAction() 
    {
        $id = (int) $this->params()->fromRoute('id', 0);
        if (!$id) {
            return $this->redirect()->toRoute($this->getRouteName($this->getType()));
        }

        $entityManager = $this->getServiceLocator()->get('Doctrine\ORM\EntityManager');
        $asset = $entityManager->getRepository('\Application\Entity\Asset')
                               ->find($id);
        if (!$asset) {
            $this->flashMessenger()
                 ->setNamespace('error')
                 ->addMessage('The requested ' . strtolower($this->getEntityFriendlyName($this->getType())) . ' could not be found.');
            return $this->redirect()->toRoute($this->getRouteName($this->getType()));                 
        }        
        if ($asset->getStatus() == Asset::STATUS_INACTIVE) {
            $this->flashMessenger()
                 ->setNamespace('error')
                 ->addMessage('The requested ' . strtolower($this->getEntityFriendlyName($this->getType())) . ' has been archived and is no longer available.');
            return $this->redirect()->toRoute($this->getRouteName($this->getType()));                 
        } 
        
        $builder = new AnnotationBuilder();
        $form = $builder->createForm(new ConfirmationForm());
        $request = $this->getRequest();        
        
        if ($request->isPost()) {
            $form->setData($request->getPost());
            if ($form->isValid()) {
                $validatedData = $form->getData();
                if ($validatedData['confirmation'] == '1') {
                    $asset->setStatus(Asset::STATUS_INACTIVE);
                    $entityManager->persist($asset);
                    $entityManager->flush();
                    $this->flashMessenger()
                         ->setNamespace('success')
                         ->addMessage('The selected ' . strtolower($this->getEntityFriendlyName($this->getType())) . ' was successfully archived.');
                    return $this->redirect()->toRoute($this->getRouteName($this->getType()));
                }
            } else {
                $messages = $form->getMessages();
            }    
        }

        $view = new ViewModel(array(
            'form' => $form, 
            'id' => $asset->getId(), 
            'route' => $this->getRouteName($this->getType()),
            'action' => $this->getActionName(), 
            'message' => 'The selected ' . strtolower($this->getEntityFriendlyName($this->getType())) . ' will no longer be visible in the system.',
        ));
        $view->setTemplate('application/common/confirm.phtml');
        return $view;
    }

    public function unarchiveAction() 
    {
        $id = (int) $this->params()->fromRoute('id', 0);
        if (!$id) {
            return $this->redirect()->toRoute($this->getRouteName($this->getType()));
        }

        $entityManager = $this->getServiceLocator()->get('Doctrine\ORM\EntityManager');
        $asset = $entityManager->getRepository('\Application\Entity\Asset')
                               ->find($id);
        if (!$asset) {
            $this->flashMessenger()
                 ->setNamespace('error')
                 ->addMessage('The requested ' . strtolower($this->getEntityFriendlyName($this->getType())) . ' could not be found.');
            return $this->redirect()->toRoute($this->getRouteName($this->getType()));                 
        }        
        
        $builder = new AnnotationBuilder();
        $form = $builder->createForm(new ConfirmationForm());
        $request = $this->getRequest();        
        
        if ($request->isPost()) {
            $form->setData($request->getPost());
            if ($form->isValid()) {
                $validatedData = $form->getData();
                if ($validatedData['confirmation'] == '1') {
                    $asset->setStatus(Asset::STATUS_ACTIVE);
                    $entityManager->persist($asset);
                    $entityManager->flush();
                    $this->flashMessenger()
                         ->setNamespace('success')
                         ->addMessage('The selected ' . strtolower($this->getEntityFriendlyName($this->getType())) . ' was successfully unarchived.');
                    return $this->redirect()->toRoute($this->getRouteName($this->getType()));
                }
            } else {
                $messages = $form->getMessages();
            }    
        }

        $view = new ViewModel(array(
            'form' => $form, 
            'id' => $asset->getId(), 
            'route' => $this->getRouteName($this->getType()),
            'action' => $this->getActionName(), 
            'message' => 'The selected ' . strtolower($this->getEntityFriendlyName($this->getType())) . ' will become visible in the system.',
        ));
        $view->setTemplate('application/common/confirm.phtml');
        return $view;
    }
    
    public function auditAction() 
    {
        $id = (int) $this->params()->fromRoute('id', 0);
        if (!$id) {
            return $this->redirect()->toRoute($this->getRouteName($this->getType()));
        }

        $entityManager = $this->getServiceLocator()->get('Doctrine\ORM\EntityManager');
        $asset = $entityManager->getRepository('\Application\Entity\Asset')
                               ->find($id);
        if (!$asset) {
            $this->flashMessenger()
                 ->setNamespace('error')
                 ->addMessage('The requested ' . strtolower($this->getEntityFriendlyName($this->getType())) . ' could not be found.');
            return $this->redirect()->toRoute($this->getRouteName($this->getType()));                 
        }        
        if ($asset->getStatus() == Asset::STATUS_INACTIVE) {
            $this->flashMessenger()
                 ->setNamespace('error')
                 ->addMessage('The requested ' . strtolower($this->getEntityFriendlyName($this->getType())) . ' has been archived and is no longer available.');
            return $this->redirect()->toRoute($this->getRouteName($this->getType()));                 
        } 

        // get the last audit record for update
        // if changing to audit log, update to create a new record for each audit activity
        // also update in display and request actions 
        $audits = $entityManager->getRepository('\Application\Entity\Activity')
                                    ->findBy(array('type' => Activity::TYPE_AUDIT, 'assetId' => $asset->getId()), array('created' => 'DESC'));   
        $asset->setAudits($audits);  
        $lastAuditActivity = $audits[0];        
        $builder = new AnnotationBuilder($entityManager);
        $form = $builder->createForm($lastAuditActivity);
        $form->remove('message');

        $downloads = $entityManager->getRepository('\Application\Entity\Activity')
                                    ->findBy(array('type' => Activity::TYPE_DOWNLOAD, 'assetId' => $asset->getId()), array('created' => 'DESC'));   
        $asset->setDownloads($downloads); 
        
        $request = $this->getRequest();        
        if ($request->isPost()) {
            $form->setData($request->getPost());
            if ($form->isValid()) {
                $validatedData = $form->getData();
                // manually setting name/email as if using data-binding
                // audit form contains previous owner's details 
                $lastAuditActivity->setUserName($validatedData['userName']);
                $lastAuditActivity->setUserEmail($validatedData['userEmail']);
                $lastAuditActivity->setCreated(new \DateTime);
                $lastAuditActivity->setSourceIpAddress($request->getServer('REMOTE_ADDR'));
                $entityManager->persist($lastAuditActivity);
                $entityManager->flush();
                
                $metadata = $this->assetPlugin()->getAssetMetadataByType($asset->getType());
                $config = $this->getServiceLocator()->get('config');
                $uri = new \Zend\Uri\Uri($this->getRequest()->getUri());
                $baseUrl = $uri->getScheme() . '://' . $uri->getHost();
                $view = new ViewModel(array(
                    'asset' => $asset, 
                    'assetTypeSingular' => strtolower($metadata['labels'][0]),
                    'hubUrl' => $baseUrl . $this->url()->fromRoute('home'),
                ));
                $view->setTemplate('application/asset/audit.email.phtml');
                $viewRenderer = $this->getServiceLocator()->get('ViewRenderer');
                $html = $viewRenderer->render($view);                
                $html = new Part($html);
                $html->type = "text/html";  
                $body = new MimeMessage();
                $body->setParts(array($html));                
                $message = new Message();
                $message->setBody($body);               
                $emailAddresses = array($asset->getOwnerEmail());
                $downloads = $asset->getDownloads();
                foreach ($downloads as $d) {
                    $emailAddresses[] = $d->getUserEmail();
                }
                $fromEmail = $config['application']['from_email'];
                $fromName = $config['application']['from_name'];
                $message->setFrom($fromEmail, $fromName);
                $message->addTo($emailAddresses);
                $message->setSubject(ucfirst(strtolower($metadata['labels'][0])) . ' review complete - TACS');
                $message->setEncoding("UTF-8");

                $transport = new Sendmail();
                $transport->send($message);                                
                              
                $this->flashMessenger()
                     ->setNamespace('success')
                     ->addMessage('The selected ' . strtolower($this->getEntityFriendlyName($this->getType())) . ' was successfully audited.');
                return $this->redirect()->toRoute($this->getRouteName($this->getType()));
            } else {
                $messages = $form->getMessages();
            }    
        }
            
        $view = new ViewModel(array(
            'form' => $form, 
            'asset' => $asset, 
            'title' => 'Audit ' . ucwords($this->getEntityFriendlyName($this->getType())), 
            'route' => $this->getRouteName($this->getType())
        ));
        $view->setTemplate('application/asset/audit.phtml');
        return $view;

    }    
    
    public function requestAction() 
    {
        $id = (int) $this->params()->fromRoute('id', 0);
        if (!$id) {
            return $this->redirect()->toRoute($this->getRouteName($this->getType()));
        }

        $entityManager = $this->getServiceLocator()->get('Doctrine\ORM\EntityManager');
        $asset = $entityManager->getRepository('\Application\Entity\Asset')
                               ->find($id);
        if (!$asset) {
            $this->flashMessenger()
                 ->setNamespace('error')
                 ->addMessage('The requested ' . strtolower($this->getEntityFriendlyName($this->getType())) . ' could not be found.');
            return $this->redirect()->toRoute($this->getRouteName($this->getType()));                 
        }        
        if ($asset->getStatus() == Asset::STATUS_INACTIVE) {
            $this->flashMessenger()
                 ->setNamespace('error')
                 ->addMessage('The requested ' . strtolower($this->getEntityFriendlyName($this->getType())) . ' has been archived and is no longer available.');
            return $this->redirect()->toRoute($this->getRouteName($this->getType()));                 
        } 
        
        $request = $this->getRequest();        
        
        $past = new \DateTime("180 days ago");
        $activity = $entityManager->getRepository('\Application\Entity\Activity')
                               ->findOneBy(array('assetId' => $asset->getId(), 'type' => Activity::TYPE_AUDIT));
        if ( ($activity->getCreated() < $past) && ($request->getQuery('warn') != 'no') ) {
            return $this->redirect()->toRoute($this->getRouteName($this->getType()), array('action' => 'request-warn', 'id' => $asset->getId()));
        }
            
        $hydrator = new DoctrineHydrator($entityManager);
        $activity = new Activity();
        $builder = new AnnotationBuilder($entityManager);
        $form = $builder->createForm($activity);
        $form->get('message')->setAttributes(array('required' => true));
        $form->getInputFilter()->get('message')->setRequired(true);
        $form->getInputFilter()->get('message')->setAllowEmpty(false);
        $form->setHydrator($hydrator);
        $form->bind($activity);

        if ($request->isPost()) {
            $form->setData($request->getPost());
            if ($form->isValid()) {
                $activity->setId(null);
                $activity->setAssetId($asset->getId());
                $activity->setCreated(new \DateTime);
                $activity->setType(Activity::TYPE_DOWNLOAD);
                $activity->setSourceIpAddress($request->getServer('REMOTE_ADDR'));
                $entityManager->persist($activity);
                $entityManager->flush();
                
                // send mail
                $config = $this->getServiceLocator()->get('config');
                $audits = $entityManager->getRepository('\Application\Entity\Activity')
                                            ->findBy(array('type' => Activity::TYPE_AUDIT, 'assetId' => $asset->getId()), array('created' => 'DESC'));   
                $asset->setAudits($audits);  
                $metadata = $this->assetPlugin()->getAssetMetadataByType($asset->getType());
                $view = new ViewModel(array(
                    'asset' => $asset, 
                    'assetTypeSingular' => strtolower($metadata['labels'][0]),
                ));
                $view->setTemplate('application/asset/download.email.phtml');
                $viewRenderer = $this->getServiceLocator()->get('ViewRenderer');
                $html = $viewRenderer->render($view);                
                $html = new Part($html);
                $html->type = "text/html";  
                $uploadsPath = $config['application']['uploads_path'];
                switch ($asset->getType()) {                  
                    case Asset::TYPE_TESTIMONIAL:
                        break;
                    case Asset::TYPE_CASESTUDY:
                        $filePath = $uploadsPath . '/' . $asset->getId() . '/asset/' . $asset->getAssetFile();
                        $file = new Part(fopen($filePath, 'r'));
                        $file->filename = $asset->getAssetFile();
                        $file->disposition = Mime::DISPOSITION_ATTACHMENT;
                        $file->encoding = Mime::ENCODING_BASE64;
                        break;
                    case Asset::TYPE_VIDEO:
                        break;
                }
                $body = new MimeMessage();
                if ($file) {
                    $body->setParts(array($html, $file));
                } else {
                    $body->setParts(array($html));                
                }
                $message = new Message();
                $message->setBody($body);
                $fromEmail = $config['application']['from_email'];
                $fromName = $config['application']['from_name'];
                $message->setFrom($fromEmail, $fromName);
                $message->addTo($activity->getUserEmail());
                $message->setSubject('Your download from TACS');
                $message->setEncoding("UTF-8");
                $transport = new Sendmail();
                /* left in for testing 
                $transport = new SmtpTransport();
                $options   = new SmtpOptions(array(
                    'name'              => 'smtp.gmail.com',
                    'host'              => 'smtp.gmail.com',
                    'port' => 587,
                    'connection_class'  => 'login',
                    'connection_config' => array(
                        'ssl' => 'tls',
                        'username' => 'user@gmail.com',
                        'password' => 'password',
                    ),
                ));
                $transport->setOptions($options); 
                /* */
                $transport->send($message);                
                
                $this->flashMessenger()
                     ->setNamespace('success')
                     ->addMessage('Your download request was successful. Further information has been sent to your email address.');
                return $this->redirect()->toRoute($this->getRouteName($this->getType()));
            } else {
                $messages = $form->getMessages();
            }    
        }
            
        $view = new ViewModel(array(
            'form' => $form, 
            'id' => $asset->getId(), 
            'title' => 'Download ' . ucwords($this->getEntityFriendlyName($this->getType())), 
            'route' => $this->getRouteName($this->getType()),
            'warn' => $request->getQuery('warn')
        ));
        $view->setTemplate('application/asset/download.phtml');
        return $view;
    }

    public function downloadConsentAction()
    {
        $entityManager = $this->getServiceLocator()->get('Doctrine\ORM\EntityManager');
        $hydrator = new DoctrineHydrator($entityManager);
        $request = $this->getRequest();        
        
        // no id
        $id = (int) $this->params()->fromRoute('id', 0);
        if (!$id) {
            return $this->redirect()->toRoute('home');
        }
        
        // invalid id
        $asset = $entityManager->getRepository('\Application\Entity\Asset')
                               ->find($id);          
        if (!$asset) {
            $this->flashMessenger()
                 ->setNamespace('error')
                 ->addMessage('The requested file could not be found.');
            return $this->redirect()->toRoute('home');                 
        }        
        if ($asset->getStatus() == Asset::STATUS_INACTIVE) {
            $this->flashMessenger()
                 ->setNamespace('error')
                 ->addMessage('The requested ' . strtolower($this->getEntityFriendlyName($this->getType())) . ' has been archived and is no longer available.');
            return $this->redirect()->toRoute($this->getRouteName($this->getType()));                 
        } 

        $config = $this->getServiceLocator()->get('config');
        $uploadsPath = $config['application']['uploads_path'];
        $file = $uploadsPath . '/' . $asset->getId() . '/consent/' . $asset->getConsentFile();
        if (!file_exists($file)) {
            $this->flashMessenger()
                 ->setNamespace('error')
                 ->addMessage('The requested file could not be found.');
            return $this->redirect()->toRoute('home');
        }

        $response = new \Zend\Http\Response\Stream();
        $response->setStream(fopen($file, 'r'));
        $response->setStatusCode(200);
        $response->setStreamName(basename($file));
        $headers = new \Zend\Http\Headers();
        $headers->addHeaders(array(
            'Content-Disposition' => 'attachment; filename="' . basename($file) .'"',
            'Content-Type' => 'application/octet-stream',
            'Content-Length' => filesize($file),
            'Expires' => '@0', // @0, because zf2 parses date as string to \DateTime() object
            'Cache-Control' => 'must-revalidate',
            'Pragma' => 'public'
        ));
        $response->setHeaders($headers);
        return $response;
    
    }
    
    public function requestWarnAction()
    {
        $id = (int) $this->params()->fromRoute('id', 0);
        if (!$id) {
            return $this->redirect()->toRoute($this->getRouteName($this->getType()));
        }

        $entityManager = $this->getServiceLocator()->get('Doctrine\ORM\EntityManager');
        $asset = $entityManager->getRepository('\Application\Entity\Asset')
                               ->find($id);
        if (!$asset) {
            $this->flashMessenger()
                 ->setNamespace('error')
                 ->addMessage('The requested ' . strtolower($this->getEntityFriendlyName($this->getType())) . ' could not be found.');
            return $this->redirect()->toRoute($this->getRouteName($this->getType()));                 
        }        
        if ($asset->getStatus() == Asset::STATUS_INACTIVE) {
            $this->flashMessenger()
                 ->setNamespace('error')
                 ->addMessage('The requested ' . strtolower($this->getEntityFriendlyName($this->getType())) . ' has been archived and is no longer available.');
            return $this->redirect()->toRoute($this->getRouteName($this->getType()));                 
        } 
        
        $request = $this->getRequest(); 
        $builder = new AnnotationBuilder();
        $form = $builder->createForm(new ConfirmationForm());
        
        if ($request->isPost()) {
            $form->setData($request->getPost());
            if ($form->isValid()) {
                $validatedData = $form->getData();
                if ($validatedData['confirmation'] == '1') {
                    return $this->redirect()->toRoute($this->getRouteName($this->getType()), array('action' => 'request', 'id' => $asset->getId()), array('query' => array('warn' => 'no')));
                }                    
            } else {
                $messages = $form->getMessages();
            }  
        }
        
        $view = new ViewModel(array(
            'form' => $form, 
            'id' => $asset->getId(), 
            'route' => $this->getRouteName($this->getType()),
            'action' => $this->getActionName(), 
            'message' => 'The selected ' . strtolower($this->getEntityFriendlyName($this->getType())) . ' was last audited more than six months ago and may no longer be valid.',            
        ));
        $view->setTemplate('application/common/confirm.phtml');
        return $view;   
    }

    public function cloneAction()
    {        
        $entityManager = $this->getServiceLocator()->get('Doctrine\ORM\EntityManager');
        $hydrator = new DoctrineHydrator($entityManager);
        $request = $this->getRequest();        
        
        // no id
        $id = (int) $this->params()->fromRoute('id', 0);
        if (!$id) {
            return $this->redirect()->toRoute($this->getRouteName($this->getType()));
        }
        
        // invalid id
        $asset = $entityManager->getRepository('\Application\Entity\Asset')
                               ->find($id);          
        if (!$asset) {
            $this->flashMessenger()
                 ->setNamespace('error')
                 ->addMessage('The requested ' . strtolower($this->getEntityFriendlyName($this->getType())) . ' could not be found.');
            return $this->redirect()->toRoute($this->getRouteName($this->getType()));                 
        }        
        if ($asset->getStatus() == Asset::STATUS_INACTIVE) {
            $this->flashMessenger()
                 ->setNamespace('error')
                 ->addMessage('The requested ' . strtolower($this->getEntityFriendlyName($this->getType())) . ' has been archived and is no longer available.');
            return $this->redirect()->toRoute($this->getRouteName($this->getType()));                 
        } 
        
        $builder = new AnnotationBuilder();
        $form = $builder->createForm($asset);
        $form->get('categories')->setOptions(array('object_manager' => $entityManager));
        $form->setHydrator($hydrator);
        $form->bind($asset);
        
        $categoryHydrator = new DoctrineHydrator($entityManager, 'Category');
        $categories = $entityManager->getRepository('\Application\Entity\Category')
                                    ->findBy(array('status' => Asset::STATUS_ACTIVE));
        foreach ($categories as $c) {
            $categoryId = $c->getId();
            $categoryOptions[$categoryId] = $c->getTitle();
        }
        $form->get('categories')->setValueOptions($categoryOptions);
        
        $form->get('planType')->setValueOptions($this->assetPlugin()->getPlanTypes());        
        
        $form = $this->setRequiredAssetFields($form);
                                        
        $view = new ViewModel(array(
            'form' => $form, 
            'title' => 'Add ' . ucwords($this->getEntityFriendlyName($this->getType())), 
            'action' => 'save', 
            'route' => $this->getRouteName($this->getType())
        ));
        $view->setTemplate('application/asset/save.phtml');
        return $view;
    }
    
    private function getEntityFriendlyName($type)
    {
        $metadata = $this->assetPlugin()->getAssetMetadataByType($type);
        return $metadata['labels'][0];
    }  

    private function getRouteName($type)
    {
        $metadata = $this->assetPlugin()->getAssetMetadataByType($type);
        return $metadata['route'];
    }

    private function getActionName()
    {
        return $this->params('action');
    }  
    
    private function setRequiredAssetFields($form, $id = null)
    {
        switch($this->getType()) 
        {
            case Asset::TYPE_TESTIMONIAL:
                $form->get('assetData')->setAttributes(array('required' => true));
                $form->getInputFilter()->get('assetData')->setRequired(true);
                $form->getInputFilter()->get('assetData')->setAllowEmpty(false);
                break;
            case Asset::TYPE_CASESTUDY:
                // if create operation only, file required for case studies
                // if update operation, file optional
                if (empty($id)) {
                    $form->get('assetFile')->setAttributes(array('required' => true));
                    $form->getInputFilter()->get('assetFile')->setRequired(true);
                    $form->getInputFilter()->get('assetFile')->setAllowEmpty(false);
                }
                $form->get('description')->setAttributes(array('required' => true));
                $form->getInputFilter()->get('description')->setRequired(true);
                $form->getInputFilter()->get('description')->setAllowEmpty(false);                
                break;
            case Asset::TYPE_VIDEO:
                $form->get('description')->setAttributes(array('required' => true));
                $form->getInputFilter()->get('description')->setRequired(true);
                $form->getInputFilter()->get('description')->setAllowEmpty(false);                
                $form->get('assetData')->setAttributes(array('required' => true));
                $form->getInputFilter()->get('assetData')->setRequired(true);
                $form->getInputFilter()->get('assetData')->setAllowEmpty(false);
                break;                
        }    
        return $form;
    }

    private function setAdditionalValidatorsOnAssetFields($form, $id = null)
    {
        switch($this->getType()) 
        {
            case Asset::TYPE_TESTIMONIAL:
                break;
            case Asset::TYPE_CASESTUDY:
                break;
            case Asset::TYPE_VIDEO:
                $form->getInputFilter()->get('assetData')->getValidatorChain()
                     ->attach(new \Zend\Validator\Uri(array('allow_relative' => false)));
                $form->getInputFilter()->get('assetDataSize')->getValidatorChain()
                     ->attach(new \Zend\Validator\Regex(array('pattern' => '/^[0-9]*\.?[0-9]+$/', 'messages' => array('regexNotMatch' => 'The input must be an integer or decimal value'))));
                break;                
        }    
        return $form;
    }
    
    private function handleUpload($file, $directory, $id, $originalFilename = false)
    {    
        $config = $this->getServiceLocator()->get('config');
        $uploadsPath = $config['application']['uploads_path'];
        if (!file_exists($uploadsPath . '/' . $id)) {
            mkdir($uploadsPath . '/' . $id);
        }
        if (!file_exists($uploadsPath . '/' . $id . '/' . $directory)) {
            mkdir($uploadsPath . '/' . $id . '/' . $directory);
        }
        $fileFilter = new Rename(array("target" => $uploadsPath . '/' . $id . '/' . $directory . '/' . $file['name'], "overwrite" => "true"));
        $fileFilter->filter($file);
        if (!empty($originalFilename) && file_exists($uploadsPath . '/' . $id . '/' . $directory . '/' . $originalFilename)) {
            unlink($uploadsPath . '/' . $id . '/' . $directory . '/' . $originalFilename);
        }
        return $file['name'];    
    }

    private function removeOrphanFiles($location)
    {    
        $count = 0;
        $date = strtotime('-4 day', time());
        foreach (new \DirectoryIterator($location) as $file) {
            if ($file->isDot() || strtolower($file->getFilename()) == '.gitignore') {
                continue;
            }
            if ($file->isFile() && ($file->getMTime() < $date)) {
                unlink($location . '/' . $file);
                $count++;
            }            
        }
        return $count;
    }

}
