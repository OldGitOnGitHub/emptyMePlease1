<html>
<body>
 
 
<h1>Post Auction Data for Graham</h1>
<!-- Links to main admin pages -->
 
 
 
<?php
// includes
include('../includes/conf.php');
include('../includes/functions.php');
 
// open database connection
$connection = mysql_connect($host, $user, $pass) or die ('Unable to connect!');
 
// select database
mysql_select_db($db) or die ('Unable to select database!');
 
// generate and execute query
$query = "SELECT BidderName, BidderEmail FROM bids";
 
$result = mysql_query($query) or die ("Error in query: $query. " . mysql_error());
?><h2>Email Addresses:</h2><ul><?php
// if records present
if (mysql_num_rows($result) > 0)
{
      // iterate through resultset
      // print title with links to edit and delete scripts
      while($row = mysql_fetch_object($result))
      {
      ?>
      <li><?php echo ($row->BidderName); ?>   -   <?php echo ($row->BidderEmail); ?></li>
      <?php
      }
}
 
?>
</ul>
<?php
 
 
// generate and execute query
$query = "SELECT LotNumber FROM lots WHERE DisplayedLotNumber='43'";
 
$result = mysql_query($query) or die ("Error in query: $query. " . mysql_error());
 
// if records present
if (mysql_num_rows($result) > 0)
{
      // iterate through resultset
      // print title with links to edit and delete scripts
      while($row = mysql_fetch_object($result))
      {
$query = "SELECT BidderName, BidderEmail, MaximumBid, BidTime FROM bids WHERE LotNumber='".$row->LotNumber."'";
                                $lotNumber = $row->LotNumber;
      }
}
 
// generate and execute query
 
$result = mysql_query($query) or die ("Error in query: $query. " . mysql_error());
?><h2>Lot 43 (<?php echo ($lotNumber); ?>) info:</h2><table><tr><th>Name</th><th>Email</th><th>Max Bid</th><th>Time</th></tr><?php
// if records present
if (mysql_num_rows($result) > 0)
{
      // iterate through resultset
      // print title with links to edit and delete scripts
      while($row = mysql_fetch_object($result))
      {
      ?>
      <tr><td><?php echo ($row->BidderName); ?></td><td><?php echo ($row->BidderEmail); ?></td><td><?php echo ($row->MaximumBid); ?></td><td><?php echo ($row->BidTime); ?></td></tr>
      <?php
      }
}
?>
</table
<?
// close connection
mysql_close($connection);
?>
 
 
</body>
</html>
