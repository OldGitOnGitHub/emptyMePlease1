<html>
<body>


<h1>Main Auction Admin Pages</h1>
<!-- Links to main admin pages -->
<ul>
<li><font size="4"><a href="add-actions.php">Add a New Item</a></font>   </li>
<li><font size="4"><a href="list-actions.php">Edit and Delete Existing Item</a></font>   </li>
</ul>



<?php
// includes
include('../includes/conf.php');
include('../includes/functions.php');

// open database connection
$connection = mysql_connect($host, $user, $pass) or die ('Unable to connect!');

// select database
mysql_select_db($db) or die ('Unable to select database!');

// generate and execute query
$query = "SELECT SUM(LotCurrentDisplayBid) as value_sum FROM lots";

$result = mysql_query($query) or die ("Error in query: $query. " . mysql_error());

$row = mysql_fetch_assoc($result); 
$sum = $row['value_sum'];      
      ?>
      <br /><h3>Current Total:</h3>
      <?php echo '&#163;'.$sum; ?><br/>

<?php
// close connection
mysql_close($connection);
?>


</body>
</html>