<!DOCTYPE html>
<meta http-equiv="X-UA-Compatible" content="IE=edge" />
<?php include('userIDinclude.php'); ?>

<html>
<head>

<title>Add a policy</title>

<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.css">
<link rel="stylesheet" type="text/css" href="styles.css">

<script src="scripts/jquery-1.10.1.min.js" type="text/javascript"></script>
<script src="ckeditor4.5.9/ckeditor.js" type="text/javascript"></script>

</head>
<body class="formPage">

<?php
if (!$_POST['submit'])
{

// includes
include('conf.php');

// open database connection
$connection = mysql_connect($host, $user, $pass) or die ('Unable to connect!');

// select database
mysql_select_db($db) or die ('Unable to select database!');

?>

<h1>Add a policy</h1>
<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST">
<label>Name</label><input name="name" type="text"/>
<?php
// generate and execute query
$Dquery = "SELECT ID, name FROM companies ORDER BY ID DESC";

$Dresult = mysql_query($Dquery) or die ("Error in query: $Dquery. " . mysql_error());

// if records present
if (mysql_num_rows($Dresult) > 0)
{?>
<label>Company</label>
<select name="companyID">
<?php
      // iterate through resultset
      // print title with links to edit and delete scripts
      while($Drow = mysql_fetch_object($Dresult))
      {
      ?>
      <option value="<?php echo $Drow->ID; ?>"><?php echo $Drow->name; ?></option> 
      <?php
      }
      ?>
</select>
<?php
}
?>
<label>InPatientDayCover</label><textarea class="ckeditor" name="InPatientDayCover" rows="2" cols="8"></textarea>
<label>PsyciatricIP</label><textarea class="ckeditor" name="PsyciatricIP" rows="2" cols="8"></textarea>
<label>Consultations</label><textarea class="ckeditor" name="Consultations" rows="2" cols="8"></textarea>
<label>DiagnosticTests</label><textarea class="ckeditor" name="DiagnosticTests" rows="2" cols="8"></textarea>
<label>Therapists</label><textarea class="ckeditor" name="Therapists" rows="2" cols="8"></textarea>
<label>Practitioners</label><textarea class="ckeditor" name="Practitioners" rows="2" cols="8"></textarea>
<label>MriCtPetScans</label><textarea class="ckeditor" name="MriCtPetScans" rows="2" cols="8"></textarea>
<label>PsyciatricOP</label><textarea class="ckeditor" name="PsyciatricOP" rows="2" cols="8"></textarea>
<label>NHSCashBenefits</label><textarea class="ckeditor" name="NHSCashBenefits" rows="2" cols="8"></textarea>
<label>CancerCashBenefits</label><textarea class="ckeditor" name="CancerCashBenefits" rows="2" cols="8"></textarea>
<label>AmbulanceTransport</label><textarea class="ckeditor" name="AmbulanceTransport" rows="2" cols="8"></textarea>
<label>CancerCover</label><textarea class="ckeditor" name="CancerCover" rows="2" cols="8"></textarea>
<label>RecuperativeCare</label><textarea class="ckeditor" name="RecuperativeCare" rows="2" cols="8"></textarea>
<label>ParentAccomodation</label><textarea class="ckeditor" name="ParentAccomodation" rows="2" cols="8"></textarea>
<label>ExcessLevels</label><textarea class="ckeditor" name="ExcessLevels" rows="2" cols="8"></textarea>
<label>Extras</label><textarea class="ckeditor" name="Extras" rows="2" cols="8"></textarea>
<label>one80DayRule</label><textarea class="ckeditor" name="one80DayRule" rows="2" cols="8"></textarea>
<label>NCDProtection</label><textarea class="ckeditor" name="NCDProtection" rows="2" cols="8"></textarea>
<label>NCDLevels</label><textarea class="ckeditor" name="NCDLevels" rows="2" cols="8"></textarea>
<label>NCDStartingPerc</label><textarea class="ckeditor" name="NCDStartingPerc" rows="2" cols="8"></textarea>
<label>sixWeekRule</label><textarea class="ckeditor" name="sixWeekRule" rows="2" cols="8"></textarea>
<label>HospitalList</label><textarea class="ckeditor" name="HospitalList" rows="2" cols="8"></textarea>
<label>Underwriting</label><textarea class="ckeditor" name="Underwriting" rows="2" cols="8"></textarea>
<label>AnythingElse</label><textarea class="ckeditor" name="AnythingElse" rows="2" cols="8"></textarea><br />
<label>Exclude from HoLi?</label>
<input type="checkbox" name="notOnHoLi" value="1" />
<input type="submit" value="Submit" name="submit">
</form>
</form>
<?php
// close connection
mysql_close($connection);
?>



<?php
}
else
{
    // includes
    include('conf.php');

    // set up error list array
    $errorList = array();
    
$name = $_POST['name'];
$companyID = $_POST['companyID'];
$InPatientDayCover = $_POST['InPatientDayCover'];
$PsyciatricIP = $_POST['PsyciatricIP'];
$Consultations = $_POST['Consultations'];
$DiagnosticTests = $_POST['DiagnosticTests'];
$Therapists = $_POST['Therapists'];
$Practitioners = $_POST['Practitioners'];
$MriCtPetScans = $_POST['MriCtPetScans'];
$PsyciatricOP = $_POST['PsyciatricOP'];
$NHSCashBenefits = $_POST['NHSCashBenefits'];
$CancerCashBenefits = $_POST['CancerCashBenefits'];
$AmbulanceTransport = $_POST['AmbulanceTransport'];
$CancerCover = $_POST['CancerCover'];
$RecuperativeCare = $_POST['RecuperativeCare'];
$ParentAccomodation = $_POST['ParentAccomodation'];
$ExcessLevels = $_POST['ExcessLevels'];
$Extras = $_POST['Extras'];
$one80DayRule = $_POST['one80DayRule'];
$NCDProtection = $_POST['NCDProtection'];
$NCDLevels = $_POST['NCDLevels'];
$NCDStartingPerc = $_POST['NCDStartingPerc'];
$sixWeekRule = $_POST['sixWeekRule'];
$HospitalList = $_POST['HospitalList'];
$Underwriting = $_POST['Underwriting'];
$AnythingElse = $_POST['AnythingElse'];
$notOnHoLi = $_POST['notOnHoLi'];
    
    
    // validate text input fields
    if (trim($_POST['name']) == '') 
    { 
        $errorList[] = 'Invalid entry: Name'; 
    }

    // check for errors
    // if none found...
    if (sizeof($errorList) == 0)
    {
        // open database connection
        $connection = mysql_connect($host, $user, $pass) or die ('Unable to connect!');

        // select database
        mysql_select_db($db) or die ('Unable to select database!');

        // generate and execute query
        $query = "INSERT INTO policies (name, companyID, InPatientDayCover, PsyciatricIP, Consultations, DiagnosticTests, Therapists, Practitioners, MriCtPetScans, PsyciatricOP, NHSCashBenefits, CancerCashBenefits, AmbulanceTransport, CancerCover, RecuperativeCare, ParentAccomodation, ExcessLevels, Extras, one80DayRule, NCDProtection, NCDLevels, NCDStartingPerc, sixWeekRule, HospitalList, Underwriting, AnythingElse, notOnHoLi) VALUES ('$name', '$companyID', '$InPatientDayCover', '$PsyciatricIP', '$Consultations', '$DiagnosticTests', '$Therapists', '$Practitioners', '$MriCtPetScans', '$PsyciatricOP', '$NHSCashBenefits', '$CancerCashBenefits', '$AmbulanceTransport', '$CancerCover', '$RecuperativeCare', '$ParentAccomodation', '$ExcessLevels', '$Extras', '$one80DayRule', '$NCDProtection', '$NCDLevels', '$NCDStartingPerc', '$sixWeekRule', '$HospitalList', '$Underwriting', '$AnythingElse', '$notOnHoLi')";


        $result = mysql_query($query) or die ("Error in query: $query. " . mysql_error());

/**********ACTIVITY LOG FUNCTIONALITY**********/
        $currentFile = $_SERVER["PHP_SELF"];
$ipAddress = $_SERVER["REMOTE_ADDR"];
$date = date("Y/m/d");
$escapedQuery = mysql_escape_string($query);
        // generate and execute query
        $activityQuery = "INSERT INTO activityLog(user, page, notes, query, errors, dateExecuted, ipAddress) VALUES('$userID', '$currentFile', 'Added new policy.', '$escapedQuery', '$SQLerror', '$date', '$ipAddress')";

        $activityResult = mysql_query($activityQuery) or die ("Error in query: $query. " . mysql_error());
/**********************************************/

        // print result
        echo '<h2>Update successful.</h2><br>';

        // close database connection
        mysql_close($connection);
    }
    else
    {
    
    
        // errors found
        // print as list
        echo '<font size=-1>The following errors were encountered:'; 
        echo '<br>';
        echo '<ul>';
        for ($x=0; $x<sizeof($errorList); $x++)
        {
            echo "<li>$errorList[$x]";
        }
        echo '</ul></font><br /><a href=&amp;javascript: history.go(-1)&amp;>Back</a>';
    }
}
?>
</body>
</html>
