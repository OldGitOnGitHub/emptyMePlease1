<?php
namespace Application\Entity;

use Doctrine\ORM\Mapping as ORM;
use Zend\Form\Annotation;

/** @ORM\Entity
*   @ORM\Table(name="category")
*   @Annotation\Name("category")
*/
class Category
{

    const STATUS_ACTIVE = 1;
    const STATUS_INACTIVE = 0;

    /**
    * @ORM\Id
    * @ORM\GeneratedValue(strategy="AUTO")
    * @ORM\Column(type="integer")
    * @Annotation\Type("Zend\Form\Element\Hidden")
    */
    protected $id;

    /** @ORM\Column(type="string") 
    *   @Annotation\Filter({"name":"StringTrim"})
    *   @Annotation\Filter({"name":"StripTags"})
    *   @Annotation\Validator({"name":"StringLength", "options":{"min":1, "max":100}})
    *   @Annotation\Type("Zend\Form\Element\Text")
    *   @Annotation\Options({"label":"Name"})     
    */
    protected $title;
    
    /** @ORM\Column(type="boolean") 
    *   @Annotation\Required(false)
    *   @Annotation\Filter({"name":"StringTrim"})
    *   @Annotation\Filter({"name":"StripTags"})
    *   @Annotation\Type("Zend\Form\Element\Checkbox")
    *   @Annotation\Options({"label":"Status", "checked_value":"1", "unchecked_value":"0"})     
    */
    protected $status;
    
    /** 
    *   @Annotation\Type("Zend\Form\Element\Csrf")
    */
    protected $csrf;
        
    /** 
    *   @Annotation\Attributes({"value":"Submit"})
    *   @Annotation\Type("Zend\Form\Element\Submit")
    */
    protected $submit;
    
    public function getId()
    {
        return $this->id;
    }

    public function setId($value)
    {
        $this->id = $value;
    }    
     
    public function getTitle()
    {
        return $this->title;
    }

    public function setTitle($value)
    {
        $this->title = $value;
    }    
    
    public function getStatus()
    {
        return $this->status;
    }

    public function setStatus($value)
    {
        $this->status = $value;
    }    
}