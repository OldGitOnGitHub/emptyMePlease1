<html>
<head>
<basefont face="Verdana">
<title>auction admin add</title>
</head>

<body>

<!-- standard page header begins -->
<p>&nbsp;<p>

<table width="100%" cellspacing="0" cellpadding="5">
<tr>
    <td></td>
</tr>
<tr>
    <td bgcolor="#993333"><font size="-1" color="White">
    <b>AXA PPP Healthcare - Online Charity Auction</b></font>
    </td>
</tr>
</table>
<!-- standard page header ends -->

<?php
// form not yet submitted
// display initial form
if (!$_POST['submit'])
{
?>

<table cellspacing="5" cellpadding="5">
<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST">

<?php

 // open database connection
 	include('../includes/conf.php');
    	include('../includes/functions.php');
        $connection = mysql_connect($host, $user, $pass) or die ('Unable to connect!');

        // select database
        mysql_select_db($db) or die ('Unable to select database!');

?>

<tr>
    <td valign="top"><font size="4">Displayed Lot Number</font></td>
    <td>
      <input size="10" maxlength="10" type="text" name="DisplayedLotNumber">
    </td>
</tr>

<tr>
    <td valign="top"><font size="4">Lot Title</font></td>
    <td>
      <input size="66" maxlength="66" type="text" name="LotTitle">
    </td>
</tr>
<tr>
    <td valign="top"><font size="4">Lot Description</font></td>
    <td>
    
    <textarea rows="10" cols="50" name="LotDescription" wrap="physical"> </textarea><br />
      
    </td>
</tr>
<tr>
    <td valign="top"><font size="4">Lot Donor</font></td>
    <td>
    <textarea rows="10" cols="50" name="LotDonor" wrap="physical"> </textarea><br />
    </td>
</tr>

<tr>
    <td valign="top"><font size="4">Lot Picture</font></td>
    <td>
      <input size="30" maxlength="30" type="text" name="LotPicture">
    </td>
</tr>

<tr>
    <td valign="top"><font size="4">Additional Info Link</font></td>
    <td>
      <input size="150" maxlength="150" type="text" name="AdditionalInfoLink">
    </td>
</tr>

<tr>
    <td colspan=2>
      <input type="Submit" name="submit" value="Add">
    </td>
</tr>

</form>
</table>
<?php
}
else
{
    // includes
    include('../includes/conf.php');
    include('../includes/functions.php');

    // set up error list array
    $errorList = array();
    
    $DisplayedLotNumber = $_POST['DisplayedLotNumber'];
    $LotTitle = $_POST['LotTitle'];
    $LotDescription = $_POST['LotDescription'];
    $LotDonor = $_POST['LotDonor'];
    $LotPicture = $_POST['LotPicture'];
    $AdditionalInfoLink = $_POST['AdditionalInfoLink'];
    
    
    //validate text input fields
    
   
    if (trim($_POST['DisplayedLotNumber']) == '') 
    { 
        $errorList[] = 'Invalid entry: Displayed Lot Number'; 
    }
   
    if (trim($_POST['LotTitle']) == '') 
    { 
        $errorList[] = 'Invalid entry: Lot Title'; 
    }
    
    if (trim($_POST['LotDescription']) == '') 
    { 
        $errorList[] = 'Invalid entry: Lot Description'; 
    }
    
    if (trim($_POST['LotDonor']) == '') 
    { 
        $errorList[] = 'Invalid entry: Lot Donor'; 
    }

    if (trim($_POST['LotPicture']) == '') 
    { 
        $errorList[] = 'Invalid entry: Lot Picture'; 
    }
   

    
    // check for errors
    // if none found...
    if (sizeof($errorList) == 0)
    {
        // open database connection
        $connection = mysql_connect($host, $user, $pass) or die ('Unable to connect!');

        // select database
        mysql_select_db($db) or die ('Unable to select database!');

        // generate and execute query
        $query = "INSERT INTO lots (DisplayedLotNumber, LotTitle, LotDescription, LotDonor, LotPicture, AdditionalInfoLink) VALUES ('$DisplayedLotNumber', '$LotTitle', '$LotDescription', '$LotDonor', '$LotPicture', '$AdditionalInfoLink')";
        $query = "INSERT INTO lots (DisplayedLotNumber, LotTitle, LotDescription, LotDonor, LotPicture, AdditionalInfoLink) VALUES ('$DisplayedLotNumber', '$LotTitle', '$LotDescription', '$LotDonor', '$LotPicture', '$AdditionalInfoLink')";

        $result = mysql_query($query) or die ("Error in query: $query. " . mysql_error());

        // print result
        echo '<font size=4>Update successful. <br> <a href=list-actions.php>Go back to the Auction List</a>. </font>';

        // close database connection
        mysql_close($connection);
    }
    else
    {
        // errors found
        // print as list
        echo '<font size=4>The following errors were encountered:'; 
        echo '<br>';
        echo '<ul>';
        for ($x=0; $x<sizeof($errorList); $x++)
         {
            echo "<li>$errorList[$x]"; 
           
        }
        echo '</ul></font>';
        echo '<br>';
        echo '<br>';
        echo '<a href=list-actions.php>Go back to the Auction List</a>.</font>';
    
    }          
}

?>

<!-- Link to admin menu -->
<br>
<font size="4"><a href="index.php">Back to the Admin Menu</a></font>  

<!-- standard page footer begins -->
<p>
<table width="100%" cellspacing="0" cellpadding="5">
<tr>
    <td align="center"><font size="-2">
    Few rights reserved. Visit  
    <a href="http://www.joining-dots.com"> 
    joining-dots</a> for more.</font></td>
</tr>
</table>
<!-- standard page footer ends -->

</body>
</html>