<!DOCTYPE html>
<meta http-equiv="X-UA-Compatible" content="IE=edge" />
<?php include('userIDinclude.php'); ?>
 
<html>
<head>
 
<title>Add a topic</title>
 
<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.css">
<link rel="stylesheet" type="text/css" href="styles.css">
 
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js" type="text/javascript"></script>

<script src="ckeditor4.5.9/ckeditor.js" type="text/javascript"></script>
 
<script>
$(document ).ready(function() {
CKEDITOR.replace( 'ckeditor', { width:"400" } );
});
</script>
 
<STYLE>
  .fleft{float:left;}
  .fright{float:right;}
  div {
                                height:35px;
                                width:495px;
                                /* background-color:#b00; */
                                padding: 5px 45px 5px 45px;
                                margin: 0 auto;
                }
</STYLE>
 
</head>
<body class="formPage">
 
<?php
if (!$_POST['submit'])
{
 
// includes
include('conf.php');
 
// open database connection
$connection = mysql_connect($host, $user, $pass) or die ('Unable to connect!');
 
// select database
mysql_select_db($db) or die ('Unable to select database!');
 
?>
 
<h1>Add a topic</h1>
<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST">
                <div>
                <label class="fleft">Title <span style="font-size: 10px">(max 45 chars.)</span></label>
                                <input class="fright" name="title" type="text" maxlength="45" />
    </div>
    <div>
                                <label class="fleft">User</label>
				<input name="userIDVisible" class="fright capitalize" type="text" value="<?php echo $userID ; ?>" disabled="disabled" />
				<input name="userID" class="capitalize" type="hidden" value="<?php echo $userID ; ?>" />
                </div>
    <div>
                <label class="fleft">Department</label>
                <select  class="fright" name="department" >
                </div>
    <div>
                <option value="">Please select</option>
<?php
 
// generate and execute query
$query = "SELECT ID, name FROM departments ORDER BY name ASC";
 
$result = mysql_query($query) or die ("Error in query: $query. " . mysql_error());
 
// if records present
if (mysql_num_rows($result) > 0)
{
      // iterate through resultset
      // print title with links to edit and delete scripts
      while($row = mysql_fetch_object($result))
      {
      ?>
      <option value="<?php echo $row->ID; ?>"><?php echo $row->name; ?></option>
      <?php
      }
}
// if no records present
// display message
else
{
?>
      <option>No departments currently available</option>
<?php
}
?>
</select>
</div>
<div>
<label  class="fleft">Category</label>
<select  class="fright" name="category" >
                <option value="">Please select</option>
<?php
 
// generate and execute query
$query = "SELECT ID, name FROM topicCategories ORDER BY ID DESC";
 
$result = mysql_query($query) or die ("Error in query: $query. " . mysql_error());
 
// if records present
if (mysql_num_rows($result) > 0)
{
      // iterate through resultset
      // print title with links to edit and delete scripts
      while($row = mysql_fetch_object($result))
      {
      ?>
      <option value="<?php echo $row->ID; ?>"><?php echo $row->name; ?></option>
      <?php
      }
}
// if no records present
// display message
else
{
?>
      <option>No departments currently available</option>
<?php
}
?>
</select>
</div>
<br/>
<div>
                <label class="fleft">Content <span style="font-size: 10px">(max 80 words)</span></label>
<br><br>
                <textarea class="fright" id="ckeditor" name="content" rows="4" cols="50">Enter your topic content here</textarea>
                <br />
<input type="submit" value="Add" name="submit">
</div>
</form>
<?php
// close connection
mysql_close($connection);
?>
 
 
 
<?php
}
else
{
    // includes
    include('conf.php');
 
    // set up error list array
    $errorList = array();
   
    $title = $_POST['title'];
    $userID = $_POST['userID'];
    $department = $_POST['department'];
    $category = $_POST['category'];
    $content = $_POST['content'];
   
               
    // validate text input fields
    if (trim($_POST['title']) == '')
    {
        $errorList[] = 'Invalid entry: Title';
    }
    if (trim($_POST['userID']) == '')
    {
        $errorList[] = 'Invalid entry: User';
    }
    if (trim($_POST['department']) == '')
    {
        $errorList[] = 'Invalid entry: Department';
    }
        if (trim($_POST['category']) == '')
    {
        $errorList[] = 'Invalid entry: Category';
    }
        if (trim($_POST['content']) == '')
    {
        $errorList[] = 'Invalid entry: Content';
    }
    // check for errors
    // if none found...
    if (sizeof($errorList) == 0)
    {
        // open database connection
        $connection = mysql_connect($host, $user, $pass) or die ('Unable to connect!');
 
        // select database
        mysql_select_db($db) or die ('Unable to select database!');
 
        // generate and execute query
        $query = "INSERT INTO topics(title, userID, departmentID, categoryID, content, votes, status, visible) VALUES('$title', '$userID', '$department', '$category', '$content', 0, 0, 1)";
 
 
        $result = mysql_query($query) or die ("Error in query: $query. " . mysql_error());
 
/**********ACTIVITY LOG FUNCTIONALITY**********/
        $currentFile = $_SERVER["PHP_SELF"];
                                $ipAddress = $_SERVER["REMOTE_ADDR"];
                                $date = date("Y/m/d");
                                $escapedQuery = mysql_escape_string($query);
        // generate and execute query
        $activityQuery = "INSERT INTO activityLog(user, page, notes, query, errors, dateExecuted, ipAddress) VALUES('$userID', '$currentFile', 'Added new topic - $title', '$escapedQuery', '$SQLerror', '$date', '$ipAddress')";
 
        $activityResult = mysql_query($activityQuery) or die ("Error in query: $query. " . mysql_error());
/**********************************************/
 
        // print result
        echo '<h2>Update successful.</h2>';
?>
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js" type="text/javascript"></script>
 
<script>
$(document ).ready(function() {
parent.location.reload();
});
</script>
<?php
        // close database connection
        mysql_close($connection);
    }
    else
    {
   
    
        // errors found
        // print as list
        echo '<font size=-1>The following errors were encountered:';
        echo '<br>';
        echo '<ul>';
        for ($x=0; $x<sizeof($errorList); $x++)
        {
            echo "<li>$errorList[$x]";
        }
        echo '</ul></font><br /><a href=&amp;javascript: history.go(-1)&amp;>Back</a>';
    }
}
?>
</body>
</html>
 