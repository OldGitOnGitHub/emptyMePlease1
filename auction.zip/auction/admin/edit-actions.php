<html>
<head>
<basefont face="Verdana">
<title>auction admin edit</title>
</head>

<body>

<!-- standard page header begins -->
<p><p>

<table width="100%" cellspacing="0" cellpadding="5">
<tr>
    <td></td>
</tr>
<tr>
    <td bgcolor="#993333"><font size="-1" color="White">
    <b>AXA PPP Healthcare - Online Charity Auction</b></font>
    </td>
</tr>
</table>
<!-- standard page header ends -->

<?php
// includes
include('../includes/conf.php');
include('../includes/functions.php');

// form not yet submitted
// display initial form with values pre-filled
if (!$_POST['submit'])
{
     // check for record ID
     if ((!isset($_GET['id']) || trim($_GET['id']) == '')) 
     { 
         die('Missing record ID!'); 
     }

    // open database connection
    $connection = mysql_connect($host, $user, $pass) or die ('Unable to connect!');

    // select database
    mysql_select_db($db) or die ('Unable to select database!');

    // generate and execute query
    $id = $_GET['id'];
    $query = "SELECT LotNumber, DisplayedLotNumber, LotTitle, LotDescription, LotDonor, LotOpenTime, LotCloseTime, LotCurrentDisplayBid, LotWinner, LotPicture, AdditionalInfoLink FROM lots WHERE DisplayedLotNumber = '$id'";
    $result = mysql_query($query) or die ("Error in query: $query. " . mysql_error());
    
    // if a result is returned
    if (mysql_num_rows($result) > 0)
    {
        // turn it into an object
        $row = mysql_fetch_object($result);

        // print form with values pre-filled
?>
<table cellspacing="5" cellpadding="5">
<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST">
<input type="hidden" name="DisplayedLotNumber"  value="<?php echo $id; ?>">


<tr>
    <td valign="top"></td><font size="4">Lot Number</font></td>
    <td>
      <?php echo $row->LotNumber; ?>
	        <input size="5" maxlength="5" type="hidden" name="LotNumber" 
value="<?php echo $row->LotNumber; ?>">
    </td>
</tr>

<tr>
    <td valign="top"></td><font size="3">Displayed Lot Number</font></td>
    <td>
      <input size="5" maxlength="5" type="text" name="DisplayedLotNumber" 
value="<?php echo $row->DisplayedLotNumber; ?>">
    </td>
</tr>
<tr>
    <td valign="top"><font size="4">Lot Title</font></td>
    <td>
      <input size="66" maxlength="66" type="text" name="LotTitle"
      value="<?php echo $row->LotTitle; ?>">
    </td>
</tr>
<tr>
    <td valign="top"><font size="4">Lot Description</font></td>
    <td>
    
    <input size="150" maxlength="1000" type="text" name="LotDescription"
      value="<?php echo $row->LotDescription; ?>">
    
    
    </td>
</tr>


<tr>
    <td valign="top"><font size="4">Lot Donor</font></td>
    <td>
      <input size="150" maxlength="150" type="text" name="LotDonor"
      value="<?php echo $row->LotDonor; ?>">
    </td>
</tr>

<tr>
    <td valign="top"><font size="4">Lot Picture</font></td>
    <td>
      <input size="30" maxlength="30" type="text" name="LotPicture"
      value="<?php echo $row->LotPicture; ?>">
    </td>
</tr>

<tr>
    <td valign="top"><font size="4">Additional Info Link</font></td>
    <td>
      <input size="150" maxlength="150" type="text" name="AdditionalInfoLink"
      value="<?php echo $row->AdditionalInfoLink; ?>">
    </td>
</tr>

<tr>
    <td colspan=2>
      <input type="Submit" name="submit" value="Update">
    </td>
</tr>
</form>
</table>
<?php
    }
    // no result returned
    // print graceful error message
    else
    {
        echo '<font size=-1>That press release could not be located in our database.</font>';
    }
}
// form submitted
// start processing it
else
{
    // set up error list array
    $errorList = array();
    
    $LotNumber = $_POST['LotNumber'];
    $DisplayedLotNumber = $_POST['DisplayedLotNumber'];
    $LotTitle = $_POST['LotTitle'];
    $LotDescription = $_POST['LotDescription'];
    $LotDonor = $_POST['LotDonor'];
    $LotOpenTime = $_POST['LotOpenTime'];
    $LotCloseTime = $_POST['LotCloseTime'];
    $LotCurrentDisplayBid = $_POST['LotCurrentDisplayBid'];
    $LotWinner = $_POST['LotWinner'];
    $LotPicture = $_POST['LotPicture'];
    $AdditionalInfoLink = $_POST['AdditionalInfoLink'];
    $id = $_POST['DisplayedLotNumber'];
        
    // check for record ID
    if ((!isset($_POST['DisplayedLotNumber']) || trim($_POST['DisplayedLotNumber']) == '')) 
    {  
      die ('Missing record ID!'); 
    }

    // validate text input fields
    /*
     if (trim($_POST['LotNumber']) == '') 
    { 
      $errorList[] = 'Invalid entry: Lot Number'; 
    }
    */
    if (trim($_POST['DisplayedLotNumber']) == '') 
    { 
      $errorList[] = 'Invalid entry: Displayed Lot Number'; 
    }
    
    
    if (trim($_POST['LotTitle']) == '') 
    { 
      $errorList[] = "Invalid entry: Lot Title"; 
    }
    
    if (trim($_POST['LotDescription']) == '') 
    { 
      $errorList[] = "Invalid entry: Lot Description"; 
    }
    
    if (trim($_POST['LotDonor']) == '') 
    { 
      $errorList[] = "Invalid entry: Lot Donor"; 
    }
    
    if (trim($_POST['LotPicture']) == '') 
    { 
      $errorList[] = "Invalid entry: Lot Picture"; 
    }
    
    
    // check for errors
    // if none found...
    if (sizeof($errorList) == 0)
    {
        // open database connection
        $connection = mysql_connect($host, $user, $pass) or die ('Unable to connect!');

        // select database
        mysql_select_db($db) or die ('Unable to select database!');

        // generate and execute query
        $query = "UPDATE lots SET DisplayedLotNumber = '$DisplayedLotNumber', LotTitle = '$LotTitle', LotDescription = '$LotDescription', LotDonor = '$LotDonor', LotOpenTime = '$LotOpenTime', LotCloseTime = '$LotCloseTime', LotPicture = '$LotPicture', AdditionalInfoLink = '$AdditionalInfoLink' WHERE LotNumber = '$LotNumber'";
        $result = mysql_query($query) or die ("Error in query: $query. " . mysql_error());

        // print result
        echo '<font size=4>Update successful.';
        echo '<a href=list-actions.php>Go back to the Auction List</a>.</font>';

        // close database connection
        mysql_close($connection);
    }
    else
    {
        // errors occurred
        // print as list
        echo '<font size=4>The following errors were encountered:'; 
        echo '<br>';
        echo '<ul>';
        for ($x=0; $x<sizeof($errorList); $x++)
        
        {
            echo "<li>$errorList[$x]"; 
            
        }
        echo '</ul></font>';
        echo '<br>';
        echo '<br>';
        echo '<a href=list-actions.php>Go back to the Auction List</a>.</font>';
    
    }          
}

?>

<!-- standard page footer begins -->
<p>
<table width="100%" cellspacing="0" cellpadding="5">
<tr>
    <td align="center"><font size="-2">
    Few rights reserved. Visit  
    <a href="http://www.joining-dots.com"> 
    joining-dots</a> for more.</font></td>
</tr>
</table>
<!-- standard page footer ends -->

</body>
</html>