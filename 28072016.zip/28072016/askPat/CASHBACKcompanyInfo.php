<div class="companyInfoWrap">
<?php

// includes
include('conf.php');
include('userIDinclude.php'); 

// open database connection
$connection = mysql_connect($host, $user, $pass) or die ('Unable to connect!');

// select database
mysql_select_db($db) or die ('Unable to select database!');

$ID = $_GET["ID"];

// generate and execute query
$query = "SELECT * FROM CASHBACK_companies WHERE ID='".$ID."'";

$result = mysql_query($query) or die ("Error in query: $query. " . mysql_error());

// if records present
if (mysql_num_rows($result) > 0)
{
      // iterate through resultset
      // print title with links to edit and delete scripts
      while($row = mysql_fetch_object($result))
      {
      $parts = explode('/', $row->genericItem1date);
      $date1 = $parts[1].'/'.$parts[0].'/'. $parts[2];
      $parts = explode('/', $row->genericItem2date);
      $date2 = $parts[1].'/'.$parts[0].'/'. $parts[2];
      $parts = explode('/', $row->genericItem3date);
      $date3 = $parts[1].'/'.$parts[0].'/'. $parts[2];
      ?>
      <div class="nw corner"><div class="ne corner"><div class="sw corner"><div class="se corner">
      <div class="genericWrap">
      	<div>
      		<div class="genericItem one">
      			<div class="itemText"><?php echo $row->genericItem1; ?></div>
      		</div>

      		<div class="genericItem two">
      			<div class="itemText"><?php echo $row->genericItem2; ?></div>
      		</div>
 		
      		<div class="genericItem three">
      			<div class="itemText"><?php echo $row->genericItem3; ?></div>
      		</div>
	</div>
	<div style="clear:both;">
      		<div class="one<?php if ((time() - strtotime($date1)) >= 7889230) { ?> red<?php } 
      					elseif ((time() - strtotime($date1)) >= 2629740) { ?> amber<?php } 
      					else {?> green<?php } ?>">
      			<span>Updated <?php echo $row->genericItem1date; ?></span>
      		</div>

      		<div class="two<?php if ((time() - strtotime($date2)) >= 7889230) { ?> red<?php } 
      					elseif ((time() - strtotime($date2)) >= 2629740) { ?> amber<?php } 
      					else {?> green<?php } ?>">
      			<span>Updated <?php echo $row->genericItem2date; ?></span>
      		</div>
 		
      		<div class="three<?php if ((time() - strtotime($date3)) >= 7889230) { ?> red<?php } 
      					elseif ((time() - strtotime($date3)) >= 2629740) { ?> amber<?php } 
      					else {?> green<?php } ?>">
      			<span>Updated <?php echo $row->genericItem3date; ?></span>
      		</div>
	</div>
      	<br />
      		<h2 class="genInf">General Info  </h2><p class="generalInfo"> - <?php echo $row->generalInfo; ?></p><br />
      		<h2 class="webAdd">On the web</h2>&nbsp;<p class="webAddress">  - <a href="<?php echo $row->webAddress; ?>" title="<?php echo $row->name; ?> on the web"><?php echo $row->webAddress; ?></a></p>
      </div>
      </div></div></div></div>
      
       <script src="scripts/jquery-1.10.1.min.js" type="text/javascript"></script>
    
<script>
        
$(document).ready(function(){
     
/***********UPDATE SEARCH COUNT************/
var user = $.trim($("p.userInfo").attr("data"));
var time = (new Date).getTime();
$(".searchCount #count").load(encodeURI("searchCount.php?userID="+user+"&time="+time));
/******************************************/	

});

</script>

      <?php
      
      
      
      
      
      
/**********ACTIVITY LOG FUNCTIONALITY**********/
        $currentFile = $_SERVER["PHP_SELF"];
		$ipAddress = $_SERVER["REMOTE_ADDR"];
		$date = date("Y/m/d");
		$escapedQuery = mysql_escape_string($query);
        // generate and execute query
        $activityQuery = "INSERT INTO activityLog(user, page, notes, query, errors, dateExecuted, ipAddress) VALUES('$userID', '$currentFile', 'Searched for ".$row->name."', '$escapedQuery', '$SQLerror', '$date', '$ipAddress')";

        $activityResult = mysql_query($activityQuery) or die ("Error in query: $query. " . mysql_error());
/**********************************************/


      
      }
}
// if no records present
// display message
else
{
?>
      <h1>No topics currently available</h1>
<?php
}
?>
</div>