<html>
<body>
<h1>Main Auction Admin Pages</h1>
<!-- Links to main admin pages -->
<ul>
<li><font size="4"><a href="add-actions.php">Add a New Item</a></font>   </li>
<li><font size="4"><a href="list-actions.php">Edit and Delete Existing Item</a></font>   </li>
</ul>
</body>
</html>