<?php
// 'Not sure what's supposed to be going on here ...
header("Cache-Control: no-cache, must-revalidate"); 
header("Expires: Mon, 26 Jul 1997 05:00:00 GMT");
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="en" xml:lang="en">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<meta name="description" content="Details of the annual intranet auction for 2011 in aid of Headway." />
<title>Charity auction 2011</title>
<?php
$document_owner="graham.thomas@axa-ppp.co.uk";
$devolved_publisher="matthew.newman@joining-dots.com";
include($_SERVER['DOCUMENT_ROOT']."/intranet/global/includes/page-scripts-styles.html");
?>
<script type="text/javascript">
navLocation="Time out:Auction:";
</script>


<style type="text/css">

<!--
.style1 {
	color: #FF0000;
	font-weight: bold;
}
.style2 {color: #FF0000}
-->

.floater-r{
float:right;
margin-left:0.5em;
}

.hlogo {
	padding:20px;
}

</style>
</head>
<body class="col3">
	<div id="wrapper">
        <?php
        //include($_SERVER['DOCUMENT_ROOT']."/intranet/global/includes/page-header.php");
        include($_SERVER['DOCUMENT_ROOT']."/intranet/timeout/sports-and-social/local-nav.html");
        ?>

        <div id="header">
            <!--
            <a href="#" rel="home" id="logo"><img src="/intranet/global/imgs/logo.gif" alt="healthnet" /></a>
            -->

            <div id="hlogo">
            	<img src="/intranet/global/imgs/logo.gif" alt="healthnet" class="hlogo"/>
            </div>
		</div>

		<?php
        //include($_SERVER['DOCUMENT_ROOT']."/intranet/timeout/sports-and-social/local-nav.html");
        ?>
        
        <div class="presentational1"></div>
		<div id="content">
            <!-- Code to check we can get information items from the database -->
            <?php
            // includes
            include('includes/conf.php');
            include('includes/functions.php');
            
            // open database connection
            $connection = mysql_connect($host, $user, $pass) or die ('Unable to connect!');
            
            // select database
            mysql_select_db($db) or die ('Unable to select database!');
            
            ?>
            <!-- end of Code to check we can get information items from the database -->


            <h1>Charity auction - 2011 </h1>
            
            <img alt="Charity Auction" src="images/gavel.gif" border="0" height=150px class="floater-r"/>
            
            <p>Welcome to the home page for AXA PPP healthcare's 2011 charity auction.</p>

            <!-- START OF END OF AUCTION MESSAGE -->
            <!--
            <p>
            The 2010 Intranet Charity Auction has now closed. Thank you to everyone who placed a bid or donated an item. 
            </p>
            
            <p>
            With the honey orders included, we have raised a whopping <b>�4,309.14</b> for charity � the vast bulk of which will be donated to our annual chosen charity, 
            <a href="http://www.kentairambulance.co.uk">Kent Air Ambulance</a> (please note that a modest proportion of the money rasied from honey sales will go to a local bee conservation charity).
            Winning bidders will be contacted very shortly to arrange payment and collection of their item.
            </p>
            -->
            <!-- END OF END OF AUCTION MESSAGE -->

            <h3>Auction Items</h3>
            
            <p>Please browse through the items below and if you wish to make a bid, select the <em>Bid now</em> button beneath the item in question. 
            NB - please state if you wish your bid to remain anonymous on the site.</p>
            
            <p>All bids must be made in whole pounds - if your bid contains an odd number of pence it will be rounded up to the nearest pound.</p>
            
            <p>Like eBay, bidding will be done for you by proxy. </p>
            
            <p><strong>Always bid the maximum you are willing to pay</strong> for the item. This saves everyone time and effort, you in particular. </p>
            
            <p>If your bid is the highest we will only ever keep it at &pound;1 more than the next highest bidder. Highest bidders at the end of the auction period will only ever pay &pound;1 more than the next highest bidder for their item. </p>
            
            <p>In the case of two bids of exactly the same amount, the second bidder will be asked to bid again, if they want to. </p>
            
            <p><strong>The auction closes at 12.00pm on Monday 31st October.</strong> </p>
            
            <p> All proceeds from the auction will be donated to this year's chosen charity, <br /> 
            <a href="http://www.headway.org.uk/home.aspx">Headway</a>.</p>
            
            
            <p><strong>Graham Thomas, Community Officer</strong></p>

<!-- start of lot item display -->
<?php
// generate and execute the database query

$query = "SELECT lots.LotNumber, DisplayedLotNumber, LotTitle, LotDescription, LotDonor, LotCurrentDisplayBid, BidderName, LotPicture, AdditionalInfoLink FROM lots LEFT JOIN bids ON lots.LotCurrentActiveBid = bids.BidNumber ORDER BY lots.DisplayedLotNumber";

$result = mysql_query($query) or die ("Error in query: $query. " . mysql_error());

// if records present
if (mysql_num_rows($result) > 0)
{
      // iterate through resultset
      while($row = mysql_fetch_object($result))
      {
      ?>
      
<form action="submit.php" method="post">
<div>
<!-- <img alt="" src="images/odeon1.jpg" border="0" height=50px/> -->

<!-- show images on the joining-dots server -->
 <img alt="" src="images/<?php echo ($row->LotPicture); ?>" border="0" height=80px/> 

<!-- show images on the healthnet server -->
<!--  <img alt="" src="http://www.intranet.pppgroup.co.uk/intranet/timeout/sports-and-social/auction/images/2010/<?php echo ($row->LotPicture); ?>" border="0" height=150px/>  -->


</div>
<input type="hidden" name="bidlot" value="<?php echo $row->LotNumber; ?>" />	
<table>
<caption>
Lot <?php echo $row->DisplayedLotNumber; ?>: <?php echo ($row->LotTitle); ?> 
</caption>
<tr>
<th scope="row">Item</th>
<td><?php echo ($row->LotTitle); ?></td>
</tr>
<tr>
<th scope="row">Kindly donated by</th>
<td><?php echo($row->LotDonor); ?></td>
</tr>
<tr>
<th scope="row">Description</th>
<td><?php echo($row->LotDescription); ?></td>
</tr>
<tr>
<th scope="row">Winning bid </th>
<td>&pound;<?php echo((int)$row->LotCurrentDisplayBid); ?> <?php echo !empty($row->BidderName) ? '- ' . $row->BidderName : ''; ?></td>
</tr>

<?php if (!empty($row->AdditionalInfoLink)): ?>
<tr>
<th scope="row">Additional Information </th>
<td><a href="<?php echo $row->AdditionalInfoLink; ?>">Click here</a> </td>
</tr>
<?php endif; ?>

<tr>
<td colspan="2"><input id="formsubmit" type="submit" name="submit" value="Bid now!" /></td>
</tr>

</table>

<p>&nbsp;</p>  

</form>      
      <?php
      }
}
// if no records present
// display message
else
{
?>
      <font size="-1">No items currently available</font><p>
<?php
}

// close connection
mysql_close($connection);
?>
<!-- start of lot item display -->

<!--
<h2> Tell 'em about the honey</h2>
<img alt="healthcare honey" src="http://www.intranet.pppgroup.co.uk/intranet/timeout/sports-and-social/auction/images/2010//honey.jpg" border="0" height=150px class="floater-r"/>
<p> 
We have 48 jars of top quality honey available. 
The honey has been harvested from our Phillips House hive.
These have been kindly donated by Business Service, the AXA PPP beekeepers, and - of course - the bees.  
These are available to the first 48 people who bid �10 (or more if you are feeling particularly generous!)
Limited to one jar per person.
</p>
<p>
To get your jar simply select this 
<a href="mailto:axappphoneyjars@joining-dots.com?&subject=I%20want%20honey&body=I would like a jar of PPP honey and I'm prepared to pay �? for it.">I want honey</a> link and replace
the question mark (in the auto-generated e-mail) with the amount of money you'll pay for your honey. If you're one of the first 48 employees who've bid more than �10 we will send you a mail to let you know
you've been successful. If you aren't one of the first 48 we'll send you a mail with our commiserations. If your mail contains an offer of less than �10, we'll politely decline it. 
</p>
-->

</div>
<div class="presentational2"></div>


<div id="related-links">
<h2><b>Related</b> links</h2>
<ul>
<li><a href="http://www.headway.org.uk/home.aspx">Headway</a></li>
</ul>
</div>


<?php
include($_SERVER['DOCUMENT_ROOT']."/intranet/global/includes/page-last-updated.php");
include($_SERVER['DOCUMENT_ROOT']."/intranet/global/includes/footer.php");
?>
</div>
</body>
</html>