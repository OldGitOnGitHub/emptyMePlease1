<?php
// 'Not sure what's supposed to be going on here ...
header("Cache-Control: no-cache, must-revalidate"); 
header("Expires: Mon, 26 Jul 1997 05:00:00 GMT");
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="en" xml:lang="en">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<meta name="description" content="Details of the annual intranet auction for 2010. The intranet auction returned in October 2010 and is in aid of Kent Air Ambulance." />
<title>Charity auction listing</title>
<?php
$document_owner="graham.thomas@axa-ppp.co.uk";
$devolved_publisher="matthew.newman@joining-dots.com";
include($_SERVER['DOCUMENT_ROOT']."/intranet/global/includes/page-scripts-styles.html");
?>
<script type="text/javascript">
navLocation="Time out:Auction:";
</script>

<style type="text/css">
<!--
.style1 {
	color: #FF0000;
	font-weight: bold;
}
.style2 {color: #FF0000}
-->

.floater-r{
float:right;
margin-left:0.5em;
}

.hlogo {
	padding:20px;
}

</style>
</head>
<body class="col3">

<div id="wrapper">
<!--
<?php
include($_SERVER['DOCUMENT_ROOT']."/intranet/global/includes/page-header.php");
include($_SERVER['DOCUMENT_ROOT']."/intranet/timeout/sports-and-social/local-nav.html");
?>
-->

<div id="header">
<!--
<a href="#" rel="home" id="logo"><img src="/intranet/global/imgs/logo.gif" alt="healthnet" /></a>
-->
<!--
<div id="hlogo">
<img src="/intranet/global/imgs/logo.gif" alt="healthnet" class="hlogo"/>
</div>
-->

</div>
<!--
<?php
include($_SERVER['DOCUMENT_ROOT']."/intranet/timeout/sports-and-social/local-nav.html");
?>
-->
<div class="presentational1"></div>

<div id="content">

<!-- Code to check we can get information items from the database -->
<?php
// includes
include('../includes/conf.php');
include('../includes/functions.php');

// open database connection
$connection = mysql_connect($host, $user, $pass) or die ('Unable to connect!');

// select database
mysql_select_db($db) or die ('Unable to select database!');

?>
<!-- end of Code to check we can get information items from the database -->


<h1>Charity auction - Listing for Graham </h1>

<img alt="Charity Auction" src="../images/gavel.gif" border="0" height=150px class="floater-r"/>


<!-- start of a lot item -->
<?php
// generate and execute the database query

$query = "SELECT lots.LotNumber, DisplayedLotNumber, LotTitle, LotDescription, LotDonor, LotCurrentDisplayBid, BidderName, BidderEmail, LotPicture, AdditionalInfoLink FROM lots LEFT JOIN bids ON lots.LotCurrentActiveBid = bids.BidNumber ORDER BY lots.DisplayedLotNumber";

$result = mysql_query($query) or die ("Error in query: $query. " . mysql_error());

// if records present
if (mysql_num_rows($result) > 0)
{
      // iterate through resultset
      while($row = mysql_fetch_object($result))
      {
      ?>
      
<form action="../submit.php" method="post">
<div>
<!-- <img alt="" src="images/odeon1.jpg" border="0" height=50px/> -->

<!-- show images on the joining-dots server -->
<!-- <img alt="" src="images/<?php echo ($row->LotPicture); ?>" border="0" height=50px/> -->

<!-- show images on the healthnet server -->
 <img alt="" src="http://www.intranet.pppgroup.co.uk/intranet/timeout/sports-and-social/auction/images/2010/<?php echo ($row->LotPicture); ?>" border="0" height=150px/> 


</div>
<input type="hidden" name="bidlot" value="<?php echo $row->LotNumber; ?>" />	
<table>
<caption>
Lot <?php echo $row->DisplayedLotNumber; ?>: <?php echo ($row->LotTitle); ?> 
</caption>
<tr>
<th scope="row">Item</th>
<td><?php echo ($row->LotTitle); ?></td>
</tr>
<tr>
<th scope="row">Kindly donated by</th>
<td><?php echo($row->LotDonor); ?></td>
</tr>
<tr>
<th scope="row">Description</th>
<td><?php echo($row->LotDescription); ?></td>
</tr>

<tr>
<th scope="row">Winning bid </th>
<td>&pound;<?php echo((int)$row->LotCurrentDisplayBid); ?> <?php echo !empty($row->BidderName) ? '- ' . $row->BidderName : ''; ?></td>
</tr>

<tr>
<th scope="row">e-Mail </th>
<td> <?php echo !empty($row->BidderEmail) ? ' ' . $row->BidderEmail : ''; ?></td>
</tr>


<?php if (!empty($row->AdditionalInfoLink)): ?>
<tr>
<th scope="row">Additional Information </th>
<td><a href="<?php echo $row->AdditionalInfoLink; ?>">Click here</a> </td>
</tr>
<?php endif; ?>

<!--
<tr>
<td colspan="2"><input id="formsubmit" type="submit" name="submit" value="Bid now!" /></td>
</tr>
-->

</table>

<p>&nbsp;</p>  

</form>      
      <?php
      }
}
// if no records present
// display message
else
{
?>
      <font size="-1">No items currently available</font><p>
<?php
}

// close connection
mysql_close($connection);
?>

<h2> Tell 'em about the honey</h2>
<img alt="healthcare honey" src="http://www.intranet.pppgroup.co.uk/intranet/timeout/sports-and-social/auction/images/2010//honey.jpg" border="0" height=150px class="floater-r"/>
<p> 
We have 48 jars of top quality honey available. 
The honey has been harvested from our Phillips House hive.
These have been kindly donated by Business Service, the AXA PPP beekeepers, and - of course - the bees.  
These are available to the first 48 people who bid �10 (or more if you are feeling particularly generous!)
Limited to one jar per person.
</p>
<p>
To get your jar simply select this 
<a href="mailto:axappphoneyjars@joining-dots.com?&subject=I%20want%20honey&body=I would like a jar of PPP honey and I'm prepared to pay �? for it.">I want honey</a> link and replace
the question mark (in the auto-generated e-mail) with the amount of money you'll pay for your honey. If you're one of the first 48 employees who've bid more than �10 we will send you a mail to let you know
you've been successful. If you aren't one of the first 48 we'll send you a mail with our commiserations. If your mail contains an offer of less than �10, we'll politely decline it. 
</p>


<!-- old code for showing lots -->
<!--
<form action="submit.php" method="post">
<div><img alt="" src="images/2009/lot1.jpg" border="0" /></div>
<input type="hidden" name="bidlot" value="lot 1: guitar lesson" />	
<table>
<caption>
Lot 1: Guitar experience 
</caption>
<tr>
<th scope="row">Item</th>
<td>One hour guitar session </td>
</tr>
<tr>
<th scope="row">Kindly donated by</th>
<td>Nick Harding</td>
</tr>
<tr>
<th scope="row">Description</th>
<td>60 minutes playing on a professional guitar rig with me as your �techy�. I�ll set up the rig by 17.30 in a meeting room and you can let your Clapton licks and Hendrix tricks transform the room into stadium filled with greasy-faced fans shouting something that you don�t quite understand. Tuition available, but your bid should reflect this! </td>
</tr>
<tr>
<th scope="row">Highest bid / bidder &pound;</th>
<td>Anonymous bidder - &pound;10 </td>
</tr>
<tr>
<td colspan="2"><input id="formsubmit" type="submit" name="submit" value="Bid now!" /></td>
</tr>
</table>
<p>&nbsp;</p>  
</form>
-->
<!-- end of old code for showing lots -->


</div>
<div class="presentational2"></div>


<div id="related-links">
<h2><b>Related</b> links</h2>
<ul>
<li><a href="http://www.kentairambulance.co.uk/">Kent Air Ambulance</a></li>
</ul>
</div>


<?php
include($_SERVER['DOCUMENT_ROOT']."/intranet/global/includes/page-last-updated.php");
include($_SERVER['DOCUMENT_ROOT']."/intranet/global/includes/footer.php");
?>
</div>
</body>
</html>