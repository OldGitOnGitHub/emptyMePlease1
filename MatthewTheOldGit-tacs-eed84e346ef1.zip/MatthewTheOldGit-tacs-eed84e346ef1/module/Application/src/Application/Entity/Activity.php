<?php
namespace Application\Entity;

use Doctrine\ORM\Mapping as ORM;
use Doctrine\Common\Collections\Collection as Collection;
use Zend\Form\Annotation;

/** @ORM\Entity
*   @ORM\Table(name="activity")
*   @Annotation\Name("activity")
*/
class Activity
{

    const TYPE_DOWNLOAD = 1;
    const TYPE_AUDIT = 2;
    
    /**
    *   @ORM\Id
    *   @ORM\GeneratedValue(strategy="AUTO")
    *   @ORM\Column(type="integer")
    *   @Annotation\Exclude()
    */
    protected $id;

    /**  
    *   @ORM\Column(type="integer", nullable=false)
    *   @Annotation\Exclude()
    *   ORM\ManyToOne(targetEntity="Asset")
    *   ORM\JoinColumn(name="asset_id", referencedColumnName="id")
    */
    protected $assetId;

    /** @ORM\Column(type="datetime", nullable=false) 
    *   @Annotation\Required(false)
    *   @Annotation\Type("Zend\Form\Element\Date")
    *   @Annotation\Validator({"name":"Date"})
    */
    protected $created;

    /** @ORM\Column(type="string", nullable=false) 
    *   @Annotation\Required(true)
    *   @Annotation\Filter({"name":"StringTrim"})
    *   @Annotation\Filter({"name":"StripTags"})
    *   @Annotation\Validator({"name":"StringLength", "options":{"min":1, "max":255}})
    *   @Annotation\Type("Zend\Form\Element\Text")
    *   @Annotation\Options({"label":"Name"})     
    */
    protected $userName;

    /** @ORM\Column(type="string", nullable=false) 
    *   @Annotation\Required(true)
    *   @Annotation\Filter({"name":"StringTrim"})
    *   @Annotation\Filter({"name":"StripTags"})
    *   @Annotation\Validator({"name":"EmailAddress"})
    *   @Annotation\Type("Zend\Form\Element\Text")
    *   @Annotation\Options({"label":"Email address"})     
    */
    protected $userEmail;

    /** @ORM\Column(type="text", nullable=true) 
    *   @Annotation\Required(false)
    *   @Annotation\Filter({"name":"StringTrim"})
    *   @Annotation\Filter({"name":"StripTags"})
    *   @Annotation\Validator({"name":"StringLength", "options":{"min":1, "max":255}})
    *   @Annotation\Type("Zend\Form\Element\Textarea")
    *   @Annotation\Options({"label":"Intended use"})     
    */
    protected $message;
    
    /** @ORM\Column(type="string", nullable=false) 
    *   @Annotation\Required(false)
    *   @Annotation\Filter({"name":"StringTrim"})
    *   @Annotation\Filter({"name":"StripTags"})
    *   @Annotation\Validator({"name":"Ip"})
    *   @Annotation\Type("Zend\Form\Element\Text")
    */
    protected $sourceIpAddress;
    
    /** @ORM\Column(type="integer", nullable=false) 
    *   @Annotation\Exclude()
    */
    protected $type;

    /** 
    *   @Annotation\Required(true)
    *   @Annotation\Type("Zend\Form\Element\Csrf")
    */
    protected $csrf;
        
    /** 
    *   @Annotation\Attributes({"value":"Submit"})
    *   @Annotation\Type("Zend\Form\Element\Submit")
    */
    protected $submit;
    
    public function getId()
    {
        return $this->id;
    }

    public function setId($value)
    {
        $this->id = $value;
    }    
    
    public function getAssetId()
    {
        return $this->assetId;
    }

    public function setAssetId($value)
    {
        $this->assetId = $value;
    }    

    public function getCreated()
    {
        return $this->created;
    }

    public function setCreated($value)
    {
        $this->created = $value;
    }    

    public function getUserName()
    {
        return $this->userName;
    }

    public function setUserName($value)
    {
        $this->userName = $value;
    }    
    
    public function getUserEmail()
    {
        return $this->userEmail;
    }

    public function setUserEmail($value)
    {
        $this->userEmail = $value;
    }    

    public function getMessage()
    {
        return $this->message;
    }

    public function setMessage($value)
    {
        $this->message = $value;
    }    
    
    public function getSourceIpAddress()
    {
        return $this->sourceIpAddress;
    }

    public function setSourceIpAddress($value)
    {
        $this->sourceIpAddress = $value;
    }    

    public function getType()
    {
        return $this->type;
    }

    public function setType($value)
    {
        $this->type = $value;
    }    
    
}