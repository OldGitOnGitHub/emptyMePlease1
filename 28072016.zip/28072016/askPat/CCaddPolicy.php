<!DOCTYPE html>
<meta http-equiv="X-UA-Compatible" content="IE=edge" />
<?php include('userIDinclude.php'); ?>

<html>
<head>

<title>Add a policy</title>

<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.css">
<link rel="stylesheet" type="text/css" href="styles.css">

<script src="scripts/jquery-1.10.1.min.js" type="text/javascript"></script>
<script src="ckeditor4.5.9/ckeditor.js" type="text/javascript"></script>


</head>
<body class="formPage">

<?php
if (!$_POST['submit'])
{

// includes
include('conf.php');

// open database connection
$connection = mysql_connect($host, $user, $pass) or die ('Unable to connect!');

// select database
mysql_select_db($db) or die ('Unable to select database!');

?>

<h1>Add a policy</h1>
<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST">
<label>Name</label><input name="name" type="text"/>
<?php
// generate and execute query
$Dquery = "SELECT ID, name FROM CANCER_companies ORDER BY name ASC";

$Dresult = mysql_query($Dquery) or die ("Error in query: $Dquery. " . mysql_error());

// if records present
if (mysql_num_rows($Dresult) > 0)
{?>
<label>Company</label>
<select name="companyID">
<?php
      // iterate through resultset
      // print title with links to edit and delete scripts
      while($Drow = mysql_fetch_object($Dresult))
      {
      ?>
      <option value="<?php echo $Drow->ID; ?>"><?php echo $Drow->name; ?></option> 
      <?php
      }
      ?>
</select>
<?php
}
?>
<h4>Cash benefits</h4>
<label>Cash payment on first diagnosis of cancer</label><textarea class="ckeditor" name="Benefit1" rows="2" cols="8"></textarea>
<label>Cash payment on first diagnosis of non-melanoma skin cancer</label><textarea class="ckeditor" name="Benefit2" rows="2" cols="8"></textarea>
<h4>Treatments</h4>
<label>Cash payment on first diagnosis of non-melanoma skin cancer</label><textarea class="ckeditor" name="Benefit3" rows="2" cols="8"></textarea>
<h4>Support</h4>
<label>Expert Help</label><textarea class="ckeditor" name="Benefit4" rows="2" cols="8"></textarea>

<br />
<input type="submit" value="Submit" name="submit">
</form>
</form>
<?php
// close connection
mysql_close($connection);
?>



<?php
}
else
{
    // includes
    include('conf.php');

    // set up error list array
    $errorList = array();
    
$name = $_POST['name'];
$companyID = $_POST['companyID'];
$Benefit1 = $_POST['Benefit1'];
$Benefit2 = $_POST['Benefit2'];
$Benefit3 = $_POST['Benefit3'];
$Benefit4 = $_POST['Benefit4'];

    
    	
    // validate text input fields
    if (trim($_POST['name']) == '') 
    { 
        $errorList[] = 'Invalid entry: Name'; 
    }

    // check for errors
    // if none found...
    if (sizeof($errorList) == 0)
    {
        // open database connection
        $connection = mysql_connect($host, $user, $pass) or die ('Unable to connect!');

        // select database
        mysql_select_db($db) or die ('Unable to select database!');

        // generate and execute query
        $query = "INSERT INTO CANCER_policies (name, companyID, Benefit1, Benefit2, Benefit3, Benefit4) VALUES ('$name', '$companyID', '$Benefit1', '$Benefit2', '$Benefit3', '$Benefit4')";


        $result = mysql_query($query) or die ("Error in query: $query. " . mysql_error());

/**********ACTIVITY LOG FUNCTIONALITY**********/
        $currentFile = $_SERVER["PHP_SELF"];
		$ipAddress = $_SERVER["REMOTE_ADDR"];
		$date = date("Y/m/d");
		$escapedQuery = mysql_escape_string($query);
        // generate and execute query
        $activityQuery = "INSERT INTO activityLog(user, page, notes, query, errors, dateExecuted, ipAddress) VALUES('$userID', '$currentFile', 'Added new policy.', '$escapedQuery', '$SQLerror', '$date', '$ipAddress')";

        $activityResult = mysql_query($activityQuery) or die ("Error in query: $query. " . mysql_error());
/**********************************************/

        // print result
        echo '<h2>Update successful.</h2><br><a href="admin.php">Return to main admin screen</a>';

        // close database connection
        mysql_close($connection);
    }
    else
    {
    
    
        // errors found
        // print as list
        echo '<font size=-1>The following errors were encountered:'; 
        echo '<br>';
        echo '<ul>';
        for ($x=0; $x<sizeof($errorList); $x++)
        {
            echo "<li>$errorList[$x]";
        }
        echo '</ul></font><br /><a href=&amp;javascript: history.go(-1)&amp;>Back</a>';
    }
}
?>
</body>
</html>