<?php
namespace Application\Controller;

use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;
use Application\Entity\Asset as Asset;
use Application\Entity\Activity as Activity;
use Application\Form\DateRangeForm as DateRangeForm;
use Application\Form\ConfirmationForm as ConfirmationForm;
use Zend\Form\Annotation\AnnotationBuilder;
use Zend\Mail\Message;
use Zend\Mime\Message as MimeMessage;
use Zend\Mime\Part;
use Zend\Mime\Mime;
use Application\Mail\Transport\Sendmail;
use Zend\Mail\Transport\Smtp as SmtpTransport;
use Zend\Mail\Transport\SmtpOptions;

class ReportController extends AbstractActionController
{

    const TYPE_PENDING_AUDIT = 1;
    
    const TYPE_PENDING_CONSENT_REVIEW = 2;

    public function indexAction()
    {
        return new ViewModel();
    }
    
    public function usageAction()
    { 
        $id = (int) $this->params()->fromRoute('id', 0);
        if (!$id) {
            return $this->redirect()->toRoute('home');
        }

        $format = (string) $this->params()->fromRoute('format', null);
        
        $entityManager = $this->getServiceLocator()->get('Doctrine\ORM\EntityManager');
        $asset = $entityManager->getRepository('Application\Entity\Asset')
                               ->find($id);          
        if (!$asset) {
            $this->flashMessenger()
                 ->setNamespace('error')
                 ->addMessage('The requested report could not be generated.');
            return $this->redirect()->toRoute('home');                 
        } 
    
        $entityManager = $this->getServiceLocator()->get('Doctrine\ORM\EntityManager');
        $activities = $entityManager->getRepository('\Application\Entity\Activity')
                                ->findBy(array('type' => Activity::TYPE_DOWNLOAD, 'assetId' => $id), array('created' => 'DESC'));   

        $view = new ViewModel(array(
            'asset' => $asset,
            'activities' => $activities
        ));
        if (strtolower($format) == 'csv') {
            return $this->produceCsv('application/report/usage.csv.phtml', 'usage-' . $asset->getId(), $view);
        } 
        $view->setTemplate('application/report/usage.phtml');
        return $view;
    }

    public function pendingAuditAction()
    { 
        return $this->pendingAction(ReportController::TYPE_PENDING_AUDIT);
    }

    public function pendingConsentReviewAction()
    { 
        return $this->pendingAction(ReportController::TYPE_PENDING_CONSENT_REVIEW);
    }
    
    public function pendingAction($type)
    { 
        $format = (string) $this->params()->fromRoute('format', null);
        $id = (int) $this->params()->fromRoute('id', 0);
        
        switch($type) {
            case ReportController::TYPE_PENDING_AUDIT:
                $title = 'In Need of Audit';
                $dateStr = 'now - 6 month';
                $conditions = array('status' => Asset::STATUS_ACTIVE);
                break;
            case ReportController::TYPE_PENDING_CONSENT_REVIEW:
                $title = 'In Need of Consent Review';
                $dateStr = 'now - 24 month';
                $conditions = array('status' => Asset::STATUS_ACTIVE, 'consentUpdateStatus' => 1);
                break;
        }

        $entityManager = $this->getServiceLocator()->get('Doctrine\ORM\EntityManager');
        $assets = $entityManager->getRepository('Application\Entity\Asset')
                                ->findByAudited(new \DateTime($dateStr), $conditions);

        foreach ($assets as $asset) {
            $downloads = $entityManager->getRepository('\Application\Entity\Activity')
                                        ->findBy(array('type' => Activity::TYPE_DOWNLOAD, 'assetId' => $asset->getId()), array('created' => 'DESC'));   
            $audits = $entityManager->getRepository('\Application\Entity\Activity')
                                        ->findBy(array('type' => Activity::TYPE_AUDIT, 'assetId' => $asset->getId()), array('created' => 'DESC'));   
            $asset->setDownloads($downloads); 
            $asset->setAudits($audits);             
        }
        
        $view = new ViewModel(array(
            'title' => $title,
            'results' => $assets,
            'assetPlugin' => $this->assetPlugin(),
            'type' => $type,
            'action' => $this->getActionName(), 
        ));

        if (strtolower($format) == 'csv') {
            return $this->produceCsv('application/report/pending.csv.phtml', $this->getActionName(), $view);
        } 
        $view->setTemplate('application/report/pending.phtml');
        return $view;
    }

    public function lapsedMembersAction()
    { 
        $format = (string) $this->params()->fromRoute('format', null);
        $id = (int) $this->params()->fromRoute('id', 0);

        $entityManager = $this->getServiceLocator()->get('Doctrine\ORM\EntityManager');
        $builder = new AnnotationBuilder();
        $form = $builder->createForm(new DateRangeForm());

        $assets = array();
        
        $request = $this->getRequest();        
        if ($request->isPost()) {
            $form->setData($request->getPost());

            if ($form->isValid()) {
                $validatedData = $form->getData();
                $qb = $entityManager->createQueryBuilder();      
                $qb->select('a')
                   ->from('Application\Entity\Asset', 'a')
                   ->where('a.memberStatus = ?1')
                   ->andWhere('a.status = ?2')
                   ->setParameter(1, 0)
                   ->setParameter(2, Asset::STATUS_ACTIVE);
                
                  if ($validatedData['from']) {
                      $qb->andWhere('a.memberStatusUpdated > ?3');
                      $qb->setParameter(3, $validatedData['from']);
                  }
                
                  if ($validatedData['to']) {
                      $qb->andWhere('a.memberStatusUpdated < ?4');
                      $qb->setParameter(4, $validatedData['to']);
                  }

                $query = $qb->getQuery();
                $assets = $query->getResult();    
                foreach ($assets as $asset) {
                    $downloads = $entityManager->getRepository('\Application\Entity\Activity')
                                                ->findBy(array('type' => Activity::TYPE_DOWNLOAD, 'assetId' => $asset->getId()), array('created' => 'DESC'));   
                    $asset->setDownloads($downloads); 
                }
                  
            } else {
                $messages = $form->getMessages();
            }    
        }        
        
        
        $view = new ViewModel(array(
            'form' => $form,
            'results' => $assets,
            'assetPlugin' => $this->assetPlugin(),
            'action' => $this->getActionName(), 
        ));

        if (strtolower($format) == 'csv') {
            return $this->produceCsv('application/report/lapsed-members.csv.phtml', $this->getActionName(), $view);
        } 
        $view->setTemplate('application/report/lapsed-members.phtml');
        return $view;
    }

    public function exportDatabaseAction()
    { 
        $format = (string) $this->params()->fromRoute('format', 'csv');

        $entityManager = $this->getServiceLocator()->get('Doctrine\ORM\EntityManager');
        $assets = $entityManager->getRepository('Application\Entity\Asset')
                                ->findBy(array(), array('created' => 'DESC'));
        
        foreach ($assets as $asset) {
            $audits = $entityManager->getRepository('\Application\Entity\Activity')
                                        ->findBy(array('type' => Activity::TYPE_AUDIT, 'assetId' => $asset->getId()), array('created' => 'DESC'));   
            $asset->setAudits($audits); 
        }
        
        $view = new ViewModel(array(
            'results' => $assets,
            'assetPlugin' => $this->assetPlugin(),
        ));

        return $this->produceCsv('application/report/export-database.csv.phtml', $this->getActionName(), $view);
    }

    public function downloadCountsAction()
    { 
        $format = (string) $this->params()->fromRoute('format', null);

        $entityManager = $this->getServiceLocator()->get('Doctrine\ORM\EntityManager');
        $assets = $entityManager->getRepository('Application\Entity\Asset')
                                ->findBy(array(), array('created' => 'DESC'));
        
        $assetCounts = array();
        $assetData = array();
        foreach ($assets as $asset) {
            $downloads = $entityManager->getRepository('\Application\Entity\Activity')
                                        ->findBy(array('type' => Activity::TYPE_DOWNLOAD, 'assetId' => $asset->getId()), array('created' => 'DESC'));   
            $assetCounts[$asset->getId()] = count($downloads);
            $assetData[$asset->getId()] = $asset;
        }
        
        arsort($assetCounts);
        $view = new ViewModel(array(
            'results' => $assetData,
            'counts' => $assetCounts,
            'assetPlugin' => $this->assetPlugin(),
        ));

        if (strtolower($format) == 'csv') {
            return $this->produceCsv('application/report/download-counts.csv.phtml', $this->getActionName(), $view);
        } 
        $view->setTemplate('application/report/download-counts.phtml');
        return $view;
    }
    
    public function notifyAction() 
    {
        $id = (int) $this->params()->fromRoute('id', 0);
        if (!$id) {
            return $this->redirect()->toRoute('reports');
        }

        $format = (string) $this->params()->fromRoute('format', null);
               
        $entityManager = $this->getServiceLocator()->get('Doctrine\ORM\EntityManager');
        $asset = $entityManager->getRepository('\Application\Entity\Asset')
                               ->find($id);
        if (!$asset) {
            $this->flashMessenger()
                 ->setNamespace('error')
                 ->addMessage('The requested notification could not be sent.');
            return $this->redirect()->toRoute('reports');                 
        }        
        $assetMetadata = $this->assetPlugin()->getAssetMetadataByType($asset->getType());
        if ($asset->getStatus() == Asset::STATUS_INACTIVE) {
            $this->flashMessenger()
                 ->setNamespace('error')
                 ->addMessage('The requested ' . strtolower($assetMetadata['labels'][0]) . ' has been archived and is no longer available.');
            return $this->redirect()->toRoute('reports');                 
        } 
        
        $builder = new AnnotationBuilder();
        $form = $builder->createForm(new ConfirmationForm());
        $request = $this->getRequest();        
        
        if ($request->isPost()) {
            $form->setData($request->getPost());
            if ($form->isValid()) {
                $validatedData = $form->getData();
                if ($validatedData['confirmation'] == '1') {
                
                    $audits = $entityManager->getRepository('\Application\Entity\Activity')
                                                ->findBy(array('type' => Activity::TYPE_AUDIT, 'assetId' => $asset->getId()), array('created' => 'DESC'));   
                    $asset->setAudits($audits);  
                    $downloads = $entityManager->getRepository('\Application\Entity\Activity')
                                                ->findBy(array('type' => Activity::TYPE_DOWNLOAD, 'assetId' => $asset->getId()), array('created' => 'DESC'));   
                    $asset->setDownloads($downloads); 

                    switch ($format) {
                      case 'lapsed-members':
                          $template = 'lapsed-members.email.phtml';
                          $subject = 'Your ' . strtolower($assetMetadata['labels'][0]) . ' member has lapsed - TACS';
                          break;
                      case 'pending-audit':
                          $template = 'pending-audit.email.phtml';
                          $subject = ucfirst(strtolower($assetMetadata['labels'][0])) . ' due for review - TACS';
                          break;
                      case 'pending-consent-review':
                          $template = 'pending-consent-review.email.phtml';
                          $subject = ucfirst(strtolower($assetMetadata['labels'][0])) . ' out of date - TACS';
                          break;
                    }

                    if (!$template) {
                        $this->flashMessenger()
                             ->setNamespace('error')
                             ->addMessage('The requested notification could not be sent.');
                        return $this->redirect()->toRoute('reports');                 
                    }        
                    
                    $config = $this->getServiceLocator()->get('config');
                    $uri = new \Zend\Uri\Uri($this->getRequest()->getUri());
                    $baseUrl = $uri->getScheme() . '://' . $uri->getHost();
                    $view = new ViewModel(array(
                        'asset' => $asset, 
                        'assetTypeSingular' => strtolower($assetMetadata['labels'][0]),
                        'hubUrl' => $baseUrl . $this->url()->fromRoute('home'),
                        'editUrl' => $baseUrl . $this->url()->fromRoute($assetMetadata['route'], array('action' => 'save', 'id' => $asset->getId())),
                        'displayUrl' => $baseUrl . $this->url()->fromRoute($assetMetadata['route'], array('action' => 'display', 'id' => $asset->getId())),
                    ));
                    $view->setTemplate('application/report/' . $template);
                    $viewRenderer = $this->getServiceLocator()->get('ViewRenderer');
                    $html = $viewRenderer->render($view);                
                    $html = new Part($html);
                    $html->type = "text/html";  
                    $body = new MimeMessage();
                    $body->setParts(array($html));                
                    $message = new Message();
                    $message->setBody($body);               
                    $emailAddresses = array($asset->getOwnerEmail());
                    $downloads = $asset->getDownloads();
                    foreach ($downloads as $d) {
                        $emailAddresses[] = $d->getUserEmail();
                    }
                    $fromEmail = $config['application']['from_email'];
                    $fromName = $config['application']['from_name'];
                    $message->setFrom($fromEmail, $fromName);
                    $message->addTo($emailAddresses);
                    $message->setSubject($subject);
                    $message->setEncoding("UTF-8");

                    $transport = new Sendmail(); 
                    $transport->send($message);                                
            
                    $this->flashMessenger()
                         ->setNamespace('success')
                         ->addMessage('The owner and downloaders of the selected ' .  strtolower($assetMetadata['labels'][0]) . ' were successfully notified.');
                    return $this->redirect()->toRoute('reports', array('action' => $format));
                }
            } else {
                $messages = $form->getMessages();
            }    
        }

        $view = new ViewModel(array(
            'form' => $form, 
            'id' => $asset->getId(), 
            'route' => 'reports',
            'action' => 'notify', 
            'format' => $format, 
            'message' => 'The owner and all downloaders of the selected ' . strtolower($assetMetadata['labels'][0]) . ' will be notified via email.',
        ));
        $view->setTemplate('application/common/confirm.phtml');
        return $view;
    }
    
    private function produceCsv($templateName, $outputSuffix, $viewModel)
    {
        $viewModel->setTemplate($templateName);
        $viewRenderer = $this->getServiceLocator()->get('ViewRenderer');
        $csv = $viewRenderer->render($viewModel);                
        $response = new \Zend\Http\Response;
        $response->setStatusCode(200);
        $date = new \DateTime('now');
        $dateStr = $date->format('dmY');
        $headers = new \Zend\Http\Headers();
        $headers->addHeaders(array(
            'Content-Disposition' => 'attachment; filename="' . $outputSuffix . '-' . $dateStr . '.csv"',
            'Content-Type' => 'text/csv',
            'Content-Length' => strlen($csv),
            'Expires' => '@0', // @0, because zf2 parses date as string to \DateTime() object
            'Cache-Control' => 'must-revalidate',
            'Pragma' => 'public'
        ));
        $response->setHeaders($headers);
        $response->setContent($csv);
        return $response;
    }
    
    private function getActionName()
    {
        return $this->params('action');
    }  

}
