<?php
namespace Application\Form;

use Zend\Form\Annotation;

class DateRangeForm
{

    /** 
    *   @Annotation\Required(false)
    *   @Annotation\Type("Zend\Form\Element\Date")
    *   @Annotation\Validator({"name":"Date"})
    *   @Annotation\Options({"label":"From"})     
    */
    protected $from;

    /** 
    *   @Annotation\Required(false)
    *   @Annotation\Type("Zend\Form\Element\Date")
    *   @Annotation\Validator({"name":"Date"})
    *   @Annotation\Options({"label":"To"})     
    */
    protected $to;
    
    /** 
    *   @Annotation\Type("Zend\Form\Element\Csrf")
    */
    protected $csrf;

    /** 
    *   @Annotation\Type("Zend\Form\Element\Submit")
    *   @Annotation\Attributes({"value":"Search"})     
    */
    protected $submit;
    
    
}