<!DOCTYPE html>
<meta http-equiv="X-UA-Compatible" content="IE=edge" />
<html>
<head>
<?php $ID = $_GET["ID"]; ?>

<title>Edit policy <?php echo $ID;?></title>

<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.css">
<link rel="stylesheet" type="text/css" href="styles.css">

<script src="scripts/jquery-1.10.1.min.js" type="text/javascript"></script>
<script src="ckeditor4.5.9/ckeditor.js" type="text/javascript"></script>

<script>
$(document).ready(function(){

CKEDITOR.replace( 'ckeditor',
    {
        toolbar : 'Basic',
        uiColor : '#9AB8F3'
    });

});
</script>
</head>
<body class="formPage editPolicy">

<?php
if (!$_POST['submit'])
{

// includes
include('conf.php');

// open database connection
$connection = mysql_connect($host, $user, $pass) or die ('Unable to connect!');

// select database
mysql_select_db($db) or die ('Unable to select database!');




        // generate and execute query
        $query = "SELECT * FROM CANCER_policies WHERE ID ='".$ID."'";


        $result = mysql_query($query) or die ("Error in query: $query. " . mysql_error());
// if records present
if (mysql_num_rows($result) > 0)
{

      while($row = mysql_fetch_object($result))
      {
?>
<h1>Edit policy</h1>
<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST">
<input name="ID" type="hidden" value="<?php echo $row->ID ; ?>" >
<label>name</label><input name="name" type="text" value="<?php echo $row->name; ?>"/>
<?php
// generate and execute query
$Dquery = "SELECT ID, name FROM CANCER_companies ORDER BY ID DESC";

$Dresult = mysql_query($Dquery) or die ("Error in query: $Dquery. " . mysql_error());

// if records present
if (mysql_num_rows($Dresult) > 0)
{?>
<label>Company</label>
<select name="companyID">
<?php
      // iterate through resultset
      // print title with links to edit and delete scripts
      while($Drow = mysql_fetch_object($Dresult))
      {
      ?>
      <option value="<?php echo $Drow->ID; ?>" <?php if ($Drow->ID==$row->companyID){ ?>selected="selected"<?php } ?>><?php echo $Drow->name; ?></option> 
      <?php
      }
      ?>
</select>
<?php
}
?>
<h4>Cash benefits</h4>
<label>Cash payment on first diagnosis of cancer</label><textarea class="ckeditor" name="Benefit1" rows="2" cols="8"><?php echo $row->Benefit1; ?></textarea>
<label>Cash payment on first diagnosis of non-melanoma skin cancer</label><textarea class="ckeditor" name="Benefit2" rows="2" cols="8"><?php echo $row->Benefit2; ?></textarea>
<h4>Treatments</h4>
<label>Cash payment on first diagnosis of non-melanoma skin cancer</label><textarea class="ckeditor" name="Benefit3" rows="2" cols="8"><?php echo $row->Benefit3; ?></textarea>
<h4>Support</h4>
<label>Expert help</label><textarea class="ckeditor" name="Benefit4" rows="2" cols="8"><?php echo $row->Benefit4; ?></textarea>

<input type="submit" value="Update" name="submit">
</form>
<?php

	}
}
// close connection
mysql_close($connection);
?>



<?php
}
else
{
    // includes
    include('conf.php');

    // set up error list array
    $errorList = array();
    
    
$ID = $_POST['ID'];
$name = $_POST['name'];
$companyID = $_POST['companyID'];
$Benefit1 = $_POST['Benefit1'];
$Benefit2 = $_POST['Benefit2'];
$Benefit3 = $_POST['Benefit3'];
$Benefit4 = $_POST['Benefit4'];
    
    	

    // check for errors
    // if none found...
    if (sizeof($errorList) == 0)
    {
        // open database connection
        $connection = mysql_connect($host, $user, $pass) or die ('Unable to connect!');

        // select database
        mysql_select_db($db) or die ('Unable to select database!');

        // generate and execute query
        $query = "UPDATE CANCER_policies SET 
					name ='$name', 
					companyID ='$companyID', 
					Benefit1 ='$Benefit1', 
					Benefit2 ='$Benefit2', 
					Benefit3 ='$Benefit3', 
					Benefit4 ='$Benefit4', 
					dateModified ='".date('Y-m-d H:i:s', time())."' 								
					 WHERE ID ='".$ID."'";
        

        $result = mysql_query($query) or die ("Error in query: $query. " . mysql_error());

/**********ACTIVITY LOG FUNCTIONALITY**********/
/*
        $currentFile = $_SERVER["PHP_SELF"];
		$ipAddress = $_SERVER["REMOTE_ADDR"];
		$date = date("Y/m/d");
		$escapedQuery = mysql_escape_string($query);
        // generate and execute query
        $activityQuery = "INSERT INTO activityLog(user, page, notes, query, errors, dateExecuted, ipAddress) VALUES('$userID', '$currentFile', 'Attempt to edit topic".$ID.".', '$escapedQuery', '$SQLerror', '$date', '$ipAddress')";

        $activityResult = mysql_query($activityQuery) or die ("Error in query: $query. " . mysql_error());
*/
/**********************************************/

        // print result
        echo '<h2>Update successful.</h2>';
?>
<script src="scripts/jquery-1.10.1.min.js" type="text/javascript"></script>
 
<script>
$(document ).ready(function() {
parent.location.reload();
});
</script>
<?php
        // close database connection
        mysql_close($connection);
    }
    else
    {
    
    
        // errors found
        // print as list
        echo '<font size=-1>The following errors were encountered:'; 
        echo '<br>';
        echo '<ul>';
        for ($x=0; $x<sizeof($errorList); $x++)
        {
            echo "<li>$errorList[$x]";
        }
        echo '</ul></font><br /><a href=&amp;javascript: history.go(-1)&amp;>Back</a>';
    }
}
?>
</body>
</html>