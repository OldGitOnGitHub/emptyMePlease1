<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="en" xml:lang="en">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<meta name="description" content="Bid submission for the charity auction for 2010. " />
<title>Charity auction 2010</title>
<?php
$document_owner="graham.thomas@axa-ppp.co.uk";
$devolved_publisher="matthew.newman@joining-dots.com";
include "global/includes/page-scripts-styles.html";
?>
<!--
<script type="text/javascript" src="../../../mantools/sales/isc/forms/one-int-validation.js"></script>
-->

<script type="text/javascript">
navLocation="Time out:Auction:";

<!-- basic validation scripts -->
<script type="text/javascript" src="js/jquery.js"></script>
<script type="text/javascript" src="js/jquery.validate.js"></script>
<script type="text/javascript">
$(document).ready(function() {
$('#signup').validate();
}); // end validate
</script>
<!-- end of basic validation scripts -->

<style type="text/css">
.hlogo {
	padding:20px;
}
</style>

</head>
<body class="col3">

<div id="wrapper">
<!--
<?php
include($_SERVER['DOCUMENT_ROOT']."/intranet/global/includes/page-header.php");
include($_SERVER['DOCUMENT_ROOT']."/intranet/timeout/sports-and-social/local-nav.html");
?>
-->

<div id="header">

<img src="global/imgs/logo.gif" alt="healthnet" class="hlogo"/>

</div>

<?php
// includes
include('includes/conf.php');
include('includes/functions.php');

// open database connection
$connection = mysql_connect($host, $user, $pass) or die ('Unable to connect!');

// select database
mysql_select_db($db) or die ('Unable to select database!');
$bidlot = stripslashes($_POST["bidlot"]);

// get lot record
$query = "SELECT * FROM lots WHERE LotNumber = '" . $bidlot . "'";
$result = mysql_query($query) or die ("Error in query: $query. " . mysql_error());
$row = mysql_fetch_object($result);
?>

<div class="presentational1"></div>

<div id="content">
<h1>Place your bid for Lot <?php echo $row->DisplayedLotNumber; ?>: <?php echo ($row->LotTitle); ?> </h1>
<form name="signup" id="signup"  method="post" action="https://www.joining-dots.com/intranet/timeout/sports-and-social/auction/2011/confirmed.php" onsubmit="return checkAll(this);" style="margin-top:1.5em;">

<input name="bidlot" id="bidlot" type="hidden" value="<?php echo $bidlot?>" />
<table>
<tr>
  <td><label for="name">Your name</label></td>

  
  <td><input name="name" id="name" type="text" class="required" title="<h5>We'll need your First Name and Surname.  Once you've entered that, we'll be pleased to accept your bid.</h5>"></td></tr>
<tr>
  <td><label for="email">Your company email address</label></td>
  <td><input name="email" id="email" type="text" class="required email" title="<h5>We'll need your e-mail address.  Once you've entered that, we'll be pleased to accept your bid.</h5>"></td></tr>
<tr>
  <td><label for="phone">Your phone no.</label></td>
  <td><input name="phone" id="phone" type="text"  class="required" title="<h5>We'll need your phone number.  Once you've entered that, we'll be pleased to accept your bid.</h5>"></td></tr>
<tr>
  <td><label for="bid">Your bid &pound;</label></td>
  <td><input name="bid" id="bid" type="text" class="required" title="<h5>We'll need your bid.  Once you've entered that, we'll be pleased to accept it.</h5>"></td></tr>
<tr><td colspan='2'><input type="submit" name="submit" id="formsubmit" value="Confirm bid" /></td></tr>
</table>
<p><a href="index.php">Cancel</a></p>
</form>
</div>
<div class="presentational2"></div>
<div id="related-links">
<h2><b>Related</b> links</h2>
<ul>
<li><a href="http://www.headwaytwells.org/">Headway</a></li>
</ul>
</div>

</div>
</body>
</html>