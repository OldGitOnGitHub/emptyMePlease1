


<?php
            // includes
            include('includes/conf.php');
            include('includes/functions.php');            
            // open database connection
            $connection = mysql_connect($host, $user, $pass) or die ('Unable to connect!');            
            // select database
            mysql_select_db($db) or die ('Unable to select database!');            


            
				// generate and execute the database query				
				$query = "SELECT lots.LotNumber, LotCurrentDisplayBid, BidderName FROM lots LEFT JOIN bids ON lots.LotCurrentActiveBid = bids.BidNumber ORDER BY lots.DisplayedLotNumber";
				$result = mysql_query($query) or die ("Error in query: $query. " . mysql_error());
				// if records present
				if (mysql_num_rows($result) > 0)
				{
                ?>
<script>//
//$(document).ready(function() {
//alert('document ready');
<?php

					  // iterate through resultset
					  while($row = mysql_fetch_object($result))
					  {
?>
            $("#<?php echo $row->LotNumber; ?>price").empty();
			            $("#<?php echo $row->LotNumber; ?>price").append("<div>&pound;<?php echo((int)$row->LotCurrentDisplayBid); ?> <?php echo !empty($row->BidderName) ? '- ' . $row->BidderName : ''; ?></div>");


							<?php 
          				}
                  ?>
                  alert('number append code run 5');
//});
</script>
                  
                <?php
            	}
            // if no records present
            // display message
            else
            {
            ?>
                  <font size="-1">No items currently available</font><p>
            <?php
            }
            
            // close connection
            mysql_close($connection);
            ?>

