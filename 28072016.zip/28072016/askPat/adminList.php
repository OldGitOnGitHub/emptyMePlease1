<html>
<head>

<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.css">
<link rel="stylesheet" type="text/css" href="styles.css">

<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js" type="text/javascript"></script>

</head>
<body class="admin">
<div class="wrapper">
<?php

// includes
include('conf.php');

// open database connection
$connection = mysql_connect($host, $user, $pass) or die ('Unable to connect!');

// select database
mysql_select_db($db) or die ('Unable to select database!');


// generate and execute query
$query = "SELECT ID, title, userID, departmentID, categoryID, content, dateAdded, votes, status FROM topics WHERE visible='1'AND ID <>'".$topTrendingID."' ORDER BY ID DESC";

$result = mysql_query($query) or die ("Error in query: $query. " . mysql_error());

// if records present
if (mysql_num_rows($result) > 0)
{
?>

<table>
<tr>
	<th>ID</th>
	<th>Title</th>
	<th>Date Added</th>
	<th>Status</th>
	<th>Edit/Delete</th>
</tr>
<?php
      // iterate through resultset
      // print title with links to edit and delete scripts
      while($row = mysql_fetch_object($result))
      {
            
      $DEPARTMENTquery = "SELECT name FROM departments WHERE ID='".$row->departmentID."'";
      $DEPARTMENTresult = mysql_query($DEPARTMENTquery) or die ("Error in query: $DEPARTMENTquery. " . mysql_error());
      $DEPARTMENTrow = mysql_fetch_object($DEPARTMENTresult);
      
      $ID = $row->ID;
      
      ?>
<tr>
      <td><?php echo "#".$row->ID;?></td>
      <td><?php echo $row->title; ?></td>
      <td><?php echo $row->dateAdded; ?></td>
      <td><img src="imgs/<?php echo $row->status; ?>.gif" /></td>
      <td><img src="imgs/edit.png" /><img src="imgs/delete.png" /></td>
</tr>
      <?php
      }
?>
</table>
<?php
}
// if no records present
// display message
else
{
?>
      <h1>No topics currently available</h1>
<?php
}
?>
</div>
</body>
</html>