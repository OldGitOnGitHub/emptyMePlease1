<?php
                // database configuration
               // $host = 'localhost';
                //$user = 'joining1_auser';
                //$pass = '@uct10n!';
                //$db = 'joining1_auction_2011';
                
              //  $host = 'localhost';
               // $user = 'root';
                //$pass = '';
                //$db = 'auction_2011';
                
                
//	$host = 'healthnet-mysql.axa-uk.intraxa';
//	$user = 'HealthnetUser';
//	$pass = 'PPPphp55';
//	$db = 'auction_2011';
	// default contact person
	$def_contact = 'Graham Thomas (graham.thomas@axa-ppp.co.uk)';


// detect where the system is running from - to decide what db connection to use ...
$url = 'http://' . $_SERVER['SERVER_NAME'] . $_SERVER['REQUEST_URI'];     
if (false !== strpos($url,'joining-dots')) {
$host = 'localhost';
$user = 'joining1_auser';
$pass = '@uct10n!';
$db = 'joining1_auction_2011';

} elseif (false !== strpos($url,'localhost')) {
$host = 'localhost';
$user = 'root';
$pass = '';
$db = 'auction_2011';

} elseif (false !== strpos($url,'52.48.57.242')) {
$host = '127.0.0.1';
$user = 'username';
$pass = 'password';
$db = 'auction_2011';

} elseif (false !== strpos($url,'192.168.56.101')) {
$host = '127.0.0.1';
$user = 'root';
$pass = '';
$db = 'auction';

} else {
if (false !== strpos($url,'staging')) {

	$host = 'localhost';
	$user = 'HealthnetUser';
	$pass = 'PPPphp55';
	$db = 'auction_2011';
} else {
		
	$host = 'healthnet-mysql.axa-uk.intraxa';
	$db = 'auction_2011';
	$user = 'HealthnetUser';
	$pass = 'PPPphp55';

}
}
// echo $host." - ".$user." - ".$pass;

// old connection details to delete once successful connections acheive on all 4 environments
//$url = 'http://' . $_SERVER['SERVER_NAME'] . $_SERVER['REQUEST_URI'];     
//if (false !== strpos($url,'joining-dots')) {
//
//	
//	$host = 'localhost';
//	$user = 'joining1_auser';
//	$pass = '@uct10n!';
//	$db = 'joining1_auction_2011';
//
//} else {
//	if (false !== strpos($url,'staging')) {
//	
//		$host = 'localhost';
//		$user = 'HealthnetUser';
//		$pass = 'PPPphp55';
//		$db = 'auction_2011';
//		
//	} else {
//			
//		$host = 'healthnet-mysql.axa-uk.intraxa';
//		$user = 'HealthnetUser';
//		$pass = 'PPPphp55';
//		$db = 'auction_2011';
//	
//	}
//}      
                
                //auction end time
                
                $endTime = '2016-05-27 11:00:00'; 
?>