<!DOCTYPE html>
<meta http-equiv="X-UA-Compatible" content="IE=edge" />
<html>
<head>
<title>Admin homepage</title>
<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.css">
<link rel="stylesheet" type="text/css" href="styles.css">
 
</head>
<body class="admin">
<style>
html, body, iframe {
	height: 100%;
	width:100%;
	}
.admin .left, .admin .right {
	height: 100%;
	}
.admin .left {
	float: left;
	width: 20%;
	min-width: 300px;
	margin: 0 10px;
	overflow: scroll;
	}
.admin .right {
//	float: right;
//	width: 80%;
	overflow: scroll;
	}
ul { 
	list-style-type: none;
	margin: 0 0 10px 0 ;
	}
</style>
<div class="left">
<h1>Admin Homepage</h1>
<!--
<b>Here is how to put stuff into the database</b>
<ul>
<li><a href="listTopics.php">Topics</a><a href="addTopic.php">(add)</a></li>
<li><a href="listComments.php">Comments</a></li>
<li><a href="listCategories.php">Categories</a><a href="addCategory.php">(add)</a></li>
<li><a href="listDepartments.php">Departments</a><a href="addDepartment.php">(add)</a></li>
<li><a href="listPolicies.php">Policies</a><a href="addPolicy.php">(add)</a></li>
<li><a href="listCompanies.php">Companies</a><a href="addCompany.php">(add)</a></li>
</ul>
-->
<table>
  	<tbody>
  		<tr>
    			<td><button type="button" class="btn btn-primary" disabled="disabled">Topics</button></td>
    			<td><a class="btn btn-default" href="addTopic.php" role="button" target="mainPane">Add</a></td>   			
    			<td><a class="btn btn-default" href="listTopics.php" role="button" target="mainPane">Edit</a></td>    	   					
 		</tr>
  		<tr>
    			<td><button type="button" class="btn btn-primary" disabled="disabled">Comments</button></td>		
    			<td><button type="button" class="btn btn-default btn-lg" disabled="disabled"> ----- </button> </td>
    			<td><a class="btn btn-default" href="listComments.php" role="button" target="mainPane">Edit</a></td>		
  		</tr>
  		<tr>
    			<td><button type="button" class="btn btn-primary" disabled="disabled">Categories</button></td>		
    			<td><a class="btn btn-default" href="addCategory.php" role="button" target="mainPane">Add</a></td>
    			<td><a class="btn btn-default" href="listCategories.php" role="button" target="mainPane">Edit</a></td>    			
  		</tr>
  		<tr>
    			<td><button type="button" class="btn btn-primary" disabled="disabled">Departments</button></td>
    			<td><a class="btn btn-default" href="addDepartment.php" role="button" target="mainPane">Add</a></td>     			
    			<td><a class="btn btn-default" href="listDepartments.php" role="button" target="mainPane">Edit</a></td>    	   					
 		</tr>
  		<tr>
    			<td><button type="button" class="btn btn-primary" disabled="disabled">Policies</button></td>		
    			<td><a class="btn btn-default" href="addPolicy.php" role="button" target="mainPane">Add</a></td>
    			<td><a class="btn btn-default" href="listPolicies.php" role="button" target="mainPane">Edit</a></td>		
  		</tr>
  		<tr>
    			<td><button type="button" class="btn btn-primary" disabled="disabled">Companies</button></td>		
    			<td><a class="btn btn-default" href="addCompany.php" role="button" target="mainPane">Add</a></td>
    			<td><a class="btn btn-default" href="listCompanies.php" role="button" target="mainPane">Edit</a></td>    			
  		</tr>

	</tbody>
</table>

<p>&nbsp;</p>
<p><b>Here is how to get stuff out</b></p>

<a href="/intranet/mantools/isc-cpat/adminReport.php" class="btn btn-default">Download  activity log for all users into Excel</a><br /><br />
<a href="/intranet/mantools/isc-cpat/adminReportCompanies.php" class="btn btn-default">Download the Companies table into Excel</a><br /><br />
<a href="/intranet/mantools/isc-cpat/adminReportPolicies.php" class="btn btn-default">Download the Policies table into Excel</a><br /><br />

</div>
<div class="right">
	<iframe name="mainPane">
	</iframe>
</div>
</body>
</html>