<?php
namespace Application\Entity;

use Doctrine\ORM\Mapping as ORM;
use Doctrine\Common\Collections\Collection as Collection;
use Zend\Form\Annotation;

/** @ORM\Entity(repositoryClass="Application\Repository\Asset")
*   @ORM\Table(name="asset")
*   @Annotation\Name("asset")
*/
class Asset
{

    const TYPE_TESTIMONIAL = 1;
    const TYPE_CASESTUDY = 2;
    const TYPE_VIDEO = 3;

    const STATUS_ACTIVE = 1;
    const STATUS_INACTIVE = 0;  // equivalent to 'STATUS_ARCHIVED'
    
    /**
    *   @ORM\Id
    *   @ORM\GeneratedValue(strategy="AUTO")
    *   @ORM\Column(type="integer")
    *   @Annotation\Exclude()
    */
    protected $id;

    /** @ORM\Column(type="date", nullable=false) 
    *   @Annotation\Required(true)
    *   @Annotation\Type("Zend\Form\Element\Date")
    *   @Annotation\Validator({"name":"Date"})
    *   @Annotation\Options({"label":"Date created"})     
    */
    protected $created;

    /** @ORM\Column(type="string", nullable=false) 
    *   @Annotation\Required(true)
    *   @Annotation\Filter({"name":"StringTrim"})
    *   @Annotation\Filter({"name":"StripTags"})
    *   @Annotation\Validator({"name":"StringLength", "options":{"min":1, "max":255}})
    *   @Annotation\Type("Zend\Form\Element\Text")
    *   @Annotation\Options({"label":"Title"})     
    */
    protected $title;
    
    /** @ORM\Column(type="text", nullable=true) 
    *   @Annotation\Required(false)
    *   @Annotation\Filter({"name":"StringTrim"})
    *   @Annotation\Filter({"name":"StripTags"})
    *   @Annotation\Validator({"name":"StringLength", "options":{"min":1, "max":255}})
    *   @Annotation\Type("Zend\Form\Element\Textarea")
    *   @Annotation\Options({"label":"Description"})     
    */
    protected $description;

    /** @ORM\Column(type="string", nullable=false) 
    *   @Annotation\Required(true)
    *   @Annotation\Filter({"name":"StringTrim"})
    *   @Annotation\Filter({"name":"StripTags"})
    *   @Annotation\Validator({"name":"StringLength", "options":{"min":1, "max":255}})
    *   @Annotation\Type("Zend\Form\Element\Text")
    *   @Annotation\Options({"label":"Owner's name"})         
    */
    protected $ownerName;
    
    /** @ORM\Column(type="string", nullable=false) 
    *   @Annotation\Required(true)
    *   @Annotation\Filter({"name":"StringTrim"})
    *   @Annotation\Filter({"name":"StripTags"})
    *   @Annotation\Validator({"name":"EmailAddress"})
    *   @Annotation\Type("Zend\Form\Element\Text")
    *   @Annotation\Options({"label":"Owner's email address"})         
    */
    protected $ownerEmail;

    /** @ORM\Column(type="string", nullable=true) 
    *   @Annotation\Required(false)
    *   @Annotation\Filter({"name":"StringTrim"})
    *   @Annotation\Filter({"name":"StripTags"})
    *   @Annotation\Validator({"name":"StringLength", "options":{"min":1, "max":255}})
    *   @Annotation\Type("Zend\Form\Element\Text")
    *   @Annotation\Options({"label":"Owner's department"})         
    */
    protected $ownerDepartment;

    /** @ORM\Column(type="string", nullable=false) 
    *   @Annotation\Required(true)
    *   @Annotation\Filter({"name":"StringTrim"})
    *   @Annotation\Filter({"name":"StripTags"})
    *   @Annotation\Validator({"name":"StringLength", "options":{"min":1, "max":255}})
    *   @Annotation\Type("Zend\Form\Element\Text")
    *   @Annotation\Options({"label":"Member name"})         
    */
    protected $memberName;

    /** @ORM\Column(type="string", nullable=false) 
    *   @Annotation\Required(true)
    *   @Annotation\Filter({"name":"StringTrim"})
    *   @Annotation\Filter({"name":"StripTags"})
    *   @Annotation\Validator({"name":"Regex", "options":{"pattern":"/^[a-zA-Z0-9]+$/", "messages": {"regexNotMatch":"The input contains characters which are non-alphabetic and non-numeric"}} })
    *   @Annotation\Type("Zend\Form\Element\Text")
    *   @Annotation\Options({"label":"Member number"})         
    */
    protected $memberNumber;

    /** @ORM\Column(type="string", nullable=true) 
    *   @Annotation\Required(false)
    *   @Annotation\Filter({"name":"StringTrim"})
    *   @Annotation\Filter({"name":"StripTags"})
    *   @Annotation\Validator({"name":"StringLength", "options":{"min":1, "max":255}})
    *   @Annotation\Type("Zend\Form\Element\Text")
    *   @Annotation\Options({"label":"Member location"})         
    */
    protected $memberLocation;

    /** @ORM\Column(type="boolean", nullable=false) 
    *   @Annotation\Required(true)
    *   @Annotation\Filter({"name":"StringTrim"})
    *   @Annotation\Filter({"name":"StripTags"})
    *   @Annotation\Validator({"name":"Digits"})
    *   @Annotation\Type("Zend\Form\Element\Radio")
    *   @Annotation\Options({"label":"Member status", "value_options":{ {"value":"1", "label":"Current","selected":true}, {"value":"0", "label":"Lapsed", "selected":false} }})           
    */
    protected $memberStatus;

    
    /** @ORM\Column(type="boolean", nullable=false) 
    *   @Annotation\Required(true)
    *   @Annotation\Filter({"name":"StringTrim"})
    *   @Annotation\Filter({"name":"StripTags"})
    *   @Annotation\Validator({"name":"Digits"})
    *   @Annotation\Type("Zend\Form\Element\Radio")
    *   @Annotation\Options({"label":"Member to remain anonymous", "value_options":{ {"value":"1", "label":"Yes","selected":true}, {"value":"0", "label":"No", "selected":false} }})         
    */
    protected $memberAnonymityStatus;
    
    /** @ORM\Column(type="string", nullable=true) 
    *   @Annotation\Required(false)
    *   @Annotation\Filter({"name":"StringTrim"})
    *   @Annotation\Filter({"name":"StripTags"})
    *   @Annotation\Validator({"name":"StringLength", "options":{"min":1, "max":255}})
    *   @Annotation\Type("Zend\Form\Element\Text")
    *   @Annotation\Options({"label":"Plan name"})         
    */
    protected $planName;

    /** @ORM\Column(type="string", nullable=true) 
    *   @Annotation\Required(true)
    *   @Annotation\Filter({"name":"StringTrim"})
    *   @Annotation\Filter({"name":"StripTags"})
    *   @Annotation\Validator({"name":"Digits"})
    *   @Annotation\Type("Zend\Form\Element\Select")
    *   @Annotation\Options({"label":"Plan type"})         
    */
    protected $planType;

    /** @ORM\Column(type="text", nullable=true) 
    *   @Annotation\Required(false)
    *   @Annotation\Filter({"name":"StringTrim"})
    *   @Annotation\Filter({"name":"StripTags"})
    *   @Annotation\Type("Zend\Form\Element\Textarea")
    *   @Annotation\Options({"label":"Comments"})         
    */
    protected $comments;

    /** @ORM\Column(type="string", nullable=true) 
    *   @Annotation\Required(false)
    *   @Annotation\Filter({"name":"StringTrim"})
    *   @Annotation\Filter({"name":"StripTags"})
    *   @Annotation\Validator({"name":"Digits"})
    *   @Annotation\Type("Zend\Form\Element\Text")
    *   @Annotation\Options({"label":"Cost"})         
    */
    protected $cost;

    /** @ORM\Column(type="boolean", nullable=false) 
    *   @Annotation\Required(true)
    *   @Annotation\Filter({"name":"StringTrim"})
    *   @Annotation\Filter({"name":"StripTags"})
    *   @Annotation\Validator({"name":"Digits"})
    *   @Annotation\Type("Zend\Form\Element\Radio")
    *   @Annotation\Options({"label":"Consent acquired", "value_options":{ {"value":"1", "label":"Yes","selected":true}, {"value":"0", "label":"No", "selected":false} }})          
    */
    protected $consentStatus;
    
    /** @ORM\Column(type="boolean", nullable=false) 
    *   @Annotation\Required(true)
    *   @Annotation\Filter({"name":"StringTrim"})
    *   @Annotation\Filter({"name":"StripTags"})
    *   @Annotation\Validator({"name":"Digits"})
    *   @Annotation\Type("Zend\Form\Element\Radio")
    *   @Annotation\Options({"label":"Consent requires update", "value_options":{ {"value":"1", "label":"Yes","selected":true}, {"value":"0", "label":"No", "selected":false} }})         
    */
    protected $consentUpdateStatus;

    /** @ORM\Column(type="text", nullable=true) 
    *   @Annotation\Required(false)
    *   @Annotation\Validator({"name":"FileExtension", "options":{"extension":"pdf"} })
    *   @Annotation\Filter({"name":"FileRenameUpload", "options":{"target":"data/tmp"} })
    *   @Annotation\Type("Zend\Form\Element\File")
    *   @Annotation\Options({"label":"Consent file"})         
    */
    protected $consentFile;
    
    /** @ORM\Column(type="text", nullable=true) 
    *   @Annotation\Required(false)
    *   @Annotation\Validator({"name":"FileExtension", "options":{"extension":"pdf"} })
    *   @Annotation\Filter({"name":"FileRenameUpload", "options":{"target":"data/tmp"} })
    *   @Annotation\Type("Zend\Form\Element\File")
    *   @Annotation\Options({"label":"File"})         
    */
    protected $assetFile;

    /** @ORM\Column(type="text", nullable=true) 
    *   @Annotation\Required(false)
    *   @Annotation\Filter({"name":"StringTrim"})
    *   @Annotation\Filter({"name":"StripTags"})
    *   @Annotation\Validator({"name":"StringLength", "options":{"min":1}})
    *   @Annotation\Type("Zend\Form\Element\Textarea")
    *   @Annotation\Options({"label":"Data"})         
    */
    protected $assetData;

    /** @ORM\Column(type="string", nullable=true) 
    *   @Annotation\Required(false)
    *   @Annotation\Filter({"name":"StringTrim"})
    *   @Annotation\Filter({"name":"StripTags"})
    *   @Annotation\Validator({"name":"StringLength", "options":{"min":1, "max":10}})
    *   @Annotation\Type("Zend\Form\Element\Text")
    *   @Annotation\Options({"label":"Length"})         
    */
    protected $assetDataSize;
    
    /** @ORM\Column(type="integer", nullable=false) 
    *   @Annotation\Exclude()
    */
    protected $status;

    /** @ORM\Column(type="integer", nullable=false) 
    *   @Annotation\Exclude()
    */
    protected $type;

    /** @ORM\Column(type="date", nullable=false) 
    *   @Annotation\Exclude()
    */
    protected $memberStatusUpdated;
    
    /**
    *   @ORM\ManyToMany(targetEntity="Category")
    *   @ORM\JoinTable(name="asset_category")
    *   @Annotation\Required(true)
    *   @Annotation\Type("DoctrineModule\Form\Element\ObjectSelect")
    *   @Annotation\Attributes({"multiple":"multiple"})     
    *   @Annotation\Options({"label":"Categories", "target_class":"Application\Entity\Category"})
    */
    protected $categories;

    protected $activities;

    /** 
    *   @Annotation\Required(true)
    *   @Annotation\Type("Zend\Form\Element\Csrf")
    */
    protected $csrf;
        
    /** 
    *   @Annotation\Attributes({"value":"Submit"})
    *   @Annotation\Type("Zend\Form\Element\Submit")
    */
    protected $submit;

    public function __construct() {
        $this->categories = new \Doctrine\Common\Collections\ArrayCollection();
        $this->activities = new \Doctrine\Common\Collections\ArrayCollection();
        $this->downloads = new \Doctrine\Common\Collections\ArrayCollection();
        $this->audits = new \Doctrine\Common\Collections\ArrayCollection();
    }
        
    public function getId()
    {
        return $this->id;
    }

    public function setId($value)
    {
        $this->id = $value;
    }    

    public function getCreated()
    {
        return $this->created;
    }

    public function setCreated($value)
    {
        $this->created = $value;
    }    

    public function getDescription()
    {
        return $this->description;
    }

    public function setDescription($value)
    {
        $this->description = $value;
    }    
    
    public function getTitle()
    {
        return $this->title;
    }

    public function setTitle($value)
    {
        $this->title = $value;
    }    

    public function getOwnerName()
    {
        return $this->ownerName;
    }

    public function setOwnerName($value)
    {
        $this->ownerName = $value;
    }    
    
    public function getOwnerEmail()
    {
        return $this->ownerEmail;
    }

    public function setOwnerEmail($value)
    {
        $this->ownerEmail = $value;
    }    

    public function getOwnerDepartment()
    {
        return $this->ownerDepartment;
    }

    public function setOwnerDepartment($value)
    {
        $this->ownerDepartment = $value;
    }    

    public function getMemberName()
    {
        return $this->memberName;
    }

    public function setMemberName($value)
    {
        $this->memberName = $value;
    }    

    public function getMemberNumber()
    {
        return $this->memberNumber;
    }

    public function setMemberNumber($value)
    {
        $this->memberNumber = $value;
    }     

    public function getMemberLocation()
    {
        return $this->memberLocation;
    }

    public function setMemberLocation($value)
    {
        $this->memberLocation = $value;
    }     

    public function getMemberStatus()
    {
        return $this->memberStatus;
    }

    public function setMemberStatus($value)
    {
        $this->memberStatus = $value;
    }     

    public function getMemberStatusUpdated()
    {
        return $this->memberStatusUpdated;
    }

    public function setMemberStatusUpdated($value)
    {
        $this->memberStatusUpdated = $value;
    }     
    
    public function getMemberAnonymityStatus()
    {
        return $this->memberAnonymityStatus;
    }

    public function setMemberAnonymityStatus($value)
    {
        $this->memberAnonymityStatus = $value;
    }     
    
    public function getPlanName()
    {
        return $this->planName;
    }

    public function setPlanName($value)
    {
        $this->planName = $value;
    }     

    public function getPlanType()
    {
        return $this->planType;
    }

    public function setPlanType($value)
    {
        $this->planType = $value;
    }     

    public function getComments()
    {
        return $this->comments;
    }

    public function setComments($value)
    {
        $this->comments = $value;
    }  

    public function getCost()
    {
        return $this->cost;
    }

    public function setCost($value)
    {
        $this->cost = $value;
    }  

    public function getConsentStatus()
    {
        return $this->consentStatus;
    }

    public function setConsentStatus($value)
    {
        $this->consentStatus = $value;
    }    

    public function getConsentUpdateStatus()
    {
        return $this->consentUpdateStatus;
    }

    public function setConsentUpdateStatus($value)
    {
        $this->consentUpdateStatus = $value;
    }    

    public function getConsentFile()
    {
        return $this->consentFile;
    }

    public function setConsentFile($value)
    {
        $this->consentFile = $value;
    }    

    public function getAssetFile()
    {
        return $this->assetFile;
    }

    public function setAssetFile($value)
    {
        $this->assetFile = $value;
    }    
    
    public function getAssetData()
    {
        return $this->assetData;
    }

    public function setAssetData($value)
    {
        $this->assetData = $value;
    }    

    public function getAssetDataSize()
    {
        return $this->assetDataSize;
    }

    public function setAssetDataSize($value)
    {
        $this->assetDataSize = $value;
    }    
    
    public function getStatus()
    {
        return $this->status;
    }

    public function setStatus($value)
    {
        $this->status = $value;
    }    
    
    public function getType()
    {
        return $this->type;
    }

    public function setType($value)
    {
        $this->type = $value;
    }    

    public function getCategories()
    {
        return $this->categories;
    }

    public function setCategories($value)
    {
        $this->categories = $value;
    }  
    
    public function addCategories(Collection $categories)
    {
        foreach ($categories as $category) {
            $this->categories->add($category);
        }
    }

    public function removeCategories(Collection $categories)
    {
        foreach ($categories as $category) {
            $this->categories->removeElement($category);
        }
    } 

    public function getActivities()
    {
        return $this->activities;
    }

    public function setActivities($value)
    {
        $this->activities = $value;
    }  

    public function getDownloads()
    {
        return $this->activities[Activity::TYPE_DOWNLOAD];
    }

    public function setDownloads($value)
    {
        return $this->activities[Activity::TYPE_DOWNLOAD] = $value;
    }
    
    public function getAudits()
    {
        return $this->activities[Activity::TYPE_AUDIT];
    }

    public function setAudits($value)
    {
        return $this->activities[Activity::TYPE_AUDIT] = $value;
    }
    
    /**
    *   Use for direct link between Asset and Activity
    *   Avoided because it created FK link between tables
    *    
    *   ORM\OneToMany(targetEntity="Activity", mappedBy="assetId")
    *   Annotation\Exclude()
    protected $activities;
        

    public function addActivities(Collection $activities)
    {
        foreach ($activities as $activity) {
            $this->activities->add($activity);
        }
    }

    public function removeActivities(Collection $activities)
    {
        foreach ($activities as $activity) {
            $this->activities->removeElement($activity);
        }
    } 
    */
    
}