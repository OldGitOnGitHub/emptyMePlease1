<!DOCTYPE html>
<meta http-equiv="X-UA-Compatible" content="IE=edge" />
<html>
<head>
<title>Cancer Cashback Admin homepage</title>
<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.css">
<link rel="stylesheet" type="text/css" href="styles.css">
 
</head>
<body>
<h1>Cancer Cashback Admin Homepage</h1>


<table>
	<tbody>
  		<tr>
    			<td><button type="button" class="btn btn-primary" disabled="disabled">Policies</button></td>
    			<td><a class="btn btn-default" role="button" href="CCaddPolicy.php">Add</a></td>   			
    			<td><a class="btn btn-default" role="button" href="CClistPolicies.php">Edit</a></td>    	   					
 		</tr>
  		<tr>
    			<td><button type="button" class="btn btn-primary" disabled="disabled">Companies</button></td>
    			<td><a class="btn btn-default" role="button" href="CCaddCompany.php">Add</a></td>   			
    			<td><a class="btn btn-default" role="button" href="CClistCompanies.php">Edit</a></td>    	   					
 		</tr>
	</tbody>
</table>
</body>
</html>