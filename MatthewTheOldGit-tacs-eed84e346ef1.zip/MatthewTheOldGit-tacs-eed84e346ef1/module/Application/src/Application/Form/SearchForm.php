<?php
namespace Application\Form;

use Application\Entity\Asset as Asset;
use Zend\Form\Annotation;

class SearchForm
{

    /** 
    * @Annotation\Type("Zend\Form\Element\Text")
    * @Annotation\Required(false)
    * @Annotation\Filter({"name":"StringTrim"})
    * @Annotation\Filter({"name":"StripTags"})
    * @Annotation\Validator({"name":"StringLength", "options":{"min":1}})
    * @Annotation\Options({"label":"Keywords"})         
    */
    protected $keywords;

    /**  
    *   @Annotation\Required(false)
    *   @Annotation\Filter({"name":"StringTrim"})
    *   @Annotation\Filter({"name":"StripTags"})
    *   @Annotation\Validator({"name":"Digits"})
    *   @Annotation\Type("Zend\Form\Element\Select")
    *   @Annotation\Options({"label":"Category", "empty_option":""})         
    */
    protected $category;

    /**  
    *   @Annotation\Required(false)
    *   @Annotation\Filter({"name":"StringTrim"})
    *   @Annotation\Filter({"name":"StripTags"})
    *   @Annotation\Validator({"name":"Digits"})
    *   @Annotation\Type("Zend\Form\Element\Select")
    *   @Annotation\Options({"label":"Plan type", "empty_option":""})         
    */
    protected $planType;
    
    /** 
    * @Annotation\Type("Zend\Form\Element\Text")
    * @Annotation\Required(false)
    * @Annotation\Filter({"name":"StringTrim"})
    * @Annotation\Filter({"name":"StripTags"})
    * @Annotation\Validator({"name":"StringLength", "options":{"min":1}})
    *   @Annotation\Options({"label":"Owner's name"})         
    */
    protected $ownerName;

    /** 
    *   @Annotation\Required(false)
    *   @Annotation\Filter({"name":"StringTrim"})
    *   @Annotation\Filter({"name":"StripTags"})
    *   @Annotation\Validator({"name":"EmailAddress"})
    *   @Annotation\Type("Zend\Form\Element\Text")
    *   @Annotation\Options({"label":"Owner's email address"})         
    */
    protected $ownerEmail;

    /** 
    *   @Annotation\Required(false)
    *   @Annotation\Type("Zend\Form\Element\Date")
    *   @Annotation\Validator({"name":"Date"})
    *   @Annotation\Options({"label":"Created after"})     
    */
    protected $createdAfter;

    /** 
    *   @Annotation\Required(false)
    *   @Annotation\Type("Zend\Form\Element\Date")
    *   @Annotation\Validator({"name":"Date"})
    *   @Annotation\Options({"label":"Created before"})     
    */
    protected $createdBefore;

    /** 
    *   @Annotation\Required(false)
    *   @Annotation\Type("Zend\Form\Element\MultiCheckbox")
    *   @Annotation\Options({"label":"Type"})     
    */
    protected $type;

    /** 
    *   @Annotation\Required(false)
    *   @Annotation\Type("Zend\Form\Element\MultiCheckbox")
    *   @Annotation\Options({"label":"Status"})     
    */
    protected $status;
    
    /** 
    *   @Annotation\Type("Zend\Form\Element\Csrf")
    */
    protected $csrf;

    /** 
    *   @Annotation\Type("Zend\Form\Element\Submit")
    *   @Annotation\Attributes({"value":"Search"})     
    */
    protected $submit;
    
    
}