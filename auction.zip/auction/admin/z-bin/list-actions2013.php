<html>
<head>
<basefont face="Verdana">
<title>auction admin list</title>
</head>

<body>

<!-- standard page header begins -->
<p>&nbsp;<p>

<table width="100%" cellspacing="0" cellpadding="5">
<tr>
    <td></td>
</tr>
<tr>
    <td bgcolor="#993333"><font size="-1" color="White">
    <b>AXA PPP Healthcare - Online Charity Auction</b></font>
    </td>
</tr>
</table>
<!-- standard page header ends -->

<?php
// includes
include('../includes/conf.php');
include('../includes/functions.php');

// open database connection
$connection = mysql_connect($host, $user, $pass) or die ('Unable to connect!');

// select database
mysql_select_db($db) or die ('Unable to select database!');

// generate and execute query
$query = "SELECT LotNumber, DisplayedLotNumber, LotTitle, LotDescription, LotDonor, LotOpenTime, LotCloseTime LotCurrentDisplayBid, LotWinner, LotPicture, AdditionalInfoLink FROM lots ORDER BY DisplayedLotNumber";

$result = mysql_query($query) or die ("Error in query: $query. " . mysql_error());

?>
<!-- Link to add additional items -->
<font size="4"><a href="add-actions.php">Add a New Item</a></font>  

<?php
// if records present
if (mysql_num_rows($result) > 0)
{
      // iterate through resultset
      // print title with links to edit and delete scripts
      while($row = mysql_fetch_object($result))
      {
      ?>
      <br/><br/>
      <?php echo ($row->DisplayedLotNumber); ?><br/>
      <font size="4"><b><?php echo $row->LotTitle; ?></b> <br/>
      <?php echo ($row->LotDescription); ?><br/>
      <?php echo ($row->LotDonor); ?><br/>
      <?php echo ($row->LotPicture); ?></font><br/>
      <?php echo ($row->AdditionalInfoLink); ?></font><br/>
      <font size="3"><a href="edit-actions.php?id=<?php echo $row->DisplayedLotNumber; ?>">
      edit</a> | <a href="delete-actions.php?id=<?php echo $row->DisplayedLotNumber; ?>">
      delete</a></font>
      <p>
      <?php
      }
}
// if no records present
// display message
else
{
?>
      <font size="-1">No actions currently available</font><p>
<?php
}

// close connection
mysql_close($connection);
?>
<br/><br/>

<!-- Link to add additional items -->
<font size="4"><a href="add-actions.php">Add a New Item</a></font> 


<br/><br/>

<!-- standard page footer begins -->
<p>
<table width="100%" cellspacing="0" cellpadding="5">
<tr>
    <td align="center"><font size="-2">
    Few rights reserved. Visit  
    <a href="http://www.joining-dots.com"> 
    joining-dots</a> for more.</font></td>
</tr>
</table>
<!-- standard page footer ends -->

</body>
</html>