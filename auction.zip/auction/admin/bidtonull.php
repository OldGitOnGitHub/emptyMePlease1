<html>
<head>
<basefont face="Verdana">

</head>

<body>
<?php
    // includes
    include('../includes/conf.php');
    include('../includes/functions.php');


        // open database connection
        $connection = mysql_connect($host, $user, $pass) or die ('Unable to connect!');

        // select database
        mysql_select_db($db) or die ('Unable to select database!');

        // generate and execute query
        $query = "UPDATE lots SET LotCurrentDisplayBid=NULL, LotCurrentActiveBid=NULL, LotWinner=NULL";

        $result = mysql_query($query) or die ("Error in query: $query. " . mysql_error());

        // print result
        echo '<font size=4>Update successful.  <a href=list-actions.php>Go back to the Auction List</a>. </font>';

        // close database connection
        mysql_close($connection);
        


?>

<!-- Link to admin menu -->
<font size="4"><a href="index.php">Back to the Admin Menu</a></font>  

<!-- standard page footer begins -->
<p>
<table width="100%" cellspacing="0" cellpadding="5">
<tr>
    <td align="center"><font size="-2">
    Few rights reserved. Visit  
    <a href="http://www.joining-dots.com"> 
    joining-dots</a> for more.</font></td>
</tr>
</table>
<!-- standard page footer ends -->

</body>
</html>