<?php
namespace Application\Form;

use Zend\Form\Annotation;

class ConfirmationForm
{

    /** 
    * @Annotation\Type("Zend\Form\Element\Hidden")
    * @Annotation\Filter({"name":"Int"})
    * @Annotation\Attributes({"value":"1"})     
    */
    protected $confirmation;
    
    /** 
    *   @Annotation\Type("Zend\Form\Element\Csrf")
    */
    protected $csrf;

    /** 
    *   @Annotation\Type("Zend\Form\Element\Submit")
    *   @Annotation\Attributes({"value":"Confirm"})     
    */
    protected $submit;
    
    
}