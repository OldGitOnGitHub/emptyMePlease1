CKEDITOR.editorConfig = function( config ) {

config.scayt_autoStartup = true;
config.scayt_sLang = 'en_GB';

config.toolbar =
 [
  { name: 'basicstyles', items : [ 'Bold','Italic','Underline','-','Link','Unlink'] } 
 ];


config.extraPlugins = 'wordcount';
config.wordcount = {

// Whether or not you want to show the Word Count
showWordCount: true,

// Whether or not you want to show the Char Count
showCharCount: true
};

};