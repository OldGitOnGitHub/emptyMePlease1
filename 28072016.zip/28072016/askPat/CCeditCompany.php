<!DOCTYPE html>
<meta http-equiv="X-UA-Compatible" content="IE=edge" />
<?php include('userIDinclude.php'); ?>

<html>
<head>
<?php $ID = $_GET["ID"]; ?>

<title>Edit company #<?php echo $ID;?></title>

<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.css">
<link rel="stylesheet" type="text/css" href="styles.css">

<script src="scripts/jquery-1.10.1.min.js" type="text/javascript"></script>

<link rel="stylesheet" href="fancybox/jquery.fancybox.css?v=2.1.5" type="text/css" media="screen" />
<script type="text/javascript" src="fancybox/jquery.fancybox.pack.js?v=2.1.5"></script>


<link type="text/css" rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/qtip2/2.1.0/jquery.qtip.min.css" />
<script type="text/javascript" src="//cdnjs.cloudflare.com/ajax/libs/qtip2/2.1.0/jquery.qtip.min.js"></script> 

<script src="ckeditor4.5.9/ckeditor.js" type="text/javascript"></script>


<script src="scripts.js" type="text/javascript"></script>




</head>
<body class="formPage editCompany">

<?php

if (!$_POST['submit'])
{

// includes
include('conf.php');

// open database connection
$connection = mysql_connect($host, $user, $pass) or die ('Unable to connect!');

// select database
mysql_select_db($db) or die ('Unable to select database!');



        // generate and execute query
        $query = "SELECT * FROM CANCER_companies WHERE ID ='".$ID."'";


        $result = mysql_query($query) or die ("Error in query: $query. " . mysql_error());

// if records present
if (mysql_num_rows($result) > 0)
{

      while($row = mysql_fetch_object($result))
      {

?>

<h1>Edit company #<?php echo $ID;?></h1>

<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST">
<input name="ID" type="hidden" value="<?php echo $row->ID ; ?>" >
<label>Company Name</label>
<input type="text" name="name" value="<?php echo $row->name; ?>" />
<label>Part of AXA group?</label>
<input type="checkbox" name="axaGroup" value="1" <?php if ($row->axaGroup=="1"){ ?> checked="checked" <?php }; ?> />
<label>Generic Item #1</label>
<textarea class="ckeditor" name="genericItem1" id="genericItem1" rel="1"><?php echo $row->genericItem1; ?></textarea>
<textarea name="genericItem1hidden" style="display: none;"><?php echo $row->genericItem1; ?></textarea>
<input type="text" name="genericItem1date" value="<?php echo $row->genericItem1date; ?>"  rel="1">
<label>Generic Item #2</label>
<textarea class="ckeditor" name="genericItem2" rel="2"><?php echo $row->genericItem2; ?></textarea>
<textarea name="genericItem2hidden" style="display: none;"><?php echo $row->genericItem2; ?></textarea>
<input type="text" name="genericItem2date" value="<?php echo $row->genericItem2date; ?>" rel="2">
<label>Generic Item #3</label>
<textarea class="ckeditor" name="genericItem3" rel="3"><?php echo $row->genericItem3; ?></textarea>
<textarea name="genericItem3hidden" style="display: none;"><?php echo $row->genericItem3; ?></textarea>
<input type="text" name="genericItem3date" value="<?php echo $row->genericItem3date; ?>" rel="3">
<label>General Info</label>
<textarea name="generalInfo" class="ckeditor"><?php echo $row->generalInfo; ?></textarea>
<label>Web Address</label>
<input type="text" name="webAddress" value="<?php echo $row->webAddress; ?>"/>
<input type="submit" value="Update" name="submit">
</form>
<?php

	}
}
// close connection
mysql_close($connection);
?>



<?php
}
else
{
    // includes
    include('conf.php');

    // set up error list array
    $errorList = array();
    
$ID = $_POST['ID'];
$name = $_POST['name'];
$axaGroup = $_POST['axaGroup'];
$genericItem1 = $_POST['genericItem1'];
$genericItem1date = date("d/m/Y");
$genericItem2 = $_POST['genericItem2'];
$genericItem2date = date("d/m/Y");
$genericItem3 = $_POST['genericItem3'];
$genericItem3date = date("d/m/Y");
$generalInfo = $_POST['generalInfo'];
$webAddress = $_POST['webAddress'];

    if (!trim($axaGroup) == '1') 
    { 
        $axaGroup = "0";
    }

    // validate text input fields
    if (trim($_POST['name']) == '') 
    { 
        $errorList[] = 'Invalid entry: Name'; 
    }
 
    // check for errors
    // if none found...
    if (sizeof($errorList) == 0)
    {
        // open database connection
        $connection = mysql_connect($host, $user, $pass) or die ('Unable to connect!');

        // select database
        mysql_select_db($db) or die ('Unable to select database!');

         $query = "UPDATE CANCER_companies SET name ='$name', axaGroup ='$axaGroup', genericItem1 ='$genericItem1', genericItem1date ='$genericItem1date', genericItem2 ='$genericItem2', genericItem2date ='$genericItem2date', genericItem3 ='$genericItem3', genericItem3date ='$genericItem3date', generalInfo ='$generalInfo', webAddress ='$webAddress' WHERE ID ='".$ID."'";

        $result = mysql_query($query) or die ("Error in query: $query. " . mysql_error());

/**********ACTIVITY LOG FUNCTIONALITY**********/
/*
        $currentFile = $_SERVER["PHP_SELF"];
		$ipAddress = $_SERVER["REMOTE_ADDR"];
		$date = date("Y/m/d");
		$escapedQuery = mysql_escape_string($query);
        // generate and execute query
        $activityQuery = "INSERT INTO activityLog(user, page, notes, query, errors, dateExecuted, ipAddress) VALUES('$userID', '$currentFile', 'Attempt to edit topic".$ID.".', '$escapedQuery', '$SQLerror', '$date', '$ipAddress')";

        $activityResult = mysql_query($activityQuery) or die ("Error in query: $query. " . mysql_error());
*/
/**********************************************/

        // print result
               echo '<h2>Update successful.</h2>';
?>
<script src="scripts/jquery-1.10.1.min.js" type="text/javascript"></script>
 
<script>
$(document ).ready(function() {
parent.location.reload();
});
</script>
<?php
        // close database connection
        mysql_close($connection);
    }
    else
    {
    
    
        // errors found
        // print as list
        echo '<font size=-1>The following errors were encountered:'; 
        echo '<br>';
        echo '<ul>';
        for ($x=0; $x<sizeof($errorList); $x++)
        {
            echo "<li>$errorList[$x]";
        }
        echo '</ul></font><br /><a href=&amp;javascript: history.go(-1)&amp;>Back</a>';
    }
}
?>
</body>
</html>