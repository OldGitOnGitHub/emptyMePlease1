<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="en" xml:lang="en">
<head>
	<!-- HINT! Do a search (CTRL + F) for four angle brackets like this >>>> to find all the sections of the page you need to edit-->

    <!-- >>>> Its important to add a document title, its what appears in the blue bar at the top of Internet Explorer -->
	<!-- >>>> Its NOT the title that appears on the main part of the page, see below for that (search for the word 'content' -->
    <title>Charity Auction</title>    
    <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
    
	<!-- >>>> add a description here of the contants of the page  -->
	<!-- >>>> ie Introduction to the XYZ Team, we build widgits, make tea, and say wibble to anyone who will listen  -->
	<meta name="description" content="Charity Auction" />
	
    <!-- stop 'em bidding after its closed -->
    <!-- <meta http-equiv="refresh" content="60; url=/intranet/timeout/Auction/2012/index.php"> -->

	<?php
	// >>>> Change the email addresses on the following lines to the information owner and publisher (can be different)
	// >>>> the publisher line controls the name that appears at the bottom of the page when its on Healthnet, you cant change the date that appears 
      $document_owner="graham.thomas@axa-ppp.co.uk";
      $devolved_publisher="terry.golding@axa-ppp.co.uk";      
    ?>
    <link rel="search" type="application/opensearchdescription+xml" href="http://www.intranet.pppgroup.co.uk/intranet/global/includes/opensearch.xml" title="AXA PPP intranet search" />
    <link rel="search" type="application/opensearchdescription+xml" href="http://www.intranet.pppgroup.co.uk/intranet/global/includes/opensearch-phonedir.xml" title="AXA UK phone directory" />
    <link type="image/x-icon" href="/intranet/global/imgs/favicon.ico" rel="Shortcut Icon" />
    <meta http-equiv="imagetoolbar" content="no" />
    <link href="/intranet/global/css/common.css" rel="stylesheet" media="screen, print" type="text/css" />
    <link href="/intranet/global/css/content.css" rel="stylesheet" media="screen, print" type="text/css" />
    <link href="/intranet/global/css/appphspecific.css" rel="stylesheet" media="screen, print" type="text/css" />
    <link href="/intranet/global/css/pages.css" rel="stylesheet" media="print, screen" type="text/css" />
    <link href="/intranet/global/css/print.css" rel="stylesheet" media="print" type="text/css" />
    <script type="text/javascript" src="http://www.intranet.pppgroup.co.uk/intranet/global/scripts/jquery-1.3.2.min.js"></script>
    <script type="text/javascript" src="http://www.intranet.pppgroup.co.uk/intranet/global/scripts/scripts.js"></script>
    <script type="text/javascript" src="http://www.intranet.pppgroup.co.uk/intranet/global/scripts/cookies.js"></script>
    <script type="text/javascript" src="http://www.intranet.pppgroup.co.uk/intranet/global/scripts/favourites.js"></script>
    <script type="text/javascript" src="http://www.intranet.pppgroup.co.uk/intranet/global/scripts/jscss.js"></script>

    <style type="text/css">
	<!-- To use these styles on your table, add Class="TG" tothe table tag so it should look something like this <table class-"TG">  -->
        table.TG {
          width:auto;
          border-width: 1px 1px 1px 1px;
          border-spacing: 0px;
          border-style: none none none none;
          border-color: gray gray gray gray;
          border-collapse: collapse;
          background-color: white;
        }
        table.TG th {
          border-width: 1px 1px 1px 1px;
          padding: 0px 0px 0px 0px;
          border-style: inset inset inset inset;
          border-color: gray gray gray gray;
          background-color: #CCC;
          -moz-border-radius: 0px 0px 0px 0px;
        }
        table.TG td {
          border-width: 1px 1px 1px 1px;
          padding: 0px 0px 0px 0px;
          border-style: inset inset inset inset;
          border-color: gray gray gray gray;
          background-color: ;
          vertical-align:middle;
          -moz-border-radius: 0px 0px 0px 0px;
        }      
        table.TG td.TGRight {
        text-align: right;/Applications/XAMPP/xamppfiles/htdocs/auction/index.php
        }

		.floater-r{
		float:right;
		margin-left:0.5em;
		}
		
    </style>
    
																			   <script type="text/javascript">
																			   navLocation="Time out:Employee discounts:Tunbridge Wells area";
																			   </script>
																			   
																							   
																							   
																			<!----REDESIGN START----->
																			   
																			  							   
																			   
																			   <script type="text/javascript" src="newlook/fancybox/jquery.mousewheel-3.0.4.pack.js"></script>
																			   <script type="text/javascript" src="newlook/fancybox/jquery.fancybox-1.3.4.pack.js"></script>
																			   <link rel="stylesheet" type="text/css" href="newlook/fancybox/jquery.fancybox-1.3.4.css" media="screen" />
																			   
																			   <link href="newlook/newlook.css" rel="stylesheet" media="all" type="text/css" />
																			   <script type="text/javascript" src="newlook/newlook.js"></script>

																			<!----REDESIGN END-------->
<script>
$(document).ready(function() {
//$('button').click(function() {
//alert('button click');
$('#loadJquery').load('itemPriceJquery.php');
setInterval(function(){$('#loadJquery').load('itemPriceJquery.php')},6000);
//});
});
</script>
    </head>

<body class="col3">
<div id="loadJquery"></div>
  <div id="wrapper">
	<?php
    	include($_SERVER['DOCUMENT_ROOT']."/intranet/global/includes/page-header.php");
		// >>>> Be sure to change the path below to point to the correct local nav file or you will be loading the wrong menu !
    	include($_SERVER['DOCUMENT_ROOT']."/intranet/timeout/local-nav.html");
    ?>

  	<div class="presentational1"></div>
 	<div id="content">
    	<!-- >>>> This is the section with the page heading that appears at the top of the page -->
        
        <!-- Code to check we can get information items from the database -->
        <?php
            // includes
            include('includes/conf.php');
            include('includes/functions.php');            
            // open database connection
            $connection = mysql_connect($host, $user, $pass) or die ('Unable to connect!');            
            // select database
            mysql_select_db($db) or die ('Unable to select database!');            
		?>
		<!-- end of Code to check we can get information items from the database -->


        	<h1>Charity auction - 2013 </h1>
				

            <img src="images/gavel.gif" alt="Charity Auction" width="110" height=115 border="0" class="floater-r"/>
            <p>Welcome to the home page for AXA PPP healthcare's 2012 charity auction.</p>

            <!-- START OF END OF CLOSE AUCTION MESSAGE -->
            <!--
            <p>
            The 2010 Intranet Charity Auction has now closed. Thank you to everyone who placed a bid or donated an item. 
            </p>
            
            <p>
            We have raised a whopping <b>?????</b> for charity � the vast bulk of which will be donated to our annual chosen charity, 
            <a href="">?????</a> 
            Winning bidders will be contacted very shortly to arrange payment and collection of their item.
            </p>
            -->
            <!-- END OF END OF AUCTION MESSAGE -->

            <h3>Auction Items</h3>
            <p>Please browse through the items below and if you wish to make a bid, select the <em>Bid now</em> button beneath the item in question. 
            NB - please state if you wish your bid to remain anonymous on the site.</p>            
            <p>All bids must be made in whole pounds - if your bid contains an odd number of pence it will be rounded up to the nearest pound.</p>
            <p>Like eBay, bidding will be done for you by proxy. </p>
            <p><strong>Always bid the maximum you are willing to pay</strong> for the item. This saves everyone time and effort, you in particular. </p>
            <p>If your bid is the highest we will only ever keep it at &pound;1 more than the next highest bidder. Highest bidders at the end of the auction period will only ever pay &pound;1 more than the next highest bidder for their item. </p>
            <p>In the case of two bids of exactly the same amount, the second bidder will be asked to bid again, if they want to. </p>
            <p><strong>The auction closes at 3pm on Tuesday 29th May.</strong> </p>
            <p> All proceeds from the auction will be donated to this year's chosen charity,            <a href="../../../initiatives/heartsinaction/chosen/chosen12.php">Chyps</a>.</p>            
            <p><strong>Graham Thomas, Community Officer</strong></p>


            
            <!-- start of lot item display -->
            <?php
				// generate and execute the database query				
				$query = "SELECT lots.LotNumber, DisplayedLotNumber, LotTitle, LotDescription, LotDonor, LotCurrentDisplayBid, BidderName, LotPicture, AdditionalInfoLink FROM lots LEFT JOIN bids ON lots.LotCurrentActiveBid = bids.BidNumber ORDER BY lots.DisplayedLotNumber";
				$result = mysql_query($query) or die ("Error in query: $query. " . mysql_error());
				// if records present
				if (mysql_num_rows($result) > 0)
				{
					  // iterate through resultset
					  while($row = mysql_fetch_object($result))
					  {
            ?>
              <div class="tile" style="background-image: url('images/<?php echo ($row->LotPicture); ?>')"><a class="fancyBox" href="#<?php echo $row->LotNumber; ?>container" ><!--<img alt="" src="images/<?php echo ($row->LotPicture); ?>" border="0"/>--><p><?php echo ($row->LotTitle); ?></p></a></div>
		
																							   
			<div style="display: none;" >
			<div id="<?php echo $row->LotNumber; ?>container" class="fancyBoxConatiner" >
            <form action="submit.php" method="post">
            <div>
                <!-- <img alt="" src="images/odeon1.jpg" border="0" height=50px/> -->
                
                <!-- show images on the server -->
                 <img alt="" src="images/<?php echo ($row->LotPicture); ?>" border="0" height=80px/> 
           </div>
            
            <input type="hidden" name="bidlot" value="<?php echo $row->LotNumber; ?>" />	
                <table>
                    <caption>Lot <?php echo $row->DisplayedLotNumber; ?>: <?php echo ($row->LotTitle); ?></caption>
                    <tr>
                        <th scope="row">Item</th>
                        <td><?php echo ($row->LotTitle); ?></td>
                    </tr>
                    <tr>
                        <th scope="row">Kindly donated by</th>
                        <td><?php echo($row->LotDonor); ?></td>
                    </tr>
                    <tr>
                        <th scope="row">Description</th>
                        <td><?php echo($row->LotDescription); ?></td>
                    </tr>
                    <tr>
                        <th scope="row">Current highest  bid </th>
                        <td id="<?php echo $row->LotNumber; ?>price"></td>
                    </tr>            
                    <?php if (!empty($row->AdditionalInfoLink)): ?>
                    <tr>
                        <th scope="row">Additional Information </th>
                        <td><a href="<?php echo $row->AdditionalInfoLink; ?>">Click here</a> </td>
                    </tr>
                    <?php endif; ?>            
                    <tr>
                        <td colspan="2"><input id="formsubmit" type="submit" name="submit" value="Bid now!" /></td>
                    </tr>            
                </table>            
            </form>
			</div>
			</div>
			<?php
          				}
            	}
            // if no records present
            // display message
            else
            {
            ?>
                  <font size="-1">No items currently available</font><p>
            <?php
            }
            
            // close connection
            mysql_close($connection);
            ?>
    </div>  
     <!-- This is the end of the main content section in the middle of the page-->        
    <div class="presentational2"></div>
																							   <div id="related-links">
																							   <h2>Related links</h2>
																							   <ul>
																							   <!-- >>>> The following links appear in the Related Links column on the right side of the page -->
																							   <li><a href="http://intranetapps.axa-uk.intraxa/pppedia/index.php/Main_Page">PPPedia</a> </li>
																							   </ul>
																							   </div>
     <!-- page last updated and footer includes start -->
     <!-- DONT EDIT BELOW THIS LINE  -->
	  <?php
      include($_SERVER['DOCUMENT_ROOT']."/intranet/global/includes/page-last-updated.php");
      include($_SERVER['DOCUMENT_ROOT']."/intranet/global/includes/footer.php");
      ?>
      <!-- page last updated and footer includes end -->
  </div>
</body>
</html>
