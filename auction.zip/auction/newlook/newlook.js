$(document).ready(function() {
				  

				  
				  $("a.fancyBox").fancybox({
										 });


});