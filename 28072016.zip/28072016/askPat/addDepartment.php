<!DOCTYPE html>
<meta http-equiv="X-UA-Compatible" content="IE=edge" />
<?php  include('userIDinclude.php'); ?>

<html>
<head>
<title>Add a department</title>

<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.css">

<link rel="stylesheet" type="text/css" href="styles.css">

</head>
<body class="formPage">
<?php
if (!$_POST['submit'])
{
?>


<h1>Add a department</h1>
<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST">
<label>Department Name</label>
<input type="text" name="name"/>
<label>Is this department currently active?</label>
<input type="checkbox" checked="checked" name="isCurrent" value="1"/>
<input type="submit" value="Add" name="submit">
</form>


<?php
}
else
{
    // includes
    include('conf.php');

    // set up error list array
    $errorList = array();
    
    $name = $_POST['name'];
    $isCurrent = $_POST['isCurrent'];
    
    if (!trim($_POST['isCurrent']) == '1')  {
    	$isCurrent="0";
    	}
    	
    // validate text input fields
    if (trim($_POST['name']) == '') 
    { 
        $errorList[] = 'Invalid entry: Name'; 
    }


    
    // check for errors
    // if none found...
    if (sizeof($errorList) == 0)
    {
        // open database connection
        $connection = mysql_connect($host, $user, $pass) or die ('Unable to connect!');

        // select database
        mysql_select_db($db) or die ('Unable to select database!');

        // generate and execute query
        $query = "INSERT INTO departments(name, isCurrent) VALUES('$name', '$isCurrent')";

        $result = mysql_query($query) or die ("Error in query: $query. " . mysql_error());

/**********ACTIVITY LOG FUNCTIONALITY**********/
        $currentFile = $_SERVER["PHP_SELF"];
		$ipAddress = $_SERVER["REMOTE_ADDR"];
		$date = date("Y/m/d");
		$escapedQuery = mysql_escape_string($query);
        // generate and execute query
        $activityQuery = "INSERT INTO activityLog(user, page, notes, query, errors, dateExecuted, ipAddress) VALUES('$userID', '$currentFile', 'Added a new department.', '$escapedQuery', '', '$date', '$ipAddress')";

        $activityResult = mysql_query($activityQuery) or die ("Error in query: $query. " . mysql_error());
/**********************************************/

        // print result
        echo '<h2>Update successful.</h2><br>';

        // close database connection
        mysql_close($connection);
    }
    else
    {
        // errors found
        // print as list
        echo '<font size=-1>The following errors were encountered:'; 
        echo '<br>';
        echo '<ul>';
        for ($x=0; $x<sizeof($errorList); $x++)
        {
            echo "<li>$errorList[$x]";
        }
        echo '</ul></font><br /><a href=&amp;javascript: history.go(-1)&amp;>Back</a>';
    }
}
?>

</body>
</html>