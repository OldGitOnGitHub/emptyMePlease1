<?php
namespace Application\Form\View\Helper;

use Zend\Form\View\Helper\FormLabel as ZendFormLabel;
use Zend\Form\ElementInterface;

/**
 * Add mark (*) for all required elements inside a form.
 */
class FormLabel extends ZendFormLabel
{
     /**
     * Invokable
     *
     * @return str
     */    
    public function __invoke(ElementInterface $element = null, $labelContent = null, $position = null)
    {

        // invoke parent and get form label
        $originalformLabel = parent::__invoke($element,$labelContent,$position);

        // check if element is required
        if ($element->hasAttribute('required')) {
            // add a start to required elements
            echo '<span class="required">' . $originalformLabel . '</span>';
        }else{
            // not start to optional elements
            return  $originalformLabel;
        }
    }
}