<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="en" xml:lang="en">
<head>
<meta http-equiv="X-UA-Compatible" content="IE=EmulateIE8" />

	<!-- HINT! Do a search (CTRL + F) for four angle brackets like this >>>> to find all the sections of the page you need to edit-->

    <!-- >>>> Its important to add a document title, its what appears in the blue bar at the top of Internet Explorer -->
	<!-- >>>> Its NOT the title that appears on the main part of the page, see below for that (search for the word 'content' -->
    <title>Charity Auction - Submit</title>    
    <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
    
	<!-- >>>> add a description here of the contants of the page  -->
	<!-- >>>> ie Introduction to the XYZ Team, we build widgits, make tea, and say wibble to anyone who will listen  -->
	<meta name="description" content="Charity Auction" />
	
    <!-- stop 'em bidding after its closed 
    <meta http-equiv="refresh" content="60; url=/intranet/timeout/Auction/2012/index.php">-->

	<?php
	// >>>> Change the email addresses on the following lines to the information owner and publisher (can be different)
	// >>>> the publisher line controls the name that appears at the bottom of the page when its on Healthnet, you cant change the date that appears 
      $document_owner="graham.thomas@axa-ppp.co.uk";
      $devolved_publisher="terry.golding@axa-ppp.co.uk";      
    ?>
    <link rel="search" type="application/opensearchdescription+xml" href="http://www.intranet.pppgroup.co.uk/intranet/global/includes/opensearch.xml" title="AXA PPP intranet search" />
    <link rel="search" type="application/opensearchdescription+xml" href="http://www.intranet.pppgroup.co.uk/intranet/global/includes/opensearch-phonedir.xml" title="AXA UK phone directory" />
    <link type="image/x-icon" href="/intranet/global/imgs/favicon.ico" rel="Shortcut Icon" />
    <meta http-equiv="imagetoolbar" content="no" />

    <link href="/intranet/global/css/content.css" rel="stylesheet" media="screen, print" type="text/css" />
    <link href="/intranet/global/css/appphspecific.css" rel="stylesheet" media="screen, print" type="text/css" />
    <link href="/intranet/global/css/pages.css" rel="stylesheet" media="print, screen" type="text/css" />
    <link href="/intranet/global/css/print.css" rel="stylesheet" media="print" type="text/css" />
    <?php
		include($_SERVER['DOCUMENT_ROOT']."/intranet/global/includes/page-scripts-styles.html");
	?>

    <style type="text/css">
	<!-- To use these styles on your table, add Class="TG" tothe table tag so it should look something like this <table class-"TG">  -->
        table.TG {
          width:auto;
          border-width: 1px 1px 1px 1px;
          border-spacing: 0px;
          border-style: none none none none;
          border-color: gray gray gray gray;
          border-collapse: collapse;
          background-color: white;
        }
        table.TG th {
          border-width: 1px 1px 1px 1px;
          padding: 0px 0px 0px 0px;
          border-style: inset inset inset inset;
          border-color: gray gray gray gray;
          background-color: #CCC;
          -moz-border-radius: 0px 0px 0px 0px;
        }
        table.TG td {
          border-width: 1px 1px 1px 1px;
          padding: 0px 0px 0px 0px;
          border-style: inset inset inset inset;
          border-color: gray gray gray gray;
          background-color: ;
          vertical-align:middle;
          -moz-border-radius: 0px 0px 0px 0px;
        }      
        table.TG td.TGRight {
        text-align: right;
        }

		.floater-r{
		float:right;
		margin-left:0.5em;
		}
		
    </style>
    
    <script type="text/javascript">
		// >>>> The following line does two things ie navLocation="First Thing:Second Thing:";
		// >>>> The value of First Thing sets the menu item that will be highlighted on the healthnet menu bar, ie Team sites 
        // >>>> The value of Second Thing sets the menu item that will be highlighted in the menu on the left, typically that will be the name of this page 
        // >>>> For example if your page is in Team sites section and its called Fianance Team in the left hand menu, the following line should = navLocation="Team sites:Finance Team:";
        navLocation="Time out:Charity auction:";
    </script>
    
    <!-- basic validation scripts -->
    <script type="text/javascript" src="js/jquery.js"></script>
    <script type="text/javascript" src="js/jquery.validate.js"></script>
    <script type="text/javascript">
    	$(document).ready(function() {
    	$('#signup').validate();
    	}); // end validate
    </script>
    <!-- end of basic validation scripts -->

    </head>

<body class="col3">
  <div id="wrapper">    
	<?php
    	include($_SERVER['DOCUMENT_ROOT']."/intranet/global/includes/page-header.php");
		// >>>> Be sure to change the path below to point to the correct local nav file or you will be loading the wrong menu !
    	include($_SERVER['DOCUMENT_ROOT']."/intranet/timeout/local-nav.html");
    ?>

	<?php
		// includes
		include('includes/conf.php');
		include('includes/functions.php');
		
		// open database connection
		$connection = mysql_connect($host, $user, $pass) or die ('Unable to connect!');
		
		// select database
		mysql_select_db($db) or die ('Unable to select database!');
		$bidlot = stripslashes($_POST["bidlot"]);
		
		// get lot record
		$query = "SELECT * FROM lots WHERE LotNumber = '" . $bidlot . "'";
		$result = mysql_query($query) or die ("Error in query: $query. " . mysql_error());
		$row = mysql_fetch_object($result);
    ?>

	<div class="presentational1"></div>

	<div id="content">
		<h1>Place your bid for Lot <?php echo $row->DisplayedLotNumber; ?>: <?php echo ($row->LotTitle); ?> </h1>
		<form name="signup" id="signup"  method="post" action="confirmed.php" onsubmit="return checkAll(this);" style="margin-top:1.5em;">
			<input name="bidlot" id="bidlot" type="hidden" value="<?php echo $bidlot?>" />
			<table>
				<tr>
  					<td><label for="name">Your name</label></td>
					<td><input name="name" id="name" type="text" class="required" title="<h5>We'll need your First Name and Surname.  Once you've entered that, we'll be pleased to accept your bid.</h5>"></td>
                </tr>
                <tr>
                  	<td><label for="email">Your company email address</label></td>
                  	<td><input name="email" id="email" type="text" class="required email" title="<h5>We'll need your e-mail address.  Once you've entered that, we'll be pleased to accept your bid.</h5>"></td>
                </tr>
                <tr>
                  	<td><label for="phone">Your phone no.</label></td>
                  	<td><input name="phone" id="phone" type="text"  class="required" title="<h5>We'll need your phone number.  Once you've entered that, we'll be pleased to accept your bid.</h5>"></td>
                </tr>
                <tr>
                  	<td><label for="bid">Your bid &pound;</label></td>
                  	<td><input name="bid" id="bid" type="text" class="required" title="<h5>We'll need your bid.  Once you've entered that, we'll be pleased to accept it.</h5>"></td></tr>
                <tr>
                	<td colspan='2'><input type="submit" name="submit" id="formsubmit" value="Confirm bid" /></td>
                </tr>
            </table>
			
            <p><a href="index.php">Cancel</a></p>
		</form>
	</div>
	<div class="presentational2"></div>    
    <div id="related-links">    	
        <h2>Related links</h2>
        <ul>
          <!-- >>>> The following links appear in the Related Links column on the right side of the page -->
          <li>None</li>
        </ul>
     </div>
     <!-- page last updated and footer includes start -->
     <!-- DONT EDIT BELOW THIS LINE  -->
	  <?php
      include($_SERVER['DOCUMENT_ROOT']."/intranet/global/includes/page-last-updated.php");
      include($_SERVER['DOCUMENT_ROOT']."/intranet/global/includes/footer.php");
      ?>
      <!-- page last updated and footer includes end -->
  </div>
</body>
</html>
