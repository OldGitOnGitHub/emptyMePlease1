<html>
<head>

    <meta http-equiv="refresh" content="10">

	</head><body>
<?php
            // includes
            include('includes/conf.php');
            include('includes/functions.php');            
            // open database connection
            $connection = mysql_connect($host, $user, $pass) or die ('Unable to connect!');            
            // select database
            mysql_select_db($db) or die ('Unable to select database!');            


     // check for LotNumber
     if ((!isset($_GET['LotNumber']) || trim($_GET['LotNumber']) == '')) 
     { 
         die('Missing LotNumber!'); 
     } else {
        $LotNumber = $_GET['LotNumber'];
     }

				// generate and execute the database query				
				$query = "SELECT LotCurrentDisplayBid, BidderName FROM lots LEFT JOIN bids ON lots.LotCurrentActiveBid = bids.BidNumber WHERE lots.LotNumber='$LotNumber'";
				$result = mysql_query($query) or die ("Error in query: $query. " . mysql_error());
    $row = mysql_fetch_object($result)
            ?>		
                        <?php echo gmdate("h:i:s A") . "<br>"; ?>
                        <p>&pound;<?php echo((int)$row->LotCurrentDisplayBid); ?> <?php echo !empty($row->BidderName) ? '- ' . $row->BidderName : ''; ?></p>
                    

            <?php
            // close connection
            mysql_close($connection);
            ?>
</body>
</html>