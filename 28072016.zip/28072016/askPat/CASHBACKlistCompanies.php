<!DOCTYPE html>
<meta http-equiv="X-UA-Compatible" content="IE=edge" />
<html>
<head>

<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.css">
<link rel="stylesheet" type="text/css" href="styles.css">

<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js" type="text/javascript"></script>
<script src="scripts.js" type="text/javascript"></script>
<link rel="stylesheet" href="fancybox/jquery.fancybox.css?v=2.1.5" type="text/css" media="screen" />
<script type="text/javascript" src="fancybox/jquery.fancybox.pack.js?v=2.1.5"></script>
</head>
<body class="admin">
<div class="wrapper">
<?php

// includes
include('conf.php');

// open database connection
$connection = mysql_connect($host, $user, $pass) or die ('Unable to connect!');

// select database
mysql_select_db($db) or die ('Unable to select database!');


// generate and execute query
$query = "SELECT ID, name FROM CASHBACK_companies ORDER BY name ASC";

$result = mysql_query($query) or die ("Error in query: $query. " . mysql_error());

// if records present
if (mysql_num_rows($result) > 0)
{
?>

<table>
<tr>
	<th>ID</th>
	<th>Name</th>
	<th>Edit/Delete</th>
</tr>

<?php
      while($row = mysql_fetch_object($result))
      {
?>



<tr>
      <td>
      	<?php echo "#".$row->ID;?>
      </td>
      <td>
      	<?php echo $row->name; ?>
      </td>
      <td>
      	<a class="fancyBox" data-fancybox-type="iframe" href="CASHBACKeditCompany.php?ID=<?php echo $row->ID; ?>">
      		<img src="imgs/edit.png" />
      	</a>
      	<a class="fancyBox delete" data-fancybox-type="iframe" href="delete.php?table=CASHBACK_companies&ID=<?php echo $row->ID; ?>">
      		<img src="imgs/delete.png" />
      	</a>
      </td>
</tr>

<?php
	}
	?>
	
</table>
	
	<?php
}
// if no records present
// display message
else
{
?>
      <h1>No companies currently available</h1>
<?php
}
?>
</div>
<a href="javascript:history.go(-1)">Back</a>

</body>
</html>