<!DOCTYPE html>
<meta http-equiv="X-UA-Compatible" content="IE=edge" />
<html>
<head>
<title>CASHBACK Admin homepage</title>
<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.css">
<link rel="stylesheet" type="text/css" href="styles.css">
 
</head>
<body>
<h1>CASHBACK Admin Homepage</h1>

<table>
	<tbody>
  		<tr>
    			<td><button type="button" class="btn btn-primary" disabled="disabled">Policies</button></td>
    			<td><a class="btn btn-default" role="button" href="CASHBACKaddPolicy.php">Add</a></td>   			
    			<td><a class="btn btn-default" role="button" href="CASHBACKlistPolicies.php">Edit</a></td>    	   					
 		</tr>
  		<tr>
    			<td><button type="button" class="btn btn-primary" disabled="disabled">Companies</button></td>
    			<td><a class="btn btn-default" role="button" href="CASHBACKaddCompany.php">Add</a></td>   			
    			<td><a class="btn btn-default" role="button" href="CASHBACKlistCompanies.php">Edit</a></td>    	   					
 		</tr>
	</tbody>
</table>

</body>
</html>