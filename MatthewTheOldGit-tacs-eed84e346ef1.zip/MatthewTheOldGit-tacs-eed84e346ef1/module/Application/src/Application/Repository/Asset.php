<?php
namespace Application\Repository;

use Doctrine\ORM\EntityRepository;
use Doctrine\ORM\Query\ResultSetMapping;
use Doctrine\DBAL\Types\Type;
use Application\Entity\Activity as Activity;
use Application\Entity\Category as Category;

class Asset extends EntityRepository
{

    public function getActivities($asset, $type = null)
    {

        $qb = $this->_em->createQueryBuilder();
        
        $qb->select('a')
           ->from('Application\Entity\Activity', 'a')
           ->where('a.assetId = ?1')
           ->setParameter(1, $asset->getId());
        
        if ($type) {
            $qb->andWhere('a.type = ?2');
            $qb->setParameter(2, $type);
        }
        
        $query = $qb->getQuery();
        return $query->getResult();    
    }

    
    public function findByConditions($conditions)
    {
        $qb = $this->_em->createQueryBuilder();
        
        $query = $qb->select('a')
                    ->from('Application\Entity\Asset', 'a')
                    ->where('1 = 1')
                    ->add('orderBy', 'a.created DESC');
        
        if ($conditions['type']) {              
            $qb->andWhere('a.type IN (?1)')
               ->setParameter('1', $conditions['type']);
        }        
        
        if ($conditions['status']) {
            $qb->andWhere('a.status IN (?2)')
               ->setParameter('2', $conditions['status']);
        }        

        if ($conditions['keywords']) {
            $qb->andWhere('a.title LIKE ?3 OR a.description like ?3')
               ->setParameter(3, '%'.$conditions['keywords'].'%');
        }        

        if ($conditions['ownerName']) {
            $qb->andWhere('a.ownerName LIKE ?4')
               ->setParameter(4, '%'.$conditions['ownerName'].'%');
        }        

        if ($conditions['ownerEmail']) {
            $qb->andWhere('a.ownerEmail LIKE ?5')
               ->setParameter(5, '%'.$conditions['ownerEmail'].'%');
        }        

        if ($conditions['createdBefore']) {
            $qb->andWhere('a.created < ?6')
               ->setParameter(6, $conditions['createdBefore']);
        }        

        if ($conditions['createdAfter']) {
            $qb->andWhere('a.created > ?7')
               ->setParameter(7, $conditions['createdAfter']);
        }        

        if ($conditions['planType']) {
            $qb->andWhere('a.planType = ?8')
               ->setParameter(8, $conditions['planType']);
        }        

        if ($conditions['category']) {
            $qb->innerJoin('a.categories', 'c')
               ->andWhere('c.id = ?9')
               ->setParameter(9, $conditions['category']);
        }        

        $query = $qb->getQuery();
        $results = $query->getResult();    
        return $results;      
    }
    
    public function findByAudited($date, $conditions)
    {
        $qb = $this->_em->createQueryBuilder();
        
        $query = $qb->select('a')
                    ->from('Application\Entity\Activity', 'a')
                    ->andWhere('a.type = ?1')
                    ->andWhere('a.created < ?2')
                    ->setParameter(1, Activity::TYPE_AUDIT)
                    ->setParameter(2, $date)
                    ->add('orderBy', 'a.created DESC');
        $query = $qb->getQuery();
        $activities = $query->getResult();
        $assets = array();        
        foreach ($activities as $a) {
            $qb = $this->_em->createQueryBuilder();
            $query = $qb->select('a')
                        ->from('Application\Entity\Asset', 'a')
                        ->where('a.id = ?1')
                        ->setMaxResults(1)
                        ->setParameter(1, $a->getAssetId());
                        
            if (isset($conditions['status'])) {
                $qb->andWhere('a.status = ?2')
                   ->setParameter(2, $conditions['status']);
            }        
                  
            if (isset($conditions['consentUpdateStatus'])) {
                $qb->andWhere('a.consentUpdateStatus = ?3')
                   ->setParameter(3, $conditions['consentUpdateStatus']);
            }        
                        
            $query = $qb->getQuery();
            $result = $query->getResult();
            if ($result) {
                $asset = $result[0];
                $assets[] = $asset;
            } 
        }

        return $assets;
    }    
}