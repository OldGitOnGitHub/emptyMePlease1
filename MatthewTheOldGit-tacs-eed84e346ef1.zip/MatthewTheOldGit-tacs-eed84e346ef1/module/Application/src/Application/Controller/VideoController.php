<?php
namespace Application\Controller;

use Application\Entity\Asset as Asset;

class VideoController extends AssetController
{

    public function __construct()
    {
        return parent::__construct(Asset::TYPE_VIDEO);    
    }
    
}
