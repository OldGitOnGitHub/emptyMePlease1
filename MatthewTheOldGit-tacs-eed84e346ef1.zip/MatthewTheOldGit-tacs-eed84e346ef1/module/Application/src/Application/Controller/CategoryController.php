<?php
namespace Application\Controller;

use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;
use DoctrineModule\Stdlib\Hydrator\DoctrineObject as DoctrineHydrator;
use Zend\Form\Annotation\AnnotationBuilder;
use Application\Entity\Category as Category;
use Application\Form\ConfirmationForm as ConfirmationForm;

class CategoryController extends AbstractActionController
{

    public function indexAction()
    {        
        $entityManager = $this->getServiceLocator()->get('Doctrine\ORM\EntityManager');
        $categories = $entityManager->getRepository('\Application\Entity\Category')->findAll();   
        return new ViewModel(array('categories' => $categories));
    }

    public function createAction()
    {        
        $entityManager = $this->getServiceLocator()->get('Doctrine\ORM\EntityManager');
        $hydrator = new DoctrineHydrator($entityManager);
        $category = new Category();
        $builder = new AnnotationBuilder();
        $form = $builder->createForm($category);
        $form->setHydrator($hydrator);
        $form->bind($category);
        
        $request = $this->getRequest();
        if ($request->isPost()) {
            $form->setData($request->getPost());
            if ($form->isValid()) {
                $category->setId(null);
                $category->setStatus(Category::STATUS_ACTIVE);
                $entityManager->persist($category);
                $entityManager->flush();
                $this->flashMessenger()
                     ->setNamespace('success')
                     ->addMessage('Your category was successfully created.');
                return $this->redirect()->toRoute('categories');
            } else {
                $messages = $form->getMessages();
            }    
        }      
        
        return new ViewModel(array('form' => $form));
    }
    
    public function updateAction()
    {        
        $entityManager = $this->getServiceLocator()->get('Doctrine\ORM\EntityManager');
        $hydrator = new DoctrineHydrator($entityManager);
        $request = $this->getRequest();        
        
        $id = (int) $this->params()->fromRoute('id', 0);
        if (!$id) {
            return $this->redirect()->toRoute('categories');
        }
        $category = $entityManager->getRepository('\Application\Entity\Category')
                                  ->find($id);  
        $builder = new AnnotationBuilder();
        $form = $builder->createForm($category);
        $form->setHydrator($hydrator);
        $form->bind($category);
            
        if ($request->isPost()) {
            $form->setData($request->getPost());
            if ($form->isValid()) {
                $entityManager->persist($category);
                $entityManager->flush();
                $this->flashMessenger()
                     ->setNamespace('success')
                     ->addMessage('Your category was successfully updated.');
                return $this->redirect()->toRoute('categories');
            } else {
                $messages = $form->getMessages();
            }    
        }      
                                          
        return new ViewModel(array('form' => $form, 'id' => $category->getId()));
    }

    public function deleteAction() {
        $id = (int) $this->params()->fromRoute('id', 0);
        if (!$id) {
            return $this->redirect()->toRoute('categories');
        }

        $builder = new AnnotationBuilder();
        $form = $builder->createForm(new ConfirmationForm());
        $entityManager = $this->getServiceLocator()->get('Doctrine\ORM\EntityManager');
        $category = $entityManager->getRepository('\Application\Entity\Category')
                                  ->find($id);
        $request = $this->getRequest();        
        
        if ($request->isPost()) {
            $form->setData($request->getPost());
            if ($form->isValid()) {
                $validatedData = $form->getData();
                if ($validatedData['confirmation'] == '1') {
                    $entityManager->remove($category);
                    $entityManager->flush();
                    $this->flashMessenger()
                         ->setNamespace('success')
                         ->addMessage('Your category was successfully deleted.');
                    return $this->redirect()->toRoute('categories');
                }
            } else {
                $messages = $form->getMessages();
            }    
        }

        $view = new ViewModel(array(
            'form' => $form, 
            'id' => $category->getId(), 
            'route' => 'categories',
            'action' => 'delete', 
            'message' => 'The selected category will be deleted from the system. This operation cannot be undone.',
        ));
        $view->setTemplate('application/common/confirm.phtml');
        return $view;
    }    
}
