<!DOCTYPE html>
<meta http-equiv="X-UA-Compatible" content="IE=edge" />
<?php include('userIDinclude.php'); ?>

<html>
<head>

<title>Add a topic</title>

<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.css">
<link rel="stylesheet" type="text/css" href="styles.css">

<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js" type="text/javascript"></script>
<script src="ckeditor4.5.9/ckeditor.js" type="text/javascript"></script>


</head>
<body class="formPage">

<?php
if (!$_POST['submit'])
{

// includes
include('conf.php');

// open database connection
$connection = mysql_connect($host, $user, $pass) or die ('Unable to connect!');

// select database
mysql_select_db($db) or die ('Unable to select database!');

$topicID = $_GET["topicID"];


// generate and execute query
$query = "SELECT title FROM topics WHERE ID='".$topicID."'";

$result = mysql_query($query) or die ("Error in query: $query. " . mysql_error());
$result = mysql_fetch_object($result)
?>

<h1>Comment on topic:</h1>
<h1>"<?php echo $result->title; ?>"</h1>
<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST">
<input name="topicID" type="hidden" value="<?php echo $topicID ?>" >
<label>User</label>
<input name="userIDVisible" type="text" value="<?php echo $userID ; ?>" disabled="disabled" />
<input name="userID" type="hidden" value="<?php echo $userID ; ?>" />
<label>Department</label>
<select name="department" >
<?php

// generate and execute query
$query = "SELECT ID, name FROM departments ORDER BY ID DESC";

$result = mysql_query($query) or die ("Error in query: $query. " . mysql_error());

// if records present
if (mysql_num_rows($result) > 0)
{
      // iterate through resultset
      // print title with links to edit and delete scripts
      while($row = mysql_fetch_object($result))
      {
      ?>
      <option value="<?php echo $row->ID; ?>"><?php echo $row->name; ?></option> 
      <?php
      }
}
// if no records present
// display message
else
{
?>
      <option>No departments currently available</option>
<?php
}
?>
</select>
<label>Comment</label>
<textarea class="ckeditor" name="content" rows="4" cols="50"></textarea>
<input type="submit" value="Add" name="submit">
</form>
<?php
// close connection
mysql_close($connection);
?>



<?php
}
else
{
    // includes
    include('conf.php');

    // set up error list array
    $errorList = array();

    $topicID = $_POST['topicID'];    
    $userID = $_POST['userID'];
    $department = $_POST['department'];
    $content = $_POST['content'];
    
    	
    // validate text input fields

    if (trim($_POST['userID']) == '') 
    { 
        $errorList[] = 'Please tell us who you are.'; 
    }
    if (trim($_POST['department']) == '') 
    { 
        $errorList[] = 'Please tell us what department you are from.'; 
    }
        if (trim($_POST['content']) == '') 
    { 
        $errorList[] = 'Please include your comment.'; 
    }
    // check for errors
    // if none found...
    if (sizeof($errorList) == 0)
    {
        // open database connection
        $connection = mysql_connect($host, $user, $pass) or die ('Unable to connect!');

        // select database
        mysql_select_db($db) or die ('Unable to select database!');

        // generate and execute query
        $query = "INSERT INTO comments(topicID, userID, departmentID, content) VALUES('$topicID', '$userID', '$department', '$content')";


        $result = mysql_query($query) or die ("Error in query: $query. " . mysql_error());

/**********ACTIVITY LOG FUNCTIONALITY**********/
        $currentFile = $_SERVER["PHP_SELF"];
		$ipAddress = $_SERVER["REMOTE_ADDR"];
		$date = date("Y/m/d");
		$escapedQuery = mysql_escape_string($query);
        // generate and execute query
        $activityQuery = "INSERT INTO activityLog(user, page, notes, query, errors, dateExecuted, ipAddress) VALUES('$userID', '$currentFile', 'Helped a colleague ".$topicID."', '$escapedQuery', '$SQLerror', '$date', '$ipAddress')";

        $activityResult = mysql_query($activityQuery) or die ("Error in query: $query. " . mysql_error());
/**********************************************/

        // print result
        echo '<h2>Update successful.</h2><br>';
?>
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js" type="text/javascript"></script>

<script>
$(document ).ready(function() {
parent.location.reload();
});
</script>
<?php
        // close database connection
        mysql_close($connection);
    }
    else
    {
    
    
        // errors found
        // print as list
        echo '<font size=-1>We need you to fix the following things before we can submit your comment:'; 
        echo '<br>';
        echo '<ul>';
        for ($x=0; $x<sizeof($errorList); $x++)
        {
            echo "<li>$errorList[$x]";
        }
        echo '</ul></font><br /><a href=&amp;javascript: history.go(-1)&amp;>Back</a>';
    }
}
?>
</body>
</html>