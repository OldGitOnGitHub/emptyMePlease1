<html>
<head>
<title>Truncate Tables</title>
</head>
<body>
 
 
<h1>Truncate Tables Ready for New Auction</h1>
<!-- CODE TO EMPTY OUT LOTS AND BIDS TABLES, READY FOR A NEW AUCTION -->
 
 
 
<?php
// includes
include('../includes/conf.php');
include('../includes/functions.php');
 
// open database connection
$connection = mysql_connect($host, $user, $pass) or die ('Unable to connect!');
 
// select database
mysql_select_db($db) or die ('Unable to select database!');

 
// generate and execute query
$queryA = "TRUNCATE bids";
 
$resultA = mysql_query($queryA) or die ("Error in query: $queryA. " . mysql_error());

$queryB = "TRUNCATE lots";
 
$resultB = mysql_query($queryB) or die ("Error in query: $queryB. " . mysql_error());
 
// close connection
mysql_close($connection);
?>
 
 
</body>
</html>