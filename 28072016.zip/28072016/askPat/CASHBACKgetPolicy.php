<?php

// includes
include('conf.php');
//include('userIDinclude.php'); 

// open database connection
$connection = mysql_connect($host, $user, $pass) or die ('Unable to connect!');

// select database
mysql_select_db($db) or die ('Unable to select database!');

$policyID = $_GET["policyID"];
$ipAddress = $_GET["ipAddress"];
$userID = $_GET["userID"];

// generate and execute query
$query = "SELECT * FROM CASHBACK_policies WHERE ID='".$policyID."'";

$result = mysql_query($query) or die ("Error in query: $query. " . mysql_error());
// if records present
if (mysql_num_rows($result) > 0)
{

      // iterate through resultset
      // print title with links to edit and delete scripts
      while($row = mysql_fetch_object($result))
      {
$returnValue['name'] = $row->name;	
$returnValue['Benefit1'] = $row->Benefit1;	
$returnValue['Benefit2'] = $row->Benefit2;	
$returnValue['Benefit3'] = $row->Benefit3;	
$returnValue['Benefit4'] = $row->Benefit4;	
$returnValue['Benefit5'] = $row->Benefit5;	
$returnValue['Benefit6'] = $row->Benefit6;	
$returnValue['Benefit7'] = $row->Benefit7;	
$returnValue['Benefit8'] = $row->Benefit8;	
$returnValue['Benefit9'] = $row->Benefit9;	
$returnValue['Benefit10'] = $row->Benefit10;	
$returnValue['Benefit11'] = $row->Benefit11;	
$returnValue['Benefit12'] = $row->Benefit12;	
$returnValue['Benefit13'] = $row->Benefit13;	
$returnValue['Benefit14'] = $row->Benefit14;	
$returnValue['Benefit15'] = $row->Benefit15;	
$returnValue['Benefit16'] = $row->Benefit16;	
$returnValue['Benefit17'] = $row->Benefit17;	
$returnValue['Benefit18'] = $row->Benefit18;	
$returnValue['Benefit19'] = $row->Benefit19;	
$returnValue['Benefit20'] = $row->Benefit20;
$returnValue['Benefit21'] = $row->Benefit21;	
$returnValue['Benefit22'] = $row->Benefit22;	
$returnValue['Benefit23'] = $row->Benefit23;	
$returnValue['Benefit24'] = $row->Benefit24;	
$returnValue['Benefit25'] = $row->Benefit25;	
$returnValue['Benefit26'] = $row->Benefit26;	
$returnValue['Benefit27'] = $row->Benefit27;	
$returnValue['Benefit28'] = $row->Benefit28;	
$returnValue['Benefit29'] = $row->Benefit29;	
$returnValue['Benefit30'] = $row->Benefit30;	
$returnValue['Benefit31'] = $row->Benefit31;	
$returnValue['Benefit32'] = $row->Benefit32;	
$returnValue['Benefit33'] = $row->Benefit33;	
$returnValue['Benefit34'] = $row->Benefit34;	
$returnValue['Benefit35'] = $row->Benefit35;	
$returnValue['Benefit36'] = $row->Benefit36;	

$returnValue['dateAdded'] = $row->dateAdded;
$returnValue['dateAddedStr'] = strtotime($row->dateAdded);
$returnValue['dateModified'] = $row->dateModified;
$returnValue['dateModified'] = strtotime($row->dateModified);

echo json_encode($returnValue);
	
	

	
	}
	
	

	
}

?>