<?php
namespace Application\Controller;

use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;
use DoctrineModule\Stdlib\Hydrator\DoctrineObject as DoctrineHydrator;
use Application\Entity\Asset as Asset;
use Application\Form\SearchForm as SearchForm;
use Zend\Form\Annotation\AnnotationBuilder;

class SearchController extends AbstractActionController
{
    public function indexAction()
    { 
        $builder = new AnnotationBuilder();
        $form = $builder->createForm(new SearchForm());
        $entityManager = $this->getServiceLocator()->get('Doctrine\ORM\EntityManager');
        
        $form->get('category')->setOptions(array('object_manager' => $entityManager));        
        $categoryHydrator = new DoctrineHydrator($entityManager, 'Category');
        $categories = $entityManager->getRepository('\Application\Entity\Category')
                                    ->findBy(array('status' => '1'));
        foreach ($categories as $c) {
            $categoryId = $c->getId();
            $categoryOptions[$categoryId] = $c->getTitle();
        }
        $form->get('category')->setValueOptions($categoryOptions); 

        $typeOptions = array();
        $metadata = $this->assetPlugin()->getAssetMetadata();
        foreach ($metadata as $key => $value) {
            $typeOptions[$key] = ucfirst($value['labels'][1]);
        }
        $form->get('type')->setValueOptions($typeOptions); 

        $form->get('status')->setValueOptions($this->assetPlugin()->getStatusTypes()); 

        $form->get('planType')->setValueOptions($this->assetPlugin()->getPlanTypes());        
               
        $request = $this->getRequest();  
        $results = array();
        $count = false;
        
        if ($request->isPost()) {
            $form->setData($request->getPost());
            if ($form->isValid()) {
                $validatedData = $form->getData();
                $results = $entityManager->getRepository('\Application\Entity\Asset')
                                         ->findByConditions($validatedData);
                $count = count($results);
            } else {
                $messages = $form->getMessages();
            }    
                        
        }
        
        return new ViewModel(array(
            'form' => $form, 
            'results' => $results, 
            'count' => $count, 
            'assetPlugin' => $this->assetPlugin(),
        ));
        
    }

}
