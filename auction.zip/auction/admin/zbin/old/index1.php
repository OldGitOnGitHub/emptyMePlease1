<?php
// 'Not sure what's supposed to be going on here ...
header("Cache-Control: no-cache, must-revalidate"); 
header("Expires: Mon, 26 Jul 1997 05:00:00 GMT");
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="en" xml:lang="en">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<meta name="description" content="Details of the annual intranet auction for 2010. The intranet auction returned in October 2010 and is in aid of Kent Air Ambulance." />
<title>Charity auction 2010</title>
<?php
$document_owner="graham.thomas@axa-ppp.co.uk";
$devolved_publisher="matthew.newman@joining-dots.com";
include($_SERVER['DOCUMENT_ROOT']."/intranet/global/includes/page-scripts-styles.html");
?>
<script type="text/javascript">
navLocation="Time out:Auction:";
</script>

<style type="text/css">
<!--
.style1 {
	color: #FF0000;
	font-weight: bold;
}
.style2 {color: #FF0000}
-->
</style>
</head>
<body class="col3">

<div id="wrapper">
<?php
include($_SERVER['DOCUMENT_ROOT']."/intranet/global/includes/page-header.php");
include($_SERVER['DOCUMENT_ROOT']."/intranet/timeout/sports-and-social/local-nav.html");
?>


<div class="presentational1"></div>

<div id="content">

<!-- Code to check we can get information items from the database -->

<!--
<?php
// includes
include('includes/conf.php');
include('includes/functions.php');

// open database connection
$connection = mysql_connect($host, $user, $pass) or die ('Unable to connect!');

// select database
mysql_select_db($db) or die ('Unable to select database!');

// generate and execute query
$query = "SELECT LotNumber, LotTitle, LotDescription, LotDonor FROM lots";

$result = mysql_query($query) or die ("Error in query: $query. " . mysql_error());

// if records present
if (mysql_num_rows($result) > 0)
{
      // iterate through resultset
      while($row = mysql_fetch_object($result))
      {
      ?>
      
      <font size="-1"> <b> 
      <?php echo $row->LotNumber; ?> <br/>
      <?php echo ($row->LotTitle); ?> <br/> </b> 
      <?php echo($row->LotDescription); ?> <br />
      <?php echo($row->LotDonor); ?> <br/>
      </font>
      
      <?php
      }
}
// if no records present
// display message
else
{
?>
      <font size="-1">No items currently available</font><p>
<?php
}

// close connection
mysql_close($connection);
?>

<p>  </p>
-->

<h1>Charity auction</h1>

<p>Welcome to AXA PPP's 2010 charity auction.</p>

<p>Please browse the items below and if you wish to make a bid, click the <em>Bid now</em> button beneath the item in question. NB - please state if you wish your bid to remain anonymous on the site.</p>

<p>All bids must be made in pounds - if your bid contains an odd number of pence it will be rounded up to the nearest pound.</p>

<p>Like eBay, bidding will be done for you by proxy. <strong>Always bid the maximum you are willing to pay</strong> for the item. This saves everyone's time and effort. </p>
<p>If your bid is the highest we will only ever keep it at &pound;1 more than the next highest bidder. Highest bidders at the end of the auction period will only ever pay &pound;1 more than the next highest bidder for their item. </p>
<p>In the case of two bids of exactly the same amount, the bid placed first will win. <strong>The auction closes at ??am on ?? ?? October.</strong> </p>

<p> All proceeds from the auction will be donated to our annual chosen charity, <a href="../../../initiatives/heartsinaction/chosen/chosen09.php">Kent Air Ambulance </a>.</p>
<p><strong>Where possible the site will be updated once a day (normally in the afternoon), to reflect the latest highest bids. </strong></p>
<p class="style1">Latest update - 27 Oct, 8.58am</p>
<p><strong>Graham Thomas, Community Officer</strong></p>

<!-- start of a lot item -->
<form action="submit.php" method="post">
<div><img alt="" src="images/2009/lot1.jpg" border="0" /></div>
<input type="hidden" name="bidlot" value="lot 1: guitar lesson" />	
<table>
<caption>
Lot 1: Guitar experience 
</caption>
<tr>
<th scope="row">Item</th>
<td>One hour guitar session </td>
</tr>
<tr>
<th scope="row">Kindly donated by</th>
<td>Nick Harding</td>
</tr>
<tr>
<th scope="row">Description</th>
<td>60 minutes playing on a professional guitar rig with me as your �techy�. I�ll set up the rig by 17.30 in a meeting room and you can let your Clapton licks and Hendrix tricks transform the room into stadium filled with greasy-faced fans shouting something that you don�t quite understand. Tuition available, but your bid should reflect this! </td>
</tr>
<tr>
<th scope="row">Highest bid / bidder &pound;</th>
<td>Anonymous bidder - &pound;10 </td>
</tr>
<tr>
<td colspan="2"><input id="formsubmit" type="submit" name="submit" value="Bid now!" /></td>
</tr>
</table>
<p>&nbsp;</p>  
</form>
<!-- end of a lot item -->

<form action="submit.php" method="post">
<input type="hidden" name="bidlot" value="lot 2: Sparkling wine tasting session for a group" />
<div><img src="images/2009/lot2-thumb.jpg" alt="" width="100" border="0" /></div>
<table>
<caption>
Lot 2: Sparkling wine tasting session for a group
</caption>
<tr>
<th scope="row">Item</th>
<td>Sparkling wine tasting session</td>
</tr>
<tr>
<th scope="row">Kindly donated by</th>
<td>Codorn&iacute;u</td>
</tr>
<tr>
<th scope="row">Description</th>
<td>Enjoy a private sparkling wine tasting for you and five friends with a Codorn&iacute;u wine expert at The Chapel Bar, Tunbridge Wells. Hosted by Codorn&iacute;u, you will receive a unique opportunity to enjoy a selection of award-winning wines in a private suite in this Tunbridge Wells bar. You will each receive a bottle of Anna de Codorn&iacute;u Brut, Spain's favourite sparkling wine, at the end of the evening. (Prize must be taken during January 2010 and all attendees must be over 18 years of age)</td>
</tr>
<tr>
<th scope="row">Highest bid / bidder &pound;</th>
<td>Tamsin Brownbridge  - &pound;56</td>
</tr>
<tr>
<td colspan="2"><input id="formsubmit" type="submit" name="submit" value="Bid now!" /></td>
</tr>
</table>  
<p>&nbsp;</p>
</form>

<form action="submit.php" method="post">
<input type="hidden" name="bidlot" value="lot 3: Personal chef and waitress service" />
<div><a href="images/2009/lot3.jpg"><img alt="" src="images/2009/lot3-thumb.jpg" border="0" /></a> </div>
<table>
<caption>
Lot 3: Personal chef and waitress service 
</caption>
<tr>
<th scope="row">Item</th>
<td>Personal chef and waitress service </td>
</tr>
<tr>
<th scope="row">Kindly donated by</th>
<td>Victoria Georgalakis and Kate Whitehead <a href="http://www.masterofmalt.com/shopping/index.asp?mcode=axa1"></a></td>
</tr>
<tr>
<th scope="row">Description</th>
<td>Victoria & Kate will cook, serve and clear away a 3 course meal for 4 people, including two bottles of wine. This can take place either in your own home in the Tunbridge Wells area or at Victoria�s house in Tunbridge Wells and you can select the menu from a range of options including a Greek meze or a meat, fish or vegetarian meal. Last year this item was bought by Dr David Costain and he invited Fergus Craig and Dave Clarke to dinner, so why not ask one of them what they thought if you are tempted! Click image to view dining table.
</td>
</tr>
<tr>
<th scope="row">Highest bid / bidder &pound;</th>
<td>Richard Chant  - &pound;81</td>
</tr>
<tr>
<td colspan="2"><input id="formsubmit" type="submit" name="submit" value="Bid now!" /></td>
</tr>
</table>  
<p>&nbsp;</p>
</form>

<form action="submit.php" method="post">
<input type="hidden" name="bidlot" value="lot 4: pamper day at the Royal Spa" />
<div><a href="images/2009/lot4.jpg"><img alt="" src="images/2009/lot4-thumb.jpg" border="0" /></a></div>
<table>
<caption>
Lot 4: Pamper day for two at the Royal Spa
</caption>
<tr>
<th scope="row">Item</th>
<td>Pamper day for two at the Royal Spa</td>
</tr>
<tr>
<th scope="row">Kindly donated by</th>
<td><a href="http://www.royal-dayspa.co.uk/">Royal Day Spa</a>, Tunbridge Wells</td>
</tr>
<tr>
<th scope="row">Description</th>
<td> Two Royal Passwords plus two Moroccan Mist Moments. The Royal Password gives you complete use of all the facilities.
While away the day swimming, using the gym, having a sauna and catching up on your reading in our bedroom.  The Moroccan Mist Moment is a self administered treatment, including beautiful Oriental inspired products - a body scrub, mask and lotion rich in invigorating essential oils of ginger, lime, mandarin, lemon, vitamin e and soya beans to name but a few! Scrub yourself smooth, and heat yourself up in our lovely Moroccan Mist steam room. Lay yourself out on the comfortable limestone whilst your mask really gets working. Click the image for some photographs of the Spa's facilities.
</p></td>
</tr>
<tr>
<th scope="row">Highest bid / bidder &pound;</th>
<td>Tim Cross  - &pound;111</td>
</tr>
<tr>
<td colspan="2"><input id="formsubmit" type="submit" name="submit" value="Bid now!" /></td>
</tr>
</table>  
<p>&nbsp;</p>
</form>




</div>
<div class="presentational2"></div>
<div id="related-links">
<h2><b>Related</b> links</h2>
<ul>
<li><a href="../../../initiatives/heartsinaction/index.php">Hearts in Action</a></li>
<li><a href="../../../initiatives/heartsinaction/chosen/chosen10.php">Chosen charity for 2010</a></li>
</ul>
</div>

<?php
include($_SERVER['DOCUMENT_ROOT']."/intranet/global/includes/page-last-updated.php");
include($_SERVER['DOCUMENT_ROOT']."/intranet/global/includes/footer.php");
?>
</div>
</body>
</html>